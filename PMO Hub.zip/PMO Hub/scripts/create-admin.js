// Creates (or promotes) an administrator.
//   npm run create-admin -- you@company.com "Your Name"
// The password is read from the ADMIN_PASSWORD env var, or prompted for (hidden) in a terminal.
import crypto from 'node:crypto';
import readline from 'node:readline';
import { initDb, migrate, query, closeDb } from '../src/db.js';
import { hashPassword } from '../src/auth.js';
import { password as passwordRule } from '../src/validate.js';

const [email, ...nameParts] = process.argv.slice(2);
if (!email || !email.includes('@')) {
  console.error('Usage: npm run create-admin -- <email> [name]   (password via ADMIN_PASSWORD or prompt)');
  process.exit(1);
}

function promptHidden(q) {
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: true });
    rl._writeToOutput = (s) => { if (s.includes(q)) rl.output.write(s); };
    rl.question(q, (a) => { rl.close(); process.stdout.write('\n'); resolve(a); });
  });
}

const pw = process.env.ADMIN_PASSWORD || (await promptHidden('Password (min 10 chars, letters and numbers): '));
const check = passwordRule.safeParse(pw);
if (!check.success) { console.error(check.error.issues[0].message); process.exit(1); }

await initDb();
await migrate();
const name = nameParts.join(' ') || 'Administrator';
const hash = await hashPassword(pw);
const [existing] = await query('SELECT id FROM users WHERE email=$1', [email.toLowerCase()]);
if (existing) {
  await query("UPDATE users SET global_role='admin', active=true, password_hash=$2, failed_logins=0, locked_until=NULL WHERE id=$1", [existing.id, hash]);
  console.log(`Updated ${email} as administrator.`);
} else {
  await query('INSERT INTO users (id,email,name,password_hash,global_role) VALUES ($1,$2,$3,$4,$5)', [crypto.randomUUID(), email.toLowerCase(), name, hash, 'admin']);
  console.log(`Created administrator ${email}.`);
}
await closeDb();
