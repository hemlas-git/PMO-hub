import crypto from 'node:crypto';
import { Router } from 'express';
import { query, tx } from '../db.js';
import { HttpError, programRole, capsFor, CAPS, accessibleProgramIds, canCreateProgram } from '../auth.js';
import { computeProgram, programSummary, validateTask, cascadeShifts, todayStr, FORECAST_METHODS } from '../calc.js';
import { generateProposal, PROGRAM_TYPES } from '../proposal.js';
import {
  answersSchema, createProgramSchema, programPatchSchema, workstreamSchema, taskSchema, taskPatchSchema, resourceSchema,
  budgetLineSchema, raidSchema, baselineSchema,
} from '../validate.js';
import { loadModel, loadModels, createProgram, approveBaseline, logAudit, auditDiff, proposedCount } from '../service.js';

const uid = () => crypto.randomUUID();
const r = Router();

// ------------------------------------------------------------------ portfolio
r.get('/portfolio', async (req, res) => {
  const ids = await accessibleProgramIds(req.user);
  const models = await loadModels(ids);
  const [setting] = await query("SELECT value FROM settings WHERE key='portfolio'");
  const cfg = setting?.value || { base_currency: 'USD', fx: {} };
  const managed = req.user.global_role === 'admin' ? null : new Set((await query("SELECT program_id FROM program_members WHERE user_id=$1 AND role='manager'", [req.user.id])).map((x) => x.program_id));
  const programs = [...models.values()].map((m) => ({ ...programSummary(m, computeProgram(m)), can_delete: managed === null || managed.has(m.program.id) }));
  const conv = (cur) => (cur === cfg.base_currency ? 1 : cfg.fx[cur] ?? null);
  const agg = { programs: programs.length, base_currency: cfg.base_currency, approved: 0, forecast: 0, actual: 0, excluded_currencies: [], health: { green: 0, amber: 0, red: 0, draft: 0, complete: 0 }, high_items: 0, overdue_decisions: 0, overdue_actions: 0, open_support_requests: 0 };
  for (const p of programs) {
    agg.health[p.health] = (agg.health[p.health] || 0) + 1;
    agg.high_items += p.high_items; agg.overdue_decisions += p.overdue_decisions; agg.overdue_actions += p.overdue_actions; agg.open_support_requests += p.support_requests.length;
    const f = conv(p.currency);
    if (f == null) { if (!agg.excluded_currencies.includes(p.currency)) agg.excluded_currencies.push(p.currency); continue; }
    agg.approved += p.approved_budget * f; agg.forecast += p.forecast * f; agg.actual += p.actual * f;
  }
  res.json({ programs, summary: agg, can_create: canCreateProgram(req.user) });
});

// ------------------------------------------------------------------ proposals / creation
r.post('/proposals', async (req, res) => {
  if (!canCreateProgram(req.user)) throw new HttpError(403, 'You cannot create programs');
  const answers = answersSchema.parse(req.body);
  res.json({ proposal: generateProposal(answers), program_types: PROGRAM_TYPES });
});

r.post('/programs', async (req, res) => {
  if (!canCreateProgram(req.user)) throw new HttpError(403, 'You cannot create programs');
  const { answers, edits } = createProgramSchema.parse(req.body);
  const out = await tx((t) => createProgram(t, req.user, answers, edits));
  res.status(201).json({ id: out.id });
});

// ------------------------------------------------------------------ program scoping
r.use('/programs/:pid', async (req, _res, next) => {
  try {
    const pid = req.params.pid;
    if (!/^[0-9a-f-]{36}$/i.test(pid)) throw new HttpError(404, 'Not found');
    const [exists] = await query('SELECT 1 AS ok FROM programs WHERE id=$1', [pid]);
    const role = exists ? await programRole(req.user, pid) : null;
    if (!role) throw new HttpError(404, 'Not found'); // same answer whether it exists or not
    req.role = role; req.pid = pid;
    next();
  } catch (e) { next(e); }
});
const need = (cap) => (req, _res, next) => {
  if (!CAPS[cap].includes(req.role)) throw new HttpError(403, 'You do not have permission to change this');
  next();
};

async function detail(req) {
  const model = await loadModel(req.pid);
  const c = computeProgram(model);
  const p = model.program;
  const baselines = await query('SELECT id, version, approved_by, approved_at, note FROM baselines WHERE program_id=$1 ORDER BY version DESC', [req.pid]);
  const members = await query('SELECT u.id, u.name, u.email, m.role FROM program_members m JOIN users u ON u.id=m.user_id WHERE m.program_id=$1 ORDER BY u.name', [req.pid]);
  return {
    program: p, workstreams: model.workstreams, tasks: c.plan.nodes, resources: c.resources.resources, resource_roles: c.resources.roles,
    periods: c.resources.periods, resource_totals: c.resources.totals, resource_flags: c.resources.flags, assumptions: c.resources.assumptions,
    budget: c.budget, raid: c.raid, health: c.health, variance: c.variance, baselines, members,
    plan: { issues: c.plan.issues, progress: c.plan.progress, plannedProgress: c.plan.plannedProgress, nextMilestones: c.plan.nextMilestones, keyMilestone: c.plan.keyMilestone, forecastEnd: c.plan.forecastEnd, overdueTasks: c.plan.overdueTasks },
    today: c.today, role: req.role, caps: capsFor(req.role), forecast_methods: FORECAST_METHODS, program_types: PROGRAM_TYPES,
    pending_proposals: await proposedCount({ query }, req.pid),
  };
}

r.get('/programs/:pid', async (req, res) => res.json(await detail(req)));

// ------------------------------------------------------------------ program fields
const CHARTER_FIELDS = ['summary', 'objectives', 'outcomes', 'success_measures', 'scope', 'exclusions', 'governance', 'constraints'];
const PROGRAM_CATS = { status_narrative: 'status', health_override: 'status', health_override_reason: 'status', status: 'status', support_requests: 'status' };

r.patch('/programs/:pid', need('charter'), async (req, res) => {
  const { confirm_sections: confirmed = [], ...patch } = programPatchSchema.parse(req.body);
  await tx(async (t) => {
    const [before] = await t.query('SELECT * FROM programs WHERE id=$1', [req.pid]);
    const after = { ...patch };
    if ((after.start_date ?? before.start_date) > (after.end_date ?? before.end_date)) throw new HttpError(422, 'End date must not be before the start date');
    if (patch.assumptions) after.assumptions = { ...before.assumptions, ...patch.assumptions, fx: patch.assumptions.fx ?? before.assumptions.fx ?? {} };
    if (patch.status_narrative !== undefined && patch.status_narrative !== before.status_narrative) {
      after.narrative_updated_at = new Date().toISOString();
      after.narrative_updated_by = req.user.name;
    }
    const sets = []; const vals = [req.pid];
    const jsonCols = ['assumptions', 'support_requests'];
    for (const [k, v] of Object.entries(after)) {
      vals.push(jsonCols.includes(k) ? JSON.stringify(v) : v);
      sets.push(`${k}=$${vals.length}${jsonCols.includes(k) ? '::jsonb' : ''}`);
    }
    // editing a generated charter section marks it as reviewed
    const state = before.proposal_state || {};
    const touched = [...new Set([...CHARTER_FIELDS.filter((f) => patch[f] !== undefined && patch[f] !== before[f]), ...confirmed])].filter((f) => state.sections?.[f]);
    if (touched.length) {
      for (const f of touched) delete state.sections[f];
      vals.push(JSON.stringify(state)); sets.push(`proposal_state=$${vals.length}::jsonb`);
      if (confirmed.length) await logAudit(t, req.user, req.pid, { category: 'status', entity: 'Program', entity_id: req.pid, entity_name: before.name, summary: `Reviewed and confirmed charter section(s): ${confirmed.join(', ')}` });
    }
    if (sets.length) await t.query(`UPDATE programs SET ${sets.join(', ')}, updated_at=now() WHERE id=$1`, vals);
    await auditDiff(t, req.user, req.pid, {
      entity: 'Program', id: req.pid, name: before.name, before, after,
      cats: PROGRAM_CATS, skip: ['narrative_updated_at', 'narrative_updated_by'],
    });
  });
  res.json(await detail(req));
});

// ------------------------------------------------------------------ generic collections
const CATS = {
  tasks: { actual_hrs: 'progress', pct_complete: 'progress', status: 'status', notes: 'progress' },
  budget_lines: { actual_amount: 'progress', notes: 'progress' },
  raid_items: { status: 'status' },
  resources: {}, workstreams: {},
};

function collection(path, table, entity, schema, cap, cols, label, hooks = {}) {
  const patchSchema = schema.partial();
  r.post(`/programs/:pid/${path}`, need(cap), async (req, res) => {
    const data = schema.parse(req.body);
    const id = uid();
    await tx(async (t) => {
      if (hooks.before) await hooks.before(t, req, data, null);
      const names = ['id', 'program_id', ...cols];
      const vals = [id, req.pid, ...cols.map((c) => data[c] ?? null)];
      await t.query(`INSERT INTO ${table} (${names.join(',')}) VALUES (${names.map((_, i) => `$${i + 1}`).join(',')})`, vals);
      if (hooks.after) await hooks.after(t, req, id, data, null);
      await logAudit(t, req.user, req.pid, { category: 'material', entity, entity_id: id, entity_name: label(data), summary: `${entity} added: ${label(data)}` });
    });
    res.status(201).json(await detail(req));
  });
  r.patch(`/programs/:pid/${path}/:id`, need(cap), async (req, res) => {
    const patch = patchSchema.parse(req.body);
    await tx(async (t) => {
      const [before] = await t.query(`SELECT * FROM ${table} WHERE id=$1 AND program_id=$2`, [req.params.id, req.pid]);
      if (!before) throw new HttpError(404, `${entity} not found`);
      const merged = { ...before, ...patch };
      if (hooks.before) await hooks.before(t, req, merged, before, patch);
      const set = cols.filter((c) => patch[c] !== undefined || (hooks.derived || []).includes(c));
      const vals = [req.params.id, req.pid];
      const sets = set.map((c) => { vals.push(merged[c]); return `${c}=$${vals.length}`; });
      sets.push('is_proposed=false'); // a user edit counts as review of generated content
      if (sets.length) await t.query(`UPDATE ${table} SET ${sets.join(', ')} WHERE id=$1 AND program_id=$2`, vals);
      if (hooks.after) await hooks.after(t, req, req.params.id, merged, before, patch);
      const after = Object.fromEntries(set.map((c) => [c, merged[c]]));
      await auditDiff(t, req.user, req.pid, { entity, id: req.params.id, name: label(merged), before, after, cats: CATS[table] });
    });
    res.json(await detail(req));
  });
  r.delete(`/programs/:pid/${path}/:id`, need(cap), async (req, res) => {
    await tx(async (t) => {
      const [before] = await t.query(`SELECT * FROM ${table} WHERE id=$1 AND program_id=$2`, [req.params.id, req.pid]);
      if (!before) throw new HttpError(404, `${entity} not found`);
      if (hooks.beforeDelete) await hooks.beforeDelete(t, req, before);
      await t.query(`DELETE FROM ${table} WHERE id=$1 AND program_id=$2`, [req.params.id, req.pid]);
      await logAudit(t, req.user, req.pid, { category: 'material', entity, entity_id: req.params.id, entity_name: label(before), summary: `${entity} deleted: ${label(before)}` });
    });
    res.json(await detail(req));
  });
}

/** Workstream / resource / task ids must belong to this program. */
async function ownsAll(t, table, pid, ids) {
  const list = ids.filter(Boolean);
  if (!list.length) return;
  const ph = list.map((_, i) => `$${i + 2}`).join(',');
  const rows = await t.query(`SELECT id FROM ${table} WHERE program_id=$1 AND id IN (${ph})`, [pid, ...list]);
  if (rows.length !== new Set(list).size) throw new HttpError(422, 'A linked item does not belong to this program');
}

collection('workstreams', 'workstreams', 'Workstream', workstreamSchema, 'plan', ['name', 'lead', 'description'], (d) => d.name);
collection('resources', 'resources', 'Resource', resourceSchema, 'resources',
  ['name', 'role', 'rate', 'rate_currency', 'capacity_hrs_week', 'allocation_pct', 'chargeable', 'is_placeholder', 'rate_assumed'], (d) => d.name, {
    before: async (_t, _req, merged, before, patch) => { if (before && patch && patch.rate !== undefined) merged.rate_assumed = patch.rate_assumed ?? false; },
    derived: ['rate_assumed'],
  });
collection('budget', 'budget_lines', 'Budget line', budgetLineSchema, 'resources',
  ['category', 'description', 'planned_amount', 'actual_amount', 'forecast_override', 'is_assumption', 'notes'], (d) => d.category);

// ---- tasks (custom: dependencies, validation, cascade)
const TASK_COLS = ['type', 'name', 'parent_id', 'workstream_id', 'resource_id', 'start_date', 'end_date', 'estimate_hrs', 'actual_hrs', 'pct_complete', 'status', 'notes'];

function normaliseTask(d) {
  if (d.type === 'milestone') { d.end_date = d.start_date; d.estimate_hrs = 0; d.actual_hrs = 0; }
  if (d.status === 'complete') d.pct_complete = 100;
  else if (d.pct_complete >= 100) d.status = 'complete';
  else if (d.status === 'not_started' && (d.pct_complete > 0 || d.actual_hrs > 0)) d.status = 'in_progress';
  if (d.status === 'complete' && d.type === 'milestone') d.pct_complete = 100;
}

async function currentTasks(t, pid) {
  const tasks = await t.query('SELECT * FROM tasks WHERE program_id=$1', [pid]);
  const deps = await t.query('SELECT d.task_id, d.predecessor_id FROM task_deps d JOIN tasks x ON x.id=d.task_id WHERE x.program_id=$1', [pid]);
  const m = new Map(tasks.map((x) => [x.id, { ...x, predecessors: [] }]));
  for (const d of deps) m.get(d.task_id)?.predecessors.push(d.predecessor_id);
  return [...m.values()];
}

async function saveDeps(t, taskId, preds) {
  await t.query('DELETE FROM task_deps WHERE task_id=$1', [taskId]);
  for (const p of preds) await t.query('INSERT INTO task_deps (task_id,predecessor_id) VALUES ($1,$2)', [taskId, p]);
}

async function applyCascade(t, req, tasks, seedId) {
  const shifts = cascadeShifts(tasks, [seedId]);
  for (const s of shifts) {
    const old = tasks.find((x) => x.id === s.id);
    await t.query('UPDATE tasks SET start_date=$2, end_date=$3 WHERE id=$1', [s.id, s.start_date, s.end_date]);
    await logAudit(t, req.user, req.pid, {
      category: 'material', entity: 'Task', entity_id: s.id, entity_name: old.name, field: 'dates',
      old: `${old.start_date} → ${old.end_date}`, new: `${s.start_date} → ${s.end_date}`, summary: `Task "${old.name}" rescheduled automatically because a predecessor moved`,
    });
  }
  return shifts.length;
}

r.post('/programs/:pid/tasks', need('plan'), async (req, res) => {
  const data = taskSchema.parse(req.body);
  normaliseTask(data);
  const id = uid();
  let moved = 0;
  await tx(async (t) => {
    const tasks = await currentTasks(t, req.pid);
    const errs = validateTask(tasks, data);
    if (errs.length) throw new HttpError(422, 'Task is not valid', { errors: errs });
    await ownsAll(t, 'workstreams', req.pid, [data.workstream_id]);
    await ownsAll(t, 'resources', req.pid, [data.resource_id]);
    const [{ n }] = await t.query('SELECT count(*) AS n FROM tasks WHERE program_id=$1', [req.pid]);
    await t.query(
      `INSERT INTO tasks (id,program_id,${TASK_COLS.join(',')},sort) VALUES ($1,$2,${TASK_COLS.map((_, i) => `$${i + 3}`).join(',')},$${TASK_COLS.length + 3})`,
      [id, req.pid, ...TASK_COLS.map((c) => data[c] ?? null), Number(n)]);
    await saveDeps(t, id, data.predecessors);
    await logAudit(t, req.user, req.pid, { category: 'material', entity: 'Task', entity_id: id, entity_name: data.name, summary: `${data.type} added: ${data.name} (${data.start_date} → ${data.end_date})` });
    if (data.cascade) moved = await applyCascade(t, req, [...tasks, { id, ...data, predecessors: data.predecessors }], id);
  });
  res.status(201).json({ ...(await detail(req)), moved });
});

r.patch('/programs/:pid/tasks/:id', need('plan'), async (req, res) => {
  const patch = taskPatchSchema.parse(req.body);
  let moved = 0;
  await tx(async (t) => {
    const tasks = await currentTasks(t, req.pid);
    const before = tasks.find((x) => x.id === req.params.id);
    if (!before) throw new HttpError(404, 'Task not found');
    const merged = { ...before, ...patch, predecessors: patch.predecessors ?? before.predecessors };
    if (patch.type === 'milestone' || (merged.type === 'milestone' && patch.start_date)) merged.end_date = merged.start_date;
    normaliseTask(merged);
    const errs = validateTask(tasks, merged, before.id);
    if (errs.length) throw new HttpError(422, 'Task is not valid', { errors: errs });
    await ownsAll(t, 'workstreams', req.pid, [merged.workstream_id]);
    await ownsAll(t, 'resources', req.pid, [merged.resource_id]);
    const vals = [before.id, req.pid];
    const sets = TASK_COLS.map((c) => { vals.push(merged[c] ?? null); return `${c}=$${vals.length}`; });
    sets.push('is_proposed=false');
    await t.query(`UPDATE tasks SET ${sets.join(', ')} WHERE id=$1 AND program_id=$2`, vals);
    if (patch.predecessors) await saveDeps(t, before.id, merged.predecessors);

    const nameOf = async (table, id) => (id ? (await t.query(`SELECT name FROM ${table} WHERE id=$1`, [id]))[0]?.name || '' : '');
    const lookup = { resource_id: (id) => nameOf('resources', id), workstream_id: (id) => nameOf('workstreams', id), parent_id: (id) => nameOf('tasks', id) };
    const afterShown = {}, beforeShown = {};
    for (const c of TASK_COLS) {
      if (String(before[c] ?? '') === String(merged[c] ?? '')) continue;
      afterShown[c] = lookup[c] ? await lookup[c](merged[c]) : merged[c];
      beforeShown[c] = lookup[c] ? await lookup[c](before[c]) : before[c];
    }
    if (patch.predecessors && JSON.stringify([...before.predecessors].sort()) !== JSON.stringify([...merged.predecessors].sort())) {
      const nm = (ids) => ids.map((i) => tasks.find((x) => x.id === i)?.name).filter(Boolean).join(', ');
      afterShown.predecessors = nm(merged.predecessors); beforeShown.predecessors = nm(before.predecessors);
    }
    await auditDiff(t, req.user, req.pid, { entity: 'Task', id: before.id, name: merged.name, before: beforeShown, after: afterShown, cats: CATS.tasks });
    const dateChanged = before.start_date !== merged.start_date || before.end_date !== merged.end_date || patch.predecessors;
    if (merged.cascade !== false && patch.cascade !== false && dateChanged) {
      const fresh = await currentTasks(t, req.pid);
      moved = await applyCascade(t, req, fresh, before.id);
    }
  });
  res.json({ ...(await detail(req)), moved });
});

r.delete('/programs/:pid/tasks/:id', need('plan'), async (req, res) => {
  await tx(async (t) => {
    const [before] = await t.query('SELECT * FROM tasks WHERE id=$1 AND program_id=$2', [req.params.id, req.pid]);
    if (!before) throw new HttpError(404, 'Task not found');
    const [{ n }] = await t.query('SELECT count(*) AS n FROM tasks WHERE parent_id=$1', [before.id]);
    await t.query('DELETE FROM tasks WHERE id=$1 AND program_id=$2', [before.id, req.pid]);
    await logAudit(t, req.user, req.pid, { category: 'material', entity: 'Task', entity_id: before.id, entity_name: before.name, summary: `${before.type} deleted: ${before.name}${Number(n) ? ` (with ${n} child item(s))` : ''}` });
  });
  res.json(await detail(req));
});

// ---- RAID (links to tasks)
const RAID_COLS = ['type', 'title', 'description', 'owner', 'status', 'impact', 'likelihood', 'response', 'due_date', 'workstream_id'];
async function saveRaid(t, req, id, data) {
  await ownsAll(t, 'workstreams', req.pid, [data.workstream_id]);
  await ownsAll(t, 'tasks', req.pid, data.task_ids || []);
  if (data.type === 'decision' || data.type === 'assumption') { /* scoring optional */ }
  return true;
}
r.post('/programs/:pid/raid', need('raid'), async (req, res) => {
  const data = raidSchema.parse(req.body);
  const id = uid();
  await tx(async (t) => {
    await saveRaid(t, req, id, data);
    await t.query(`INSERT INTO raid_items (id,program_id,${RAID_COLS.join(',')}) VALUES ($1,$2,${RAID_COLS.map((_, i) => `$${i + 3}`).join(',')})`, [id, req.pid, ...RAID_COLS.map((c) => data[c] ?? null)]);
    for (const tid of new Set(data.task_ids)) await t.query('INSERT INTO raid_links (raid_id,task_id) VALUES ($1,$2)', [id, tid]);
    await logAudit(t, req.user, req.pid, { category: 'material', entity: 'RAID', entity_id: id, entity_name: data.title, summary: `${data.type} added: ${data.title}` });
  });
  res.status(201).json(await detail(req));
});
r.patch('/programs/:pid/raid/:id', need('raid'), async (req, res) => {
  const patch = raidSchema.partial().parse(req.body);
  await tx(async (t) => {
    const [before] = await t.query('SELECT * FROM raid_items WHERE id=$1 AND program_id=$2', [req.params.id, req.pid]);
    if (!before) throw new HttpError(404, 'Item not found');
    const merged = { ...before, ...patch };
    await saveRaid(t, req, before.id, { ...merged, task_ids: patch.task_ids || [] });
    const vals = [before.id, req.pid];
    const sets = RAID_COLS.map((c) => { vals.push(merged[c] ?? null); return `${c}=$${vals.length}`; });
    sets.push('is_proposed=false', 'updated_at=now()');
    await t.query(`UPDATE raid_items SET ${sets.join(', ')} WHERE id=$1 AND program_id=$2`, vals);
    if (patch.task_ids) {
      await t.query('DELETE FROM raid_links WHERE raid_id=$1', [before.id]);
      for (const tid of new Set(patch.task_ids)) await t.query('INSERT INTO raid_links (raid_id,task_id) VALUES ($1,$2)', [before.id, tid]);
    }
    const after = Object.fromEntries(RAID_COLS.filter((c) => patch[c] !== undefined).map((c) => [c, merged[c]]));
    await auditDiff(t, req.user, req.pid, { entity: 'RAID', id: before.id, name: merged.title, before, after, cats: CATS.raid_items });
  });
  res.json(await detail(req));
});
r.delete('/programs/:pid/raid/:id', need('raid'), async (req, res) => {
  await tx(async (t) => {
    const [before] = await t.query('SELECT * FROM raid_items WHERE id=$1 AND program_id=$2', [req.params.id, req.pid]);
    if (!before) throw new HttpError(404, 'Item not found');
    await t.query('DELETE FROM raid_items WHERE id=$1', [before.id]);
    await logAudit(t, req.user, req.pid, { category: 'material', entity: 'RAID', entity_id: before.id, entity_name: before.title, summary: `${before.type} deleted: ${before.title}` });
  });
  res.json(await detail(req));
});

// ------------------------------------------------------------------ delete program
r.delete('/programs/:pid', need('delete'), async (req, res) => {
  await tx(async (t) => {
    const [p] = await t.query('SELECT name, code FROM programs WHERE id=$1', [req.pid]);
    if (!p) throw new HttpError(404, 'Not found');
    // all child rows (plan, resources, budget, RAID, baselines, its audit trail) are removed by ON DELETE CASCADE
    await t.query('DELETE FROM programs WHERE id=$1', [req.pid]);
    await logAudit(t, req.user, null, { category: 'material', entity: 'Program', entity_id: req.pid, entity_name: p.name, summary: `Program deleted: ${p.code} ${p.name}` });
  });
  res.json({ ok: true });
});

// ------------------------------------------------------------------ baseline + audit
r.post('/programs/:pid/baseline', need('baseline'), async (req, res) => {
  const body = baselineSchema.parse(req.body);
  const out = await tx((t) => approveBaseline(t, req.user, req.pid, body));
  res.status(201).json({ ...(await detail(req)), baseline: out });
});

r.get('/programs/:pid/audit', async (req, res) => {
  const cat = String(req.query.category || '');
  const params = [req.pid];
  let where = 'program_id=$1';
  if (['baseline', 'material', 'status', 'progress'].includes(cat)) { params.push(cat); where += ` AND category=$${params.length}`; }
  const limit = Math.min(Number(req.query.limit) || 300, 1000);
  const rows = await query(`SELECT id, at, user_name, category, entity, entity_name, field, old_value, new_value, summary FROM audit_log WHERE ${where} ORDER BY at DESC, id DESC LIMIT ${limit}`, params);
  res.json({ entries: rows });
});

export default r;
