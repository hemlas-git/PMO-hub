// Vercel serverless entry. Runs the Express app with an in-memory database
// that is seeded with sample data on each cold start (nothing is persisted).
process.env.DEMO_MODE ??= 'true';
process.env.DATA_DIR ??= 'memory://pmo';
process.env.SEED_DEMO ??= 'true';

const { bootstrap, createApp } = await import('../src/server.js');
await bootstrap();
export default createApp();
