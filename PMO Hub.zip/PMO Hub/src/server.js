import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import express from 'express';
import { ZodError } from 'zod';
import { config } from './config.js';
import { initDb, migrate, query } from './db.js';
import { loadUser, requireAuth, csrfGuard, HttpError, hashPassword } from './auth.js';
import { authRouter, adminRouter } from './routes/auth.js';
import programs from './routes/programs.js';
import documents from './routes/documents.js';

export async function bootstrap() {
  await initDb();
  await migrate();
  const [{ n }] = await query('SELECT count(*) AS n FROM users');
  if (Number(n) > 0) return;
  const b = config.bootstrap;
  if (b.email && b.password) {
    await query('INSERT INTO users (id,email,name,password_hash,global_role) VALUES ($1,$2,$3,$4,$5)', [crypto.randomUUID(), b.email.toLowerCase(), b.name, await hashPassword(b.password), 'admin']);
    console.log(`Created bootstrap administrator ${b.email}. Remove BOOTSTRAP_ADMIN_* from the environment now.`);
  } else if (config.seedDemo) {
    const { seedDemo } = await import('./seed.js');
    await seedDemo();
    console.log('Demo data loaded. Sign in as admin@demo.test (password from DEMO_PASSWORD, default in .env.example).');
  } else {
    console.warn('No users exist. Run `npm run create-admin` to create the first administrator.');
  }
}

export function createApp() {
  const app = express();
  app.disable('x-powered-by');
  if (config.trustProxy) app.set('trust proxy', 1);

  app.use((req, res, next) => {
    res.set({
      'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'",
      'X-Content-Type-Options': 'nosniff',
      'Referrer-Policy': 'same-origin',
      'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
      ...(config.isProd ? { 'Strict-Transport-Security': 'max-age=31536000; includeSubDomains' } : {}),
    });
    if (req.path.startsWith('/api/')) res.set('Cache-Control', 'no-store');
    next();
  });
  app.use(express.json({ limit: '1mb' }));

  // Public demo: visitors can explore everything but cannot change data.
  if (config.demoReadonly) {
    app.use('/api', (req, res, next) => (['GET', 'HEAD', 'OPTIONS'].includes(req.method)
      ? next()
      : res.status(403).json({ error: 'This is a read-only public demo with sample data. Run it locally to create and edit programs.' })));
  }

  app.get('/healthz', (_req, res) => res.json({ ok: true }));

  const api = express.Router();
  api.use(loadUser, csrfGuard);
  api.use('/auth', authRouter);
  api.use('/admin', adminRouter);
  api.use('/documents', requireAuth, documents);
  api.use(requireAuth, programs);
  api.use((_req, _res, next) => next(new HttpError(404, 'Not found')));
  app.use('/api', api);

  const pub = path.join(config.root, 'public');
  app.use(express.static(pub, { maxAge: config.isProd ? '1h' : 0, index: 'index.html' }));
  app.use((req, res, next) => (req.method === 'GET' && !req.path.startsWith('/api') ? res.sendFile(path.join(pub, 'index.html')) : next()));

  // eslint-disable-next-line no-unused-vars
  app.use((err, _req, res, _next) => {
    if (err instanceof ZodError) {
      return res.status(422).json({ error: 'Please check the highlighted fields', errors: err.issues.map((i) => `${i.path.join('.') || 'input'}: ${i.message}`) });
    }
    if (err instanceof HttpError) return res.status(err.status).json({ error: err.message, ...err.extra });
    if (err?.type === 'entity.parse.failed') return res.status(400).json({ error: 'Invalid JSON' });
    if (err?.code === '23505') return res.status(409).json({ error: 'Duplicate value' });
    console.error(err);
    res.status(500).json({ error: 'Something went wrong' });
  });
  return app;
}

if (fileURLToPath(import.meta.url) === path.resolve(process.argv[1] || '')) {
  await bootstrap();
  createApp().listen(config.port, () => console.log(`PMO Hub listening on http://localhost:${config.port}`));
}
