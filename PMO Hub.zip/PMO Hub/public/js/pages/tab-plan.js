import { h, s, date, shortDate, num, bar, ragDot, proposedTag, dataTable, formModal, confirmDialog, toast, emptyState, STATUS_LABEL, TYPE_LABEL } from '../dom.js';
import { post, patch, del } from '../api.js';

const view = { mode: 'table', zoom: 'week' };
const F = { q: '', ws: '', status: '', owner: '', critical: false, overdue: false };
let sort = { key: null, dir: 1 };
let collapsed = new Set();
let collapsedFor = null;

const DAY = 864e5;
const dnum = (s_) => Math.round(new Date(`${s_}T00:00:00Z`).getTime() / DAY);

export async function render(ctx) {
  const d = ctx.data;
  const canEdit = d.caps.plan;
  if (collapsedFor !== ctx.id) { collapsedFor = ctx.id; collapsed = new Set(d.tasks.filter((t) => t.type === 'task' && t.children.length).map((t) => t.id)); }
  const byId = new Map(d.tasks.map((t) => [t.id, t]));
  const resName = new Map(d.resources.map((r) => [r.id, r.name]));
  const wsName = new Map(d.workstreams.map((w) => [w.id, w.name]));

  const filtersActive = () => F.q || F.ws || F.status || F.owner || F.critical || F.overdue;
  function rows() {
    const q = F.q.toLowerCase();
    if (filtersActive() || sort.key) {
      let list = d.tasks.filter((t) => (!q || t.name.toLowerCase().includes(q) || t.wbs.startsWith(q)) && (!F.ws || t.workstream_id === F.ws) && (!F.status || t.status === F.status)
        && (!F.owner || t.resource_id === F.owner) && (!F.critical || t.critical) && (!F.overdue || t.overdue));
      if (sort.key) {
        const g = { name: (t) => t.name.toLowerCase(), start: (t) => t.start, end: (t) => t.end, estimate: (t) => t.estimate, actual: (t) => t.actual, pct: (t) => t.pct, status: (t) => t.status, owner: (t) => resName.get(t.resource_id) || '', wbs: (t) => t.wbs.split('.').map((x) => x.padStart(3, '0')).join('.') }[sort.key];
        list = [...list].sort((a, b) => (g(a) > g(b) ? 1 : g(a) < g(b) ? -1 : 0) * sort.dir);
      }
      return { list, flat: true };
    }
    return { list: d.tasks.filter((t) => { for (let p = t.parent_id; p; p = byId.get(p)?.parent_id) if (collapsed.has(p)) return false; return true; }), flat: false };
  }

  const host = h('div');
  const toolbar = h('div', { class: 'card' });
  const issuesHost = h('div');
  const body = h('div');

  function drawIssues() {
    const iss = d.plan.issues;
    if (!iss.length) { issuesHost.replaceChildren(); return; }
    const errs = iss.filter((i) => i.level === 'error');
    issuesHost.replaceChildren(h('details', { class: `notice ${errs.length ? '' : ''}`, open: errs.length > 0 || null },
      h('summary', h('strong', `${errs.length} error(s), ${iss.length - errs.length} warning(s)`), ' in the plan'),
      h('ul', iss.slice(0, 40).map((i) => h('li', { class: i.level === 'error' ? 'bad' : '' }, (i.level === 'error' ? '✖ ' : '⚠ ') + i.message,
        i.taskId && canEdit ? [' ', h('button', { class: 'btn btn-link small', type: 'button', onClick: () => editTask(ctx, byId.get(i.taskId)) }, 'Fix')] : null))),
      iss.length > 40 ? h('p', { class: 'small' }, `…and ${iss.length - 40} more`) : null));
  }

  function drawToolbar() {
    const sel = (label, key, opts) => h('label', { class: 'field' }, label, h('select', { onChange: (e) => { F[key] = e.target.value; draw(); } }, opts.map(([v, l]) => h('option', { value: v, selected: F[key] === v }, l))));
    toolbar.replaceChildren(
      h('div', { class: 'card-head' }, h('h2', 'Program plan'),
        h('div', { class: 'row' },
          h('div', { class: 'seg', role: 'group', 'aria-label': 'View' }, [['table', 'Table'], ['gantt', 'Gantt']].map(([k, l]) => h('button', { type: 'button', 'aria-pressed': view.mode === k, onClick: () => { view.mode = k; drawToolbar(); draw(); } }, l))),
          view.mode === 'gantt' ? h('div', { class: 'seg', role: 'group', 'aria-label': 'Zoom' }, [['week', 'Weeks'], ['month', 'Months']].map(([k, l]) => h('button', { type: 'button', 'aria-pressed': view.zoom === k, onClick: () => { view.zoom = k; drawToolbar(); draw(); } }, l))) : null,
          canEdit ? h('button', { class: 'btn btn-primary', type: 'button', onClick: () => editTask(ctx, null) }, '+ Add item') : null)),
      h('div', { class: 'filters' },
        h('label', { class: 'field' }, 'Search', h('input', { type: 'search', value: F.q, placeholder: 'Name or WBS', onInput: (e) => { F.q = e.target.value; draw(); } })),
        sel('Workstream', 'ws', [['', 'All'], ...d.workstreams.map((w) => [w.id, w.name])]),
        sel('Status', 'status', [['', 'All'], ...Object.entries({ not_started: 'Not started', in_progress: 'In progress', complete: 'Complete', blocked: 'Blocked' })]),
        sel('Owner', 'owner', [['', 'All'], ...d.resources.filter((r) => !r.unassigned).map((r) => [r.id, r.name])]),
        h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: F.critical, onChange: (e) => { F.critical = e.target.checked; draw(); } }), 'Critical path only'),
        h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: F.overdue, onChange: (e) => { F.overdue = e.target.checked; draw(); } }), 'Overdue only'),
        h('button', { class: 'btn btn-sm', type: 'button', onClick: () => { Object.assign(F, { q: '', ws: '', status: '', owner: '', critical: false, overdue: false }); sort = { key: null, dir: 1 }; drawToolbar(); draw(); } }, 'Clear'),
        !filtersActive() && !sort.key ? h('span', { class: 'row' },
          h('button', { class: 'btn btn-sm', type: 'button', onClick: () => { collapsed = new Set(d.tasks.filter((t) => t.children.length).map((t) => t.id)); draw(); } }, 'Collapse all'),
          h('button', { class: 'btn btn-sm', type: 'button', onClick: () => { collapsed = new Set(); draw(); } }, 'Expand all')) : null));
  }

  function draw() {
    if (!d.tasks.length) { body.replaceChildren(h('div', { class: 'card' }, emptyState('No plan items yet', 'Add phases, tasks and milestones to build the plan.', canEdit ? h('button', { class: 'btn btn-primary', type: 'button', onClick: () => editTask(ctx, null) }, 'Add the first item') : null))); return; }
    const { list, flat } = rows();
    body.replaceChildren(view.mode === 'table' ? tableView(list, flat) : ganttView(list));
    drawIssues();
  }

  // ------------------------------------------------------------ table
  function tableView(list, flat) {
    const st = (n) => h('span', { class: `badge ${{ complete: 'b-done', blocked: 'b-red', in_progress: 'b-blue', not_started: 'b-grey' }[n.status]}` }, STATUS_LABEL[n.status]);
    const cols = [
      { key: 'wbs', label: 'WBS', sort: true, render: (n) => h('span', { class: 'muted small nowrap' }, n.wbs) },
      { key: 'name', label: 'Name', sort: true, render: (n) => h('div', { class: `wbs-name depth-${flat ? 0 : Math.min(n.depth, 3)} type-${n.type}` },
        n.children.length && !flat ? h('button', { class: 'tw', type: 'button', 'aria-expanded': !collapsed.has(n.id), 'aria-label': `${collapsed.has(n.id) ? 'Expand' : 'Collapse'} ${n.name}`, onClick: () => { collapsed.has(n.id) ? collapsed.delete(n.id) : collapsed.add(n.id); draw(); } }, collapsed.has(n.id) ? '▸' : '▾') : h('span', { class: 'tw' }),
        h('span', { class: 'nm' }, n.name), ' ', proposedTag(n.is_proposed), n.critical ? h('span', { class: 'crit', title: 'On the critical path (no float)' }, ' CRIT') : null) },
      { key: 'ws', label: 'Workstream', render: (n) => wsName.get(n.workstream_id) || '' },
      { key: 'owner', label: 'Owner', sort: true, render: (n) => resName.get(n.resource_id) || h('span', { class: 'muted' }, '—') },
      { key: 'start', label: 'Start', sort: true, render: (n) => h('span', { class: 'nowrap' }, shortDate(n.start)) },
      { key: 'end', label: 'End', sort: true, render: (n) => h('span', { class: `nowrap ${n.overdue ? 'bad' : ''}` }, shortDate(n.end), n.baseline && n.baseline.end !== n.end ? h('div', { class: 'small muted' }, `base ${shortDate(n.baseline.end)}`) : null) },
      { key: 'dur', label: 'Days', num: true, render: (n) => n.type === 'milestone' ? '' : n.duration },
      { key: 'estimate', label: 'Est h', num: true, sort: true, render: (n) => (n.type === 'milestone' ? '' : num(n.estimate, 1)) },
      { key: 'actual', label: 'Actual h', num: true, sort: true, render: (n) => (n.type === 'milestone' ? '' : num(n.actual, 1)) },
      { key: 'pct', label: '% done', sort: true, render: (n) => h('div', { style: { minWidth: '70px' } }, `${n.pct}%`, bar(n.pct, n.expectedPct)) },
      { key: 'status', label: 'Status', sort: true, render: (n) => h('div', st(n), ' ', n.done ? null : ragDot(n.rag, `Schedule ${n.rag}`)) },
      { key: 'deps', label: 'Depends on', render: (n) => n.predecessors.map((p) => byId.get(p)?.wbs).filter(Boolean).join(', ') },
      { key: 'act', label: '', render: (n) => (canEdit ? h('button', { class: 'btn btn-sm', type: 'button', onClick: () => editTask(ctx, n) }, 'Edit') : null) },
    ];
    return h('div', dataTable(cols, list, { sort, onSort: (k) => { sort = sort.key === k ? (sort.dir === 1 ? { key: k, dir: -1 } : { key: null, dir: 1 }) : { key: k, dir: 1 }; drawToolbar(); draw(); }, rowClass: (n) => `type-${n.type} ${n.overdue ? 'overdue' : ''}`, empty: 'No items match these filters.' }),
      h('p', { class: 'muted small' }, 'Phase and parent rows roll up dates, effort and progress from their children. Progress bars show a marker at the % expected by today. Dependencies are finish-to-start.'));
  }

  // ------------------------------------------------------------ gantt
  function ganttView(list) {
    if (!list.length) return h('div', { class: 'card' }, emptyState('Nothing to show', 'No items match these filters.'));
    const ROW = 28; const HEAD = 44;
    const ppd = view.zoom === 'week' ? 5 : 1.6;
    let minD = Infinity; let maxD = -Infinity;
    for (const n of d.tasks) { minD = Math.min(minD, dnum(n.start), n.baseline ? dnum(n.baseline.start) : Infinity); maxD = Math.max(maxD, dnum(n.end), n.baseline ? dnum(n.baseline.end) : -Infinity); }
    minD -= 7; maxD += 21;
    const X = (dn) => (dn - minD) * ppd;
    const W = Math.ceil((maxD - minD) * ppd);
    const H = HEAD + list.length * ROW + 10;
    const rowOf = new Map(list.map((n, i) => [n.id, i]));
    const todayN = dnum(d.today);

    const svg = s('svg', { class: 'gantt', width: W, height: H, role: 'img', 'aria-label': 'Gantt chart of the program plan' },
      s('defs', null, s('marker', { id: 'arr', viewBox: '0 0 8 8', refX: 7, refY: 4, markerWidth: 6, markerHeight: 6, orient: 'auto' }, s('path', { d: 'M0,0 L8,4 L0,8 z', fill: 'currentColor' }))),
      s('rect', { class: 'head', x: 0, y: 0, width: W, height: HEAD }));
    // axis
    const start = new Date(minD * DAY);
    const cur = new Date(Date.UTC(start.getUTCFullYear(), start.getUTCMonth(), 1));
    while (cur.getTime() / DAY < maxD) {
      const x = X(cur.getTime() / DAY);
      svg.append(s('line', { class: 'grid-line', x1: x, y1: 0, x2: x, y2: H }), s('text', { x: x + 4, y: 16 }, cur.toLocaleDateString(undefined, { month: 'short', year: 'numeric', timeZone: 'UTC' })));
      cur.setUTCMonth(cur.getUTCMonth() + 1);
    }
    if (view.zoom === 'week') {
      for (let dn = minD - (((minD + 3) % 7) + 7) % 7 + 7; dn < maxD; dn += 7) {
        svg.append(s('line', { class: 'grid-line', x1: X(dn), y1: 24, x2: X(dn), y2: H, opacity: 0.4 }), s('text', { x: X(dn) + 2, y: 38, 'font-size': 10 }, String(new Date(dn * DAY).getUTCDate())));
      }
    }
    list.forEach((n, i) => { if (i % 2) svg.append(s('rect', { class: 'row-alt', x: 0, y: HEAD + i * ROW, width: W, height: ROW, opacity: 0.5 })); });
    // dependencies first (under bars)
    for (const n of list) {
      const j = rowOf.get(n.id);
      for (const pid of n.predecessors) {
        const i = rowOf.get(pid);
        if (i === undefined) continue;
        const p = byId.get(pid);
        const x1 = X(dnum(p.end) + 1); const y1 = HEAD + i * ROW + ROW / 2; const x2 = X(dnum(n.start)); const y2 = HEAD + j * ROW + ROW / 2;
        const midx = Math.max(x1 + 6, Math.min(x2 - 6, x1 + 6));
        svg.append(s('path', { class: `dep ${p.critical && n.critical ? 'crit' : ''}`, d: `M${x1},${y1} H${midx} V${y2} H${Math.max(x2 - 1, midx)}`, 'marker-end': 'url(#arr)', stroke: 'currentColor' }));
      }
    }
    // bars
    for (const n of list) {
      const i = rowOf.get(n.id);
      const y = HEAD + i * ROW;
      const x = X(dnum(n.start)); const w = Math.max((dnum(n.end) - dnum(n.start) + 1) * ppd, 3);
      const tip = `${n.wbs} ${n.name}\n${n.start} → ${n.end}\n${n.type === 'milestone' ? '' : `${n.pct}% complete · ${num(n.estimate, 1)} h est`}${n.critical ? '\nCritical path' : ''}`;
      const click = canEdit ? () => editTask(ctx, n) : null;
      if (n.baseline && (n.baseline.start !== n.start || n.baseline.end !== n.end)) {
        svg.append(s('rect', { class: 'base-bar', x: X(dnum(n.baseline.start)), y: y + ROW - 8, width: Math.max((dnum(n.baseline.end) - dnum(n.baseline.start) + 1) * ppd, 3), height: 5 }));
      }
      if (n.type === 'milestone') {
        const cx = X(dnum(n.end)) + ppd / 2; const cy = y + ROW / 2 - 2;
        svg.append(s('polygon', { points: `${cx},${cy - 8} ${cx + 8},${cy} ${cx},${cy + 8} ${cx - 8},${cy}`, class: n.done ? 'bar-done' : n.rag === 'red' ? 'bar-red' : n.rag === 'amber' ? 'bar-amber' : 'bar-bg', onClick: click, style: { cursor: canEdit ? 'pointer' : 'default' } }, s('title', null, tip)));
      } else if (n.isSummary) {
        svg.append(s('rect', { class: 'bar-phase', x, y: y + 9, width: w, height: 7, rx: 2, onClick: click }, s('title', null, tip)),
          s('polygon', { class: 'bar-phase', points: `${x},${y + 9} ${x + 6},${y + 9} ${x},${y + 19}` }), s('polygon', { class: 'bar-phase', points: `${x + w},${y + 9} ${x + w - 6},${y + 9} ${x + w},${y + 19}` }));
      } else {
        const cls = n.done ? 'bar-done' : n.rag === 'red' ? 'bar-red' : n.rag === 'amber' ? 'bar-amber' : 'bar-bg';
        svg.append(s('rect', { class: cls, x, y: y + 5, width: w, height: 13, rx: 3, onClick: click, style: { cursor: canEdit ? 'pointer' : 'default' } }, s('title', null, tip)),
          n.pct > 0 && !n.done ? s('rect', { class: 'progress', x, y: y + 5, width: (w * n.pct) / 100, height: 13, rx: 3, 'pointer-events': 'none' }) : null);
        if (n.critical) svg.append(s('rect', { x: x - 1, y: y + 4, width: w + 2, height: 15, rx: 3, fill: 'none', stroke: 'var(--bar-red)', 'stroke-width': 1.5, 'pointer-events': 'none' }));
      }
    }
    svg.append(s('line', { class: 'today', x1: X(todayN), y1: HEAD - 6, x2: X(todayN), y2: H }), s('text', { x: X(todayN) + 3, y: 38, fill: 'var(--bar-red)', 'font-size': 10 }, 'Today'));

    const flatDepth = (n) => (filtersActive() || sort.key ? 0 : Math.min(n.depth, 3));
    const left = h('div', { style: { position: 'sticky', left: 0, zIndex: 2, background: 'var(--surface)', borderRight: '1px solid var(--border)', width: '280px', flex: 'none' } },
      h('div', { style: { height: `${HEAD}px`, background: 'var(--surface-2)', padding: '12px 10px', fontWeight: 700, fontSize: '.78rem', textTransform: 'uppercase', color: 'var(--muted)' } }, 'Item'),
      list.map((n, i) => h('div', { style: { height: `${ROW}px`, lineHeight: `${ROW}px`, padding: `0 8px 0 ${8 + (flatDepth(n) * 14)}px`, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', fontWeight: n.isSummary ? 700 : 400, background: i % 2 ? 'var(--surface-2)' : 'transparent', fontSize: '.88rem' }, title: n.name },
        n.children.length && !filtersActive() ? h('button', { class: 'tw', type: 'button', style: { all: 'unset', cursor: 'pointer', width: '16px', display: 'inline-block' }, 'aria-label': `Toggle ${n.name}`, onClick: () => { collapsed.has(n.id) ? collapsed.delete(n.id) : collapsed.add(n.id); draw(); } }, collapsed.has(n.id) ? '▸' : '▾') : h('span', { style: { display: 'inline-block', width: '16px' } }),
        n.type === 'milestone' ? '◆ ' : '', n.name)));
    return h('div', h('div', { class: 'gantt-wrap', style: { display: 'flex' } }, left, svg),
      h('div', { class: 'legend', style: { marginTop: '8px' } }, h('span', h('i', { style: { background: 'var(--bar-blue)' } }), 'On track'), h('span', h('i', { style: { background: 'var(--bar-amber)' } }), 'Behind'), h('span', h('i', { style: { background: 'var(--bar-red)' } }), 'Late / blocked'),
        h('span', h('i', { style: { background: '#8793a8' } }), 'Done'), h('span', '◆ Milestone'), h('span', { style: { color: 'var(--bar-red)' } }, '▭ Critical path'), h('span', '┄ Baseline (when moved)'), h('span', 'Arrows: finish-to-start dependencies')),
      criticalDates(d));
  }

  host.append(toolbar, issuesHost, body);
  drawToolbar();
  draw();
  return host;
}

function criticalDates(d) {
  const ms = d.plan.nextMilestones;
  return h('div', { class: 'card', style: { marginTop: '12px' } }, h('h2', 'Critical dates'),
    h('ul', { class: 'plain' },
      ms.map((m) => h('li', h('div', { class: 'row spread' }, h('span', '◆ ', m.name, m.critical ? h('span', { class: 'crit' }, ' CRITICAL PATH') : null), h('span', { class: m.overdue ? 'bad' : '' }, (m.overdue ? 'Overdue · ' : '') + date(m.end))))),
      h('li', h('div', { class: 'row spread' }, h('strong', 'Forecast program finish'), h('span', date(d.plan.forecastEnd), d.variance ? h('span', { class: d.variance.endSlip > 0 ? 'bad' : 'muted' }, `  (baseline ${date(d.variance.baseEnd)})`) : null)))));
}

// ---------------------------------------------------------------- edit dialog
function editTask(ctx, t) {
  const d = ctx.data;
  const isNew = !t;
  const isSummary = !!t?.children?.length;
  const cand = d.tasks.filter((x) => x.id !== t?.id && !x.isSummary && x.type !== 'phase');
  const parents = d.tasks.filter((x) => x.id !== t?.id && (x.type === 'phase' || x.type === 'task'));
  const lock = (f) => ({ ...f, disabled: isSummary, hint: isSummary ? 'Rolled up from child items' : f.hint });
  const fields = [
    { name: 'type', label: 'Type', type: 'select', value: t?.type || 'task', options: [['phase', 'Phase'], ['task', 'Task'], ['subtask', 'Subtask'], ['milestone', 'Milestone']] },
    { name: 'name', label: 'Name', value: t?.name, required: true },
    { name: 'parent_id', label: 'Parent', type: 'select', nullable: true, value: t?.parent_id || '', options: [['', '— none (top level) —'], ...parents.map((x) => [x.id, `${x.wbs} ${x.name}`])], hint: 'Subtasks sit under tasks; tasks under phases.' },
    { name: 'workstream_id', label: 'Workstream', type: 'select', nullable: true, value: t?.workstream_id || '', options: [['', '—'], ...d.workstreams.map((w) => [w.id, w.name])] },
    { name: 'resource_id', label: 'Owner / assignee', type: 'select', nullable: true, value: t?.resource_id || '', options: [['', '— unassigned —'], ...d.resources.filter((r) => !r.unassigned).map((r) => [r.id, `${r.name}${r.role ? ` (${r.role})` : ''}`])] },
    lock({ name: 'start_date', label: 'Start date', type: 'date', required: true, value: t?.start_date || d.program.start_date }),
    lock({ name: 'end_date', label: 'End date', type: 'date', required: true, value: t?.end_date || d.program.start_date }),
    lock({ name: 'estimate_hrs', label: 'Estimate (hours)', type: 'number', min: 0, value: t?.estimate_hrs ?? 0, nullable: false }),
    lock({ name: 'actual_hrs', label: 'Actual effort (hours)', type: 'number', min: 0, value: t?.actual_hrs ?? 0, nullable: false }),
    lock({ name: 'pct_complete', label: '% complete', type: 'number', min: 0, max: 100, step: 1, value: t?.pct_complete ?? 0, nullable: false }),
    lock({ name: 'status', label: 'Status', type: 'select', value: t?.status || 'not_started', options: Object.entries({ not_started: 'Not started', in_progress: 'In progress', complete: 'Complete', blocked: 'Blocked' }) }),
    { name: 'predecessors', label: 'Depends on (finish-to-start)', type: 'multiselect', span2: true, value: t?.predecessors || [], options: cand.map((x) => [x.id, `${x.wbs} ${x.name}`]), hint: 'Ctrl/Cmd-click to select several. Circular dependencies are rejected.' },
    { name: 'cascade', label: 'Move dependent items automatically if this finishes later', type: 'checkbox', value: true, span2: true },
    { name: 'notes', label: 'Notes', type: 'textarea', value: t?.notes, span2: true },
  ];
  formModal({
    title: isNew ? 'Add plan item' : `Edit ${TYPE_LABEL[t.type].toLowerCase()}: ${t.name}`, fields,
    intro: t?.is_proposed ? 'This item is a generated proposal. Saving counts as reviewing it.' : null,
    danger: !isNew ? { label: 'Delete', onClick: async () => {
      const ok = await confirmDialog({ title: 'Delete item?', message: `"${t.name}"${t.children.length ? ` and its ${t.children.length} child item(s)` : ''} will be removed. This is recorded in the change history.`, confirmLabel: 'Delete', danger: true });
      if (ok) await ctx.apply(await del(`/programs/${ctx.id}/tasks/${t.id}`));
    } } : null,
    onSubmit: async (v) => {
      const body = { ...v };
      if (isSummary) for (const k of ['start_date', 'end_date', 'estimate_hrs', 'actual_hrs', 'pct_complete', 'status']) delete body[k];
      if (v.end_date && v.start_date && v.end_date < v.start_date && !isSummary) throw Object.assign(new Error('End date cannot be before the start date'), {});
      const r = isNew ? await post(`/programs/${ctx.id}/tasks`, body) : await patch(`/programs/${ctx.id}/tasks/${t.id}`, body);
      await ctx.apply(r);
      if (r.moved) toast(`${r.moved} dependent item(s) rescheduled automatically`);
    },
  });
}
