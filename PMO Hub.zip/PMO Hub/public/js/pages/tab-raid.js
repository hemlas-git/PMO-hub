import { h, date, dataTable, formModal, confirmDialog, proposedTag, emptyState, STATUS_LABEL, TYPE_LABEL } from '../dom.js';
import { post, patch, del } from '../api.js';

const F = { q: '', type: '', status: 'open', priority: '', ws: '', owner: '' };
const TYPE_BADGE = { risk: 'b-red', issue: 'b-amber', assumption: 'b-grey', dependency: 'b-blue', decision: 'b-green' };

export async function render(ctx) {
  const d = ctx.data;
  const r = d.raid;
  const canEdit = d.caps.raid;
  const owners = [...new Set(r.items.map((i) => i.owner).filter(Boolean))].sort();

  const chip = (label, n, cls) => h('div', { class: 'kpi' }, h('div', { class: 'label' }, label), h('div', { class: `value ${n ? cls : ''}` }, n));
  const chips = h('div', { class: 'grid g4' }, chip('Open items', r.openCount, ''), chip('High priority', r.highCount, 'bad'), chip('Overdue decisions', r.overdueDecisions, 'bad'), chip('Overdue actions', r.overdueActions, 'bad'));

  const host = h('div');
  const sel = (label, key, opts) => h('label', { class: 'field' }, label, h('select', { onChange: (e) => { F[key] = e.target.value; draw(); } }, opts.map(([v, l]) => h('option', { value: v, selected: F[key] === v }, l))));
  const filters = h('div', { class: 'filters' },
    h('label', { class: 'field' }, 'Search', h('input', { type: 'search', value: F.q, onInput: (e) => { F.q = e.target.value; draw(); } })),
    sel('Type', 'type', [['', 'All'], ...Object.keys(TYPE_BADGE).map((k) => [k, TYPE_LABEL[k]])]),
    sel('Status', 'status', [['open', 'Open / in progress'], ['', 'All'], ['closed', 'Closed']]),
    sel('Priority', 'priority', [['', 'All'], ['high', 'High priority'], ['overdue', 'Overdue']]),
    sel('Workstream', 'ws', [['', 'All'], ...d.workstreams.map((w) => [w.id, w.name])]),
    sel('Owner', 'owner', [['', 'All'], ...owners.map((o) => [o, o])]));

  const cols = [
    { key: 'type', label: 'Type', render: (i) => h('span', { class: `badge ${TYPE_BADGE[i.type]}` }, TYPE_LABEL[i.type]) },
    { key: 'title', label: 'Item', render: (i) => h('div', h('strong', i.title), ' ', proposedTag(i.is_proposed), i.description ? h('div', { class: 'muted small' }, i.description) : null, i.response ? h('div', { class: 'small' }, h('em', 'Response: '), i.response) : null) },
    { key: 'owner', label: 'Owner', render: (i) => i.owner || h('span', { class: 'bad small' }, 'No owner') },
    { key: 'status', label: 'Status', render: (i) => h('span', { class: `badge ${i.status === 'closed' ? 'b-grey' : i.status === 'in_progress' ? 'b-blue' : 'b-amber'}` }, i.type === 'decision' && i.status === 'closed' ? 'Decided' : STATUS_LABEL[i.status]) },
    { key: 'score', label: 'Impact × likelihood', render: (i) => (i.score != null ? h('span', { class: `badge ${i.priority === 'high' ? 'b-red' : i.priority === 'medium' ? 'b-amber' : 'b-green'}`, title: `Impact ${i.impact ?? '—'}, likelihood ${i.likelihood ?? (i.type === 'issue' ? 'certain' : '—')}` }, `${i.priority === 'high' ? '■' : i.priority === 'medium' ? '▲' : '●'} ${i.score} · ${i.priority}`) : h('span', { class: 'muted' }, '—')) },
    { key: 'due', label: 'Due', render: (i) => (i.due_date ? h('span', { class: i.overdue ? 'bad nowrap' : 'nowrap' }, date(i.due_date), i.overdue ? h('div', { class: 'small' }, `${i.daysOverdue} days overdue`) : null) : h('span', { class: 'muted' }, '—')) },
    { key: 'links', label: 'Affects', render: (i) => h('div', { class: 'small' }, i.workstream_name ? h('div', h('strong', i.workstream_name)) : null, i.task_names.slice(0, 3).map((n) => h('div', n)), i.task_names.length > 3 ? `+${i.task_names.length - 3} more` : null) },
    { key: 'a', label: '', render: (i) => (canEdit ? h('button', { class: 'btn btn-sm', type: 'button', onClick: () => editItem(ctx, i) }, 'Edit') : null) },
  ];

  function draw() {
    const q = F.q.toLowerCase();
    const list = r.items.filter((i) => (!q || `${i.title} ${i.description} ${i.owner}`.toLowerCase().includes(q)) && (!F.type || i.type === F.type)
      && (F.status === '' || (F.status === 'open' ? i.open : !i.open)) && (!F.priority || (F.priority === 'high' ? i.priority === 'high' && i.open : i.overdue))
      && (!F.ws || i.workstream_id === F.ws) && (!F.owner || i.owner === F.owner))
      .sort((a, b) => (b.overdue - a.overdue) || ((b.score ?? -1) - (a.score ?? -1)) || (a.due_date || '9').localeCompare(b.due_date || '9'));
    host.replaceChildren(dataTable(cols, list, { rowClass: (i) => (i.overdue ? 'overdue' : ''), empty: r.items.length ? 'No items match these filters.' : null }),
      !r.items.length ? emptyState('The RAID log is empty', 'Record risks, assumptions, issues, dependencies and decisions.') : null,
      h('p', { class: 'muted small' }, `${list.length} of ${r.items.length} items. Score = impact × likelihood (issues use impact × 5); 15+ is high priority. Overdue items are marked with a red edge.`));
  }
  draw();

  // 5x5 matrix of open risks
  const cell = (imp, lik) => {
    const n = r.matrix[`${imp}-${lik}`] || 0;
    const sc = imp * lik;
    return h('div', { class: sc >= 15 ? 'm-high' : sc >= 8 ? 'm-med' : 'm-low', title: `Impact ${imp}, likelihood ${lik}: ${n} open risk(s)`, 'aria-label': `Impact ${imp} likelihood ${lik}: ${n}` }, n || '');
  };
  const matrix = h('div', { class: 'card' }, h('h2', 'Open risk matrix'),
    h('div', { class: 'matrix' }, [5, 4, 3, 2, 1].flatMap((imp) => [h('div', { class: 'ax' }, imp), ...[1, 2, 3, 4, 5].map((lik) => cell(imp, lik))]), h('div', { class: 'ax' }), [1, 2, 3, 4, 5].map((l) => h('div', { class: 'ax' }, l))),
    h('p', { class: 'muted small' }, 'Rows: impact (5 = severe). Columns: likelihood (5 = almost certain).'));

  return h('div', chips, h('div', { class: 'grid g-main', style: { marginTop: '16px' } },
    h('div', { class: 'card' }, h('div', { class: 'card-head' }, h('h2', 'RAID & decisions'), canEdit ? h('button', { class: 'btn btn-primary btn-sm', type: 'button', onClick: () => editItem(ctx, null) }, '+ Add item') : null), filters, host),
    h('div', matrix)));
}

function editItem(ctx, i) {
  const d = ctx.data;
  const lvl = [['', '—'], [1, '1 – Very low'], [2, '2 – Low'], [3, '3 – Medium'], [4, '4 – High'], [5, '5 – Very high']];
  formModal({
    title: i ? `Edit ${TYPE_LABEL[i.type].toLowerCase()}` : 'Add RAID item',
    intro: i?.is_proposed ? 'This item is a generated proposal. Saving counts as reviewing it.' : null,
    fields: [
      { name: 'type', label: 'Type', type: 'select', value: i?.type || 'risk', options: Object.keys(TYPE_BADGE).map((k) => [k, TYPE_LABEL[k]]) },
      { name: 'status', label: 'Status', type: 'select', value: i?.status || 'open', options: [['open', 'Open'], ['in_progress', 'In progress'], ['closed', 'Closed / decided']] },
      { name: 'title', label: 'Title', value: i?.title, required: true, span2: true },
      { name: 'description', label: 'Description', type: 'textarea', value: i?.description, span2: true },
      { name: 'owner', label: 'Owner', value: i?.owner }, { name: 'due_date', label: 'Due date', type: 'date', value: i?.due_date },
      { name: 'impact', label: 'Impact', type: 'select', nullable: true, value: i?.impact ?? '', options: lvl, hint: 'Risks, issues, dependencies' },
      { name: 'likelihood', label: 'Likelihood', type: 'select', nullable: true, value: i?.likelihood ?? '', options: lvl, hint: 'Risks and dependencies (issues are already happening)' },
      { name: 'response', label: 'Response / action / decision taken', type: 'textarea', value: i?.response, span2: true },
      { name: 'workstream_id', label: 'Affected workstream', type: 'select', nullable: true, value: i?.workstream_id || '', options: [['', '—'], ...d.workstreams.map((w) => [w.id, w.name])] },
      { name: 'task_ids', label: 'Affected plan items', type: 'multiselect', span2: true, value: i?.task_ids || [], options: d.tasks.filter((t) => t.type !== 'phase').map((t) => [t.id, `${t.wbs} ${t.name}`]), hint: 'Ctrl/Cmd-click to select several.' },
    ],
    danger: i ? { label: 'Delete', onClick: async () => { if (await confirmDialog({ title: 'Delete item?', message: i.title, confirmLabel: 'Delete', danger: true })) await ctx.apply(await del(`/programs/${ctx.id}/raid/${i.id}`)); } } : null,
    onSubmit: async (v) => {
      if (v.type === 'risk' && (!v.impact || !v.likelihood)) throw new Error('Risks need both impact and likelihood so they can be prioritised');
      ctx.apply(i ? await patch(`/programs/${ctx.id}/raid/${i.id}`, v) : await post(`/programs/${ctx.id}/raid`, v));
    },
  });
}
