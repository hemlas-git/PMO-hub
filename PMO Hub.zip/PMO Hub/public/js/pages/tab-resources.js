import { h, money, num, signed, bar, dataTable, formModal, confirmDialog, proposedTag, emptyState } from '../dom.js';
import { post, patch, del } from '../api.js';

const view = { group: 'person', measure: 'hours', kind: 'planned' };
const MONTHS = (k) => new Date(`${k}-01T00:00:00Z`).toLocaleDateString(undefined, { month: 'short', year: '2-digit', timeZone: 'UTC' });

export async function render(ctx) {
  const d = ctx.data;
  const cur = d.program.currency;
  const canEdit = d.caps.resources;
  const b = d.budget;
  const M = (n) => money(n, cur);

  // ---------------------------------------------------------------- flags
  const flags = d.resource_flags.length
    ? h('div', { class: 'card' }, h('h2', 'Flags'), h('ul', d.resource_flags.map((f) => h('li', { class: f.level === 'error' ? 'bad' : 'warn' }, (f.level === 'error' ? '✖ ' : '⚠ ') + f.message))))
    : null;

  // ---------------------------------------------------------------- assumptions
  const A = d.assumptions;
  const fxText = Object.entries(A.fx).map(([k, v]) => `${k}=${v}`).join(', ') || 'none';
  const assumptions = h('div', { class: 'card' }, h('div', { class: 'card-head' }, h('h2', 'Calculation assumptions'), canEdit ? h('button', { class: 'btn btn-sm', type: 'button', onClick: () => assumptionsDialog(ctx) }, 'Edit') : null),
    h('ul', { class: 'small' },
      h('li', h('strong', 'Currency: '), `${cur} (program currency). Rates in another currency convert using FX: ${fxText}.`),
      h('li', h('strong', 'Effort timing: '), 'task estimates and actuals are spread evenly over working days (Mon–Fri) between the task dates, so changing dates or estimates moves effort between periods.'),
      h('li', h('strong', 'Cost: '), 'hours × the person\'s hourly rate. People without a rate cost nothing and are flagged.'),
      h('li', h('strong', 'Estimate to complete: '), d.forecast_methods[A.forecast_method]),
      h('li', h('strong', 'Forecast at completion: '), 'actual spend + estimate to complete (labour from the method above; non-labour = planned − actual unless overridden).'),
      h('li', h('strong', 'Contingency: '), `${A.contingency_pct}% of planned cost. It is part of the plan budget but not of the forecast.`),
      h('li', h('strong', 'Over-allocation: '), 'planned hours in any week above capacity × allocation %.')));

  // ---------------------------------------------------------------- budget summary
  const v = d.variance;
  const sumRows = [
    ['Labour', b.labour.planned, b.labour.actual, b.labour.etc, b.labour.forecast],
    ['Non-labour', b.nonLabour.planned, b.nonLabour.actual, b.nonLabour.etc, b.nonLabour.forecast],
  ];
  const sumCols = [
    { key: 'l', label: '', render: (r) => (r.total ? h('strong', r[0]) : r[0]) }, { key: 'p', label: 'Planned', num: true, render: (r) => M(r[1]) }, { key: 'a', label: 'Actual to date', num: true, render: (r) => M(r[2]) },
    { key: 'e', label: 'Estimate to complete', num: true, render: (r) => M(r[3]) }, { key: 'f', label: 'Forecast at completion', num: true, render: (r) => M(r[4]) },
    { key: 'v', label: 'Variance (plan − forecast)', num: true, render: (r) => h('span', { class: r[1] - r[4] < -0.5 ? 'bad' : 'good' }, signed(r[1] - r[4])) },
  ];
  const sumData = [...sumRows, Object.assign(['Total cost', b.plannedCost, b.actual, b.etc, b.forecast], { total: true })];
  const budgetCard = h('div', { class: 'card' }, h('div', { class: 'card-head' }, h('h2', 'Budget summary'), h('span', { class: 'muted small' }, `All amounts in ${cur}`)),
    dataTable(sumCols, sumData, { rowClass: (r) => (r.total ? 'total' : '') }),
    h('div', { class: 'grid g4', style: { marginTop: '12px' } },
      kpi('Approved budget', b.approved ? M(b.approved) : 'Not set', v ? `Baseline v${v.version}: ${M(v.baseBudget)}` : 'No baseline'),
      kpi('Plan budget incl. contingency', M(b.plannedBudget), `${M(b.contingency)} contingency (${b.contingency_pct}%)`, b.approved && b.plannedBudget > b.approved ? 'bad' : ''),
      kpi('Forecast vs approved', b.approved ? `${b.variance >= 0 ? '' : '−'}${M(Math.abs(b.variance))}` : '—', b.approved ? `${b.variance >= 0 ? 'under' : 'over'} budget (${num(Math.abs(b.variancePct), 1)}%)` : '', b.variance < 0 ? 'bad' : 'good'),
      kpi('Plan cost vs baseline', v ? signed(v.costDelta) : '—', v ? `Baseline plan cost ${M(v.baseCost)}; effort ${signed(v.hoursDelta, 0)} h` : '', v && v.costDelta > 0 ? 'warn' : '')),
    b.missingRateHours ? h('div', { class: 'notice', style: { marginTop: '12px' } }, `${num(b.missingRateHours)} planned hours have no usable rate, so labour cost is understated.`) : null);

  // ---------------------------------------------------------------- resources table
  const people = d.resources.filter((r) => !r.unassigned || r.planned_hrs > 0);
  const resCols = [
    { key: 'name', label: 'Person / role', render: (r) => h('div', h('strong', r.name), ' ', r.is_placeholder ? h('span', { class: 'badge b-grey' }, 'TBC') : null, proposedTag(r.is_proposed), h('div', { class: 'muted small' }, r.role)) },
    { key: 'rate', label: 'Hourly rate', num: true, render: (r) => (r.unassigned ? '' : r.rate == null ? h('span', { class: 'badge b-red' }, r.chargeable ? '✖ Missing' : 'n/a') : h('span', { class: r.rate_issue ? 'bad' : '' }, `${num(r.rate, 2)} ${r.rate_currency || cur}`, r.rate_assumed ? h('div', { class: 'tag-proposed' }, 'assumed') : null, r.rate_issue === 'missing_fx' ? h('div', { class: 'small bad' }, 'No FX rate') : null)) },
    { key: 'cap', label: 'Capacity', num: true, render: (r) => (r.unassigned ? '' : `${r.capacity_hrs_week} h/wk × ${r.allocation_pct}%`) },
    { key: 'planned', label: 'Planned h', num: true, render: (r) => num(r.planned_hrs) }, { key: 'actual', label: 'Actual h', num: true, render: (r) => num(r.actual_hrs) },
    { key: 'etc', label: 'To go h', num: true, render: (r) => num(r.etc_hrs) },
    { key: 'pc', label: 'Planned cost', num: true, render: (r) => M(r.planned_cost) }, { key: 'ac', label: 'Actual cost', num: true, render: (r) => M(r.actual_cost) }, { key: 'fc', label: 'Forecast cost', num: true, render: (r) => M(r.forecast_cost) },
    { key: 'util', label: 'Allocation', render: (r) => (r.unassigned ? h('span', { class: 'badge b-amber' }, 'Unassigned') : r.over_allocated ? h('span', { class: 'badge b-red', title: r.overWeeks.slice(0, 6).map((w) => `Week of ${w.week}: ${w.hours}h vs ${w.capacity}h`).join('\n') }, `■ Over: peak ${r.peak_util}% (${r.overWeeks.length} wk)`) : h('span', { class: 'badge b-green' }, `● OK · peak ${r.peak_util ?? 0}%`)) },
    { key: 'act', label: '', render: (r) => (canEdit && !r.unassigned ? h('button', { class: 'btn btn-sm', type: 'button', onClick: () => editResource(ctx, r) }, 'Edit') : null) },
  ];
  const t = d.resource_totals;
  const resCard = h('div', { class: 'card' }, h('div', { class: 'card-head' }, h('h2', 'Resources, rates & capacity'), canEdit ? h('button', { class: 'btn btn-sm btn-primary', type: 'button', onClick: () => editResource(ctx, null) }, '+ Add resource') : null),
    people.length ? dataTable(resCols, people) : emptyState('No resources yet', 'Add people or roles, with hourly rates and capacity, then assign them to plan items.'),
    h('p', { class: 'muted small' }, `Totals: ${num(t.planned_hrs)} h planned · ${num(t.actual_hrs)} h actual · ${num(t.etc_hrs)} h to go · labour forecast ${M(t.forecast_cost)}`));

  // ---------------------------------------------------------------- period view
  const periodHost = h('div');
  function drawPeriods() {
    const rowsSrc = view.group === 'person' ? d.resources.filter((r) => r.planned_hrs || r.actual_hrs) : d.resource_roles;
    const key = { planned: 'planned', actual: 'actual', forecast: 'forecast' }[view.kind];
    const field = view.measure === 'hours' ? key : `${key}Cost`;
    const cols = [{ key: 'n', label: view.group === 'person' ? 'Person' : 'Role', render: (r) => (r.total ? h('strong', 'Total') : r.name || r.role) },
      ...d.periods.map((p) => ({ key: p, label: MONTHS(p), num: true, render: (r) => {
        const c = r.months[p]?.[field] || 0;
        if (view.group === 'person' && view.measure === 'hours' && view.kind === 'planned' && r.months[p]?.util != null && c > 0) {
          const u = r.months[p].util;
          return h('span', { class: `util ${u > 100 ? 'u-over' : u > 85 ? 'u-high' : 'u-ok'}`, title: `${u}% of ${r.months[p].capacity} h capacity` }, num(c));
        }
        return c ? (view.measure === 'hours' ? num(c) : money(c, cur, true)) : h('span', { class: 'muted' }, '·');
      } })),
      { key: 't', label: 'Total', num: true, render: (r) => { const sum = d.periods.reduce((a, p) => a + (r.months[p]?.[field] || 0), 0); return view.measure === 'hours' ? num(sum) : money(sum, cur, true); } }];
    const total = { total: true, months: Object.fromEntries(d.periods.map((p) => [p, Object.fromEntries(['planned', 'actual', 'forecast', 'plannedCost', 'actualCost', 'forecastCost'].map((k) => [k, rowsSrc.reduce((a, r) => a + (r.months[p]?.[k] || 0), 0)]))])) };
    const seg = (name, opts) => h('div', { class: 'seg', role: 'group', 'aria-label': name }, opts.map(([k, l]) => h('button', { type: 'button', 'aria-pressed': view[name] === k, onClick: () => { view[name] = k; drawPeriods(); } }, l)));
    periodHost.replaceChildren(h('div', { class: 'row', style: { marginBottom: '10px' } }, seg('group', [['person', 'By person'], ['role', 'By role']]), seg('measure', [['hours', 'Hours'], ['cost', 'Cost']]), seg('kind', [['planned', 'Planned'], ['actual', 'Actual'], ['forecast', 'Forecast (actual + to go)']])),
      dataTable(cols, [...rowsSrc, total], { rowClass: (r) => (r.total ? 'total' : '') }),
      view.group === 'person' && view.measure === 'hours' && view.kind === 'planned' ? h('p', { class: 'muted small' }, 'Shading: green ≤ 85% of monthly capacity, amber 85–100%, red over capacity. Weekly over-allocation is flagged in the table above.') : null);
  }
  const periodCard = h('div', { class: 'card' }, h('h2', 'Effort & cost by period'), periodHost);
  drawPeriods();

  // ---------------------------------------------------------------- non-labour lines
  const lineCols = [
    { key: 'category', label: 'Category', render: (l) => h('div', h('strong', l.category), ' ', l.is_assumption ? h('span', { class: 'tag-proposed' }, 'assumption') : null, proposedTag(l.is_proposed), l.description ? h('div', { class: 'muted small' }, l.description) : null) },
    { key: 'p', label: 'Planned', num: true, render: (l) => M(l.planned_amount) }, { key: 'a', label: 'Actual', num: true, render: (l) => M(l.actual_amount) },
    { key: 'e', label: 'To complete', num: true, render: (l) => h('span', l.forecast_override != null ? { title: 'Manual override' } : null, M(l.etc), l.forecast_override != null ? ' ✎' : '') },
    { key: 'f', label: 'Forecast', num: true, render: (l) => M(l.forecast) },
    { key: 'v', label: 'Variance', num: true, render: (l) => h('span', { class: l.variance < -0.5 ? 'bad' : '' }, signed(l.variance)) },
    { key: 'x', label: '', render: (l) => (canEdit ? h('button', { class: 'btn btn-sm', type: 'button', onClick: () => editLine(ctx, l) }, 'Edit') : null) },
  ];
  const linesCard = h('div', { class: 'card' }, h('div', { class: 'card-head' }, h('h2', 'Non-labour budget lines'), canEdit ? h('button', { class: 'btn btn-sm btn-primary', type: 'button', onClick: () => editLine(ctx, null) }, '+ Add line') : null),
    b.lines.length ? dataTable(lineCols, b.lines) : emptyState('No non-labour lines', 'Add software, equipment, travel, contractors and other costs.'));

  return h('div', flags, assumptions, budgetCard, resCard, periodCard, linesCard);
}

const kpi = (label, value, sub, cls = '') => h('div', { class: 'kpi' }, h('div', { class: 'label' }, label), h('div', { class: `value ${cls}` }, value), sub ? h('div', { class: 'sub' }, sub) : null);

function assumptionsDialog(ctx) {
  const A = ctx.data.assumptions;
  formModal({
    title: 'Calculation assumptions', submitLabel: 'Save and recalculate',
    intro: 'Changes recalculate every forecast, variance and portfolio figure immediately and are recorded in the change history.',
    fields: [
      { name: 'contingency_pct', label: 'Contingency (% of planned cost)', type: 'number', min: 0, max: 100, value: A.contingency_pct, nullable: false },
      { name: 'forecast_method', label: 'Estimate-to-complete method', type: 'select', value: A.forecast_method, options: Object.entries(ctx.data.forecast_methods), span2: true },
      { name: 'fx', label: 'FX rates to program currency', type: 'textarea', rows: 2, span2: true, value: Object.entries(A.fx).map(([k, x]) => `${k}=${x}`).join('\n'), hint: `One per line, e.g. EUR=1.08 means 1 EUR = 1.08 ${ctx.data.program.currency}` },
    ],
    onSubmit: async (v) => {
      const fx = {};
      for (const line of v.fx.split(/[\n,]+/).map((x) => x.trim()).filter(Boolean)) {
        const m = line.match(/^([A-Za-z]{3})\s*[=:]\s*([\d.]+)$/);
        if (!m) throw new Error(`Could not read FX line "${line}". Use the form EUR=1.08`);
        fx[m[1].toUpperCase()] = Number(m[2]);
      }
      ctx.apply(await patch(`/programs/${ctx.id}`, { assumptions: { contingency_pct: v.contingency_pct, forecast_method: v.forecast_method, fx } }));
    },
  });
}

function editResource(ctx, r) {
  const cur = ctx.data.program.currency;
  formModal({
    title: r ? `Edit ${r.name}` : 'Add resource',
    fields: [
      { name: 'name', label: 'Name', value: r?.name, required: true }, { name: 'role', label: 'Role', value: r?.role },
      { name: 'rate', label: 'Hourly rate', type: 'number', min: 0, value: r?.rate, hint: 'Leave blank if unknown — it will be flagged.' },
      { name: 'rate_currency', label: 'Rate currency', value: r?.rate_currency, placeholder: cur, hint: `Blank = ${cur}. Other currencies need an FX rate in the assumptions.` },
      { name: 'capacity_hrs_week', label: 'Capacity (hours/week)', type: 'number', min: 0, max: 80, value: r?.capacity_hrs_week ?? 40, nullable: false },
      { name: 'allocation_pct', label: 'Allocated to this program (%)', type: 'number', min: 0, max: 100, step: 1, value: r?.allocation_pct ?? 100, nullable: false },
      { name: 'chargeable', label: 'Chargeable (costs count towards the budget)', type: 'checkbox', value: r?.chargeable ?? true },
      { name: 'is_placeholder', label: 'Placeholder / to be confirmed', type: 'checkbox', value: r?.is_placeholder ?? false },
    ],
    danger: r ? { label: 'Delete', onClick: async () => { if (await confirmDialog({ title: 'Delete resource?', message: `Tasks assigned to ${r.name} become unassigned.`, confirmLabel: 'Delete', danger: true })) await ctx.apply(await del(`/programs/${ctx.id}/resources/${r.id}`)); } } : null,
    onSubmit: async (v) => { ctx.apply(r ? await patch(`/programs/${ctx.id}/resources/${r.id}`, v) : await post(`/programs/${ctx.id}/resources`, v)); },
  });
}

function editLine(ctx, l) {
  formModal({
    title: l ? `Edit ${l.category}` : 'Add budget line',
    fields: [
      { name: 'category', label: 'Category', value: l?.category, required: true }, { name: 'description', label: 'Description', value: l?.description },
      { name: 'planned_amount', label: 'Planned', type: 'number', min: 0, value: l?.planned_amount ?? 0, nullable: false },
      { name: 'actual_amount', label: 'Actual spend to date', type: 'number', min: 0, value: l?.actual_amount ?? 0, nullable: false },
      { name: 'forecast_override', label: 'Estimate to complete (override)', type: 'number', min: 0, value: l?.forecast_override, hint: 'Blank = planned − actual.' },
      { name: 'is_assumption', label: 'This amount is an assumption/estimate', type: 'checkbox', value: l?.is_assumption ?? false },
      { name: 'notes', label: 'Notes', type: 'textarea', value: l?.notes, span2: true },
    ],
    danger: l ? { label: 'Delete', onClick: async () => { if (await confirmDialog({ title: 'Delete budget line?', confirmLabel: 'Delete', danger: true })) await ctx.apply(await del(`/programs/${ctx.id}/budget/${l.id}`)); } } : null,
    onSubmit: async (v) => { ctx.apply(l ? await patch(`/programs/${ctx.id}/budget/${l.id}`, v) : await post(`/programs/${ctx.id}/budget`, v)); },
  });
}
