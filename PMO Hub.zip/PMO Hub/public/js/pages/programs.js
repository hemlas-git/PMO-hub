import { h, date, healthBadge, bar, dataTable, emptyState } from '../dom.js';
import { get } from '../api.js';
import { deleteProgramDialog } from './delete-program.js';
import { toast } from '../dom.js';

export async function render() {
  const { programs, can_create: canCreate } = await get('/portfolio');
  const head = h('div', { class: 'page-head' }, h('div', h('h1', 'Programs'), h('p', { class: 'muted' }, 'All programs you can access.')),
    canCreate ? h('a', { class: 'btn btn-primary', href: '#/programs/new' }, '+ New program') : null);
  if (!programs.length) {
    return h('div', head, h('div', { class: 'card' }, emptyState('No programs yet', 'Create a program from a guided form. A draft charter, plan, budget and RAID log are proposed for you to review.',
      canCreate ? h('a', { class: 'btn btn-primary', href: '#/programs/new' }, 'Create a program') : null)));
  }
  const cols = [
    { key: 'name', label: 'Program', render: (p) => h('div', h('a', { href: `#/p/${p.id}/overview` }, h('strong', p.name)), h('div', { class: 'muted small' }, p.code)) },
    { key: 'manager', label: 'Manager', render: (p) => p.manager },
    { key: 'health', label: 'Health', render: (p) => healthBadge(p.health) },
    { key: 'progress', label: 'Progress', render: (p) => h('div', { style: { minWidth: '100px' } }, `${p.progress}%`, bar(p.progress, p.planned_progress)) },
    { key: 'dates', label: 'Dates', render: (p) => h('span', { class: 'nowrap small' }, `${date(p.start_date)} → ${date(p.forecast_end)}`) },
    { key: 'open', label: '', render: (p) => h('div', { class: 'row' }, h('a', { class: 'btn btn-sm', href: `#/p/${p.id}/overview` }, 'Open'), p.can_delete ? h('button', { class: 'btn btn-sm btn-danger', type: 'button', onClick: () => deleteProgramDialog(p, () => { toast('Program deleted'); location.reload(); }) }, 'Delete') : null) },
  ];
  return h('div', head, h('div', { class: 'card' }, dataTable(cols, programs, { onRow: (p) => { location.hash = `#/p/${p.id}/overview`; } })));
}
