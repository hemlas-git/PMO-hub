import { h, errorBox } from './dom.js';
import { get, post, getDisplayName, setDisplayName } from './api.js';

export const state = { user: null, loginRequired: false };
const app = document.getElementById('app');
let token = 0;

export const navigate = (hash) => { if (location.hash === hash) route(); else location.hash = hash; };

async function boot() {
  try { const me = await get('/auth/me'); state.user = me.user; state.loginRequired = !!me.login_required; } catch { state.user = null; }
  window.addEventListener('hashchange', route);
  window.addEventListener('pmo:unauth', () => { state.user = null; route(); });
  route();
}

function loginView() {
  const err = h('div');
  const email = h('input', { type: 'email', required: true, autocomplete: 'username', id: 'email' });
  const pw = h('input', { type: 'password', required: true, autocomplete: 'current-password', id: 'pw' });
  const btn = h('button', { class: 'btn btn-primary', type: 'submit' }, 'Sign in');
  const form = h('form', { onSubmit: async (e) => {
    e.preventDefault(); btn.disabled = true; err.replaceChildren();
    try { state.user = (await post('/auth/login', { email: email.value, password: pw.value })).user; location.hash = '#/portfolio'; route(); }
    catch (ex) { err.replaceChildren(errorBox(ex)); pw.value = ''; } finally { btn.disabled = false; }
  } },
  h('label', { class: 'field' }, 'Email', email), h('label', { class: 'field', style: { marginTop: '12px' } }, 'Password', pw), err,
  h('div', { style: { marginTop: '16px' } }, btn));
  return h('div', { class: 'login' }, h('div', { class: 'card' },
    h('div', { class: 'brand', style: { marginBottom: '14px' } }, h('span', { class: 'brand-mark' }), 'PMO Hub'),
    h('h1', 'Sign in'), h('p', { class: 'muted small' }, 'Program and portfolio management. Access is limited to authorised accounts.'), form,
    ['localhost', '127.0.0.1'].includes(location.hostname) ? h('p', { class: 'muted small' }, 'Local demo: sign in as admin@demo.test (see the README for the demo password).') : null));
}

function shell(content, active) {
  const link = (href, label, key) => h('a', { href, 'aria-current': active === key ? 'page' : null }, label);
  return h('div', null,
    h('header', { class: 'topbar' }, h('div', { class: 'topbar-inner' },
      h('div', { class: 'brand' }, h('span', { class: 'brand-mark' }), 'PMO Hub'),
      h('nav', { class: 'nav', 'aria-label': 'Main' }, link('#/portfolio', 'Portfolio', 'portfolio'), link('#/programs', 'Programs', 'programs'),
        state.user.global_role === 'admin' ? link('#/admin', 'Admin', 'admin') : null),
      h('div', { class: 'userbox' }, h('span', { class: 'muted' }, state.loginRequired ? state.user.name : (getDisplayName() || 'Guest')),
        state.loginRequired
          ? h('button', { class: 'btn btn-sm', type: 'button', onClick: async () => { try { await post('/auth/logout'); } catch { /* ignore */ } state.user = null; location.hash = ''; route(); } }, 'Sign out')
          : h('button', { class: 'btn btn-sm', type: 'button', title: 'Your name is recorded in the change history', onClick: () => {
            const n = window.prompt('Your name (shown in the change history):', getDisplayName());
            if (n !== null) { setDisplayName(n.trim()); route(); }
          } }, getDisplayName() ? 'Change name' : 'Set your name')))),
    h('main', { id: 'main' }, content));
}

async function route() {
  const my = ++token;
  if (!state.user) { app.replaceChildren(loginView()); return; }
  const parts = (location.hash.replace(/^#\/?/, '') || 'portfolio').split('/');
  let active = parts[0] === 'p' ? 'programs' : parts[0];
  let mod; let params = {};
  if (parts[0] === 'portfolio') mod = './pages/portfolio.js';
  else if (parts[0] === 'programs' && parts[1] === 'new') mod = './pages/wizard.js';
  else if (parts[0] === 'programs') mod = './pages/programs.js';
  else if (parts[0] === 'p' && parts[1]) { mod = './pages/workspace.js'; params = { id: parts[1], tab: parts[2] || 'overview', rest: parts.slice(3) }; }
  else if (parts[0] === 'admin' && state.user.global_role === 'admin') mod = './pages/admin.js';
  else { location.hash = '#/portfolio'; return; }
  app.replaceChildren(shell(h('div', { class: 'loading' }, 'Loading…'), active));
  try {
    const page = await import(mod);
    const content = await page.render({ params, state, navigate });
    if (my !== token) return; // a newer navigation superseded this one
    app.replaceChildren(shell(content, active));
    window.scrollTo(0, 0);
  } catch (e) {
    if (my !== token) return;
    const msg = e.status === 404 ? 'That page was not found, or you do not have access to it.' : e.message;
    app.replaceChildren(shell(h('div', { class: 'card' }, errorBox({ message: msg, errors: e.errors }), h('p', h('a', { href: '#/portfolio' }, 'Back to portfolio'))), active));
  }
}

boot();
