import { h, date, datetime, healthBadge, formModal, toast, STATUS_LABEL } from '../dom.js';
import { get, post } from '../api.js';
import { deleteProgramDialog } from './delete-program.js';

const TABS = [['overview', 'Overview'], ['charter', 'Charter'], ['plan', 'Plan'], ['resources', 'Resources & budget'], ['raid', 'RAID & decisions'], ['history', 'Change history']];

export async function render({ params }) {
  const id = params.id;
  const ctx = { id, data: await get(`/programs/${id}`), tab: params.tab };
  const host = h('div');
  let mod = null;
  let tabToken = 0;

  async function paint() {
    const my = ++tabToken;
    const d = ctx.data;
    const p = d.program;
    const panel = h('div', { id: 'tabpanel', role: 'tabpanel' });
    host.replaceChildren(header(d), h('nav', { class: 'tabs', 'aria-label': 'Program pages' },
      TABS.map(([k, l]) => h('a', { href: `#/p/${id}/${k}`, 'aria-current': ctx.tab === k ? 'page' : null }, l))), panel);
    try {
      mod ||= await import(`./tab-${ctx.tab}.js`);
      const node = await mod.render(ctx);
      if (my === tabToken) panel.replaceChildren(node);
    } catch (e) {
      panel.replaceChildren(h('div', { class: 'card' }, `Could not load this page: ${e.message}`));
    }
    document.title = `${p.name} — PMO Hub`;
  }
  ctx.apply = (r) => { if (r && r.program) ctx.data = r; return paint(); };
  ctx.reload = async () => { ctx.data = await get(`/programs/${id}`); return paint(); };
  ctx.act = async (fn, okMsg) => {
    try { const r = await fn(); await ctx.apply(r); if (okMsg) toast(okMsg); return r; }
    catch (e) { toast(`${e.message}${e.errors?.length ? ' — ' + e.errors[0] : ''}`, true); return null; }
  };

  function header(d) {
    const p = d.program;
    const b = d.baselines[0];
    const pending = d.pending_proposals;
    const nodes = [
      h('div', { class: 'page-head' },
        h('div', h('div', { class: 'muted small' }, h('a', { href: '#/programs' }, 'Programs'), ' / ', p.code),
          h('h1', p.name),
          h('div', { class: 'row small' }, healthBadge(d.health.overall, d.health.reasons.join('; ') || null), h('span', { class: 'badge b-grey' }, STATUS_LABEL[p.status] || p.status),
            h('span', { class: 'muted' }, b ? `Baseline v${b.version} approved ${date(b.approved_at.slice(0, 10))} by ${b.approved_by}` : 'No baseline approved yet'),
            h('span', { class: 'muted' }, `Sponsor: ${p.sponsor} · Manager: ${p.manager} · ${date(p.start_date)} → ${date(d.plan.forecastEnd)}`))),
        h('div', { class: 'row' }, d.caps.delete ? h('button', { class: 'btn btn-danger', type: 'button', onClick: () => deleteProgramDialog({ id, name: p.name }, () => { toast('Program deleted'); location.hash = '#/programs'; }) }, 'Delete program') : null, d.caps.baseline ? h('button', { class: 'btn btn-primary', type: 'button', onClick: () => baselineDialog(ctx) }, b ? 'Re-baseline…' : 'Approve baseline…') : null)),
    ];
    if (!b || pending > 0) {
      nodes.push(h('div', { class: 'notice proposal-banner' }, b
        ? `${pending} proposed item(s) are still unreviewed.`
        : h('span', h('strong', 'Draft proposal. '), `Content generated from your answers is labelled "Proposed" until you edit or approve it${pending ? ` (${pending} unreviewed item${pending === 1 ? '' : 's'})` : ''}. Review the charter, plan, resources, budget and RAID log, then approve a baseline.`)));
    }
    return h('div', nodes);
  }

  await paint();
  return host;
}

function baselineDialog(ctx) {
  const d = ctx.data;
  const hasPrev = d.baselines.length > 0;
  const pending = d.pending_proposals;
  const fields = [{ name: 'note', label: hasPrev ? 'Reason for re-baselining (required)' : 'Approval note (optional)', type: 'textarea', span2: true }];
  if (pending > 0) fields.push({ name: 'confirm', label: `I have reviewed the plan and accept the ${pending} unreviewed proposed item(s) as part of the baseline`, type: 'checkbox', span2: true });
  const issues = d.plan.issues.filter((i) => i.level === 'error');
  formModal({
    title: hasPrev ? 'Re-baseline program' : 'Approve baseline', submitLabel: 'Approve baseline', fields,
    intro: `This freezes the current dates (${date(d.plan.forecastEnd)} finish), effort, ${d.budget.approved ? 'budget' : 'plan cost'} and ${d.tasks.length} plan items as the reference for variance reporting. It is recorded in the change history.${issues.length ? ` Fix ${issues.length} plan error(s) first.` : ''}`,
    onSubmit: async (v) => {
      if (pending > 0 && !v.confirm) throw Object.assign(new Error('Please confirm you have reviewed the proposed items'), {});
      const r = await post(`/programs/${ctx.id}/baseline`, { note: v.note, confirm: !!v.confirm });
      await ctx.apply(r);
      toast(`Baseline v${r.baseline.version} approved`);
    },
  });
}
