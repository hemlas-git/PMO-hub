import { h, money, date, num, healthBadge, bar, dataTable, emptyState, days } from '../dom.js';
import { get } from '../api.js';

const RANK = { red: 4, amber: 3, green: 2, draft: 1, complete: 0, on_hold: 0 };
const f = { q: '', health: '', status: '', manager: '' };
let sort = { key: 'health', dir: -1 };

const kpi = (label, value, sub, cls = '') => h('div', { class: 'kpi' }, h('div', { class: 'label' }, label), h('div', { class: `value ${cls}` }, value), sub ? h('div', { class: 'sub' }, sub) : null);

export async function render() {
  const { programs, summary: s, can_create: canCreate } = await get('/portfolio');
  const head = h('div', { class: 'page-head' }, h('div', h('h1', 'Portfolio'), h('p', { class: 'muted' }, 'Health, budget, risks and support requests across your programs.')),
    canCreate ? h('a', { class: 'btn btn-primary', href: '#/programs/new' }, '+ New program') : null);
  if (!programs.length) {
    return h('div', head, h('div', { class: 'card' }, emptyState('No programs yet', canCreate ? 'Create your first program from a few answers and review the proposed charter, plan, budget and RAID log.' : 'You have not been given access to any programs yet. Ask an administrator.',
      canCreate ? h('a', { class: 'btn btn-primary', href: '#/programs/new' }, 'Create a program') : null)));
  }
  const bc = s.base_currency;
  const variance = s.approved - s.forecast;
  const kpis = h('div', { class: 'grid g4' },
    kpi('Programs', s.programs, ['🟢 ', s.health.green, ' on track · 🟠 ', s.health.amber, ' at risk · 🔴 ', s.health.red, ' off track', s.health.draft ? ` · ${s.health.draft} draft` : ''].join('').replace(/🟢|🟠|🔴/g, (m) => ({ '🟢': '●', '🟠': '▲', '🔴': '■' })[m])),
    kpi(`Approved budget (${bc})`, money(s.approved, bc, true), `Actual spend ${money(s.actual, bc, true)} (${s.approved ? Math.round((s.actual / s.approved) * 100) : 0}%)`),
    kpi('Forecast at completion', money(s.forecast, bc, true), `${variance >= 0 ? 'Under' : 'Over'} budget by ${money(Math.abs(variance), bc, true)}`, variance < 0 ? 'bad' : 'good'),
    kpi('Management attention', `${s.open_support_requests} requests`, `${s.high_items} high-priority RAID · ${s.overdue_decisions} overdue decisions · ${s.overdue_actions} overdue actions`, s.open_support_requests ? 'warn' : ''));
  const note = s.excluded_currencies.length ? h('div', { class: 'notice' }, `Totals exclude programs in ${s.excluded_currencies.join(', ')} because no exchange rate to ${bc} is set (Admin → Portfolio currency).`) : null;

  const host = h('div');
  const managers = [...new Set(programs.map((p) => p.manager))].sort();
  const filters = h('div', { class: 'filters' },
    h('label', { class: 'field' }, 'Search', h('input', { type: 'search', placeholder: 'Name, sponsor, manager', value: f.q, onInput: (e) => { f.q = e.target.value; draw(); } })),
    h('label', { class: 'field' }, 'Health', h('select', { onChange: (e) => { f.health = e.target.value; draw(); } },
      [['', 'All'], ['green', 'On track'], ['amber', 'At risk'], ['red', 'Off track'], ['draft', 'Draft']].map(([v, l]) => h('option', { value: v, selected: f.health === v }, l)))),
    h('label', { class: 'field' }, 'Status', h('select', { onChange: (e) => { f.status = e.target.value; draw(); } },
      [['', 'All'], ['active', 'Active'], ['draft', 'Draft'], ['on_hold', 'On hold'], ['complete', 'Complete']].map(([v, l]) => h('option', { value: v, selected: f.status === v }, l)))),
    h('label', { class: 'field' }, 'Program manager', h('select', { onChange: (e) => { f.manager = e.target.value; draw(); } },
      [h('option', { value: '' }, 'All'), ...managers.map((m) => h('option', { value: m, selected: f.manager === m }, m))])));

  const cols = [
    { key: 'name', label: 'Program', sort: true, render: (p) => h('div', h('a', { href: `#/p/${p.id}/overview` }, h('strong', p.name)), h('div', { class: 'muted small' }, p.code, p.baselined ? '' : ' · not baselined')) },
    { key: 'sponsor', label: 'Sponsor / Manager', sort: true, render: (p) => h('div', h('div', p.sponsor), h('div', { class: 'muted small' }, p.manager)) },
    { key: 'health', label: 'Health', sort: true, render: (p) => h('div', healthBadge(p.health, p.health_reasons.join('; ') || null),
      p.health === 'draft' ? null : h('div', { class: 'small muted', style: { marginTop: '4px' } }, 'Sched ', dot(p.health_parts.schedule), ' Budget ', dot(p.health_parts.budget), ' RAID ', dot(p.health_parts.raid), p.overridden ? ' · override' : '')) },
    { key: 'progress', label: 'Progress', sort: true, render: (p) => h('div', { style: { minWidth: '110px' } }, h('div', { class: 'small' }, `${p.progress}% `, h('span', { class: 'muted' }, `of ${p.planned_progress}% expected`)), bar(p.progress, p.planned_progress)) },
    { key: 'milestone', label: 'Key milestone', sort: true, render: (p) => (p.key_milestone ? h('div', h('div', p.key_milestone.name), h('div', { class: `small ${p.key_milestone.overdue ? 'bad' : 'muted'}` }, (p.key_milestone.overdue ? 'Overdue · ' : '') + date(p.key_milestone.end))) : '—') },
    { key: 'approved_budget', label: 'Approved', num: true, sort: true, render: (p) => money(p.approved_budget, p.currency, true) },
    { key: 'forecast', label: 'Forecast', num: true, sort: true, render: (p) => h('span', { class: p.approved_budget && p.forecast > p.approved_budget ? 'bad' : '' }, money(p.forecast, p.currency, true)) },
    { key: 'actual', label: 'Actual', num: true, sort: true, render: (p) => money(p.actual, p.currency, true) },
    { key: 'risks', label: 'Top risks', render: (p) => (p.top_risks.length ? h('ul', { class: 'plain small' }, p.top_risks.map((r) => h('li', h('strong', { class: r.score >= 15 ? 'bad' : '' }, r.score), ' ', r.title))) : h('span', { class: 'muted' }, '—')) },
    { key: 'overdue', label: 'Overdue', sort: true, render: (p) => (p.overdue_decisions + p.overdue_actions ? h('span', { class: 'bad' }, `${p.overdue_decisions} decisions · ${p.overdue_actions} actions`) : h('span', { class: 'muted' }, 'None')) },
    { key: 'support', label: 'Support requested', sort: true, render: (p) => (p.support_requests.length ? h('div', { class: 'small' }, h('span', { class: 'badge b-amber' }, `${p.support_requests.length} open`), h('div', p.support_requests[0])) : h('span', { class: 'muted' }, '—')) },
  ];
  const val = {
    name: (p) => p.name.toLowerCase(), sponsor: (p) => p.sponsor.toLowerCase(), health: (p) => RANK[p.health] ?? 0, progress: (p) => p.progress,
    milestone: (p) => p.key_milestone?.end || '9999', approved_budget: (p) => p.approved_budget, forecast: (p) => p.forecast, actual: (p) => p.actual,
    overdue: (p) => p.overdue_decisions + p.overdue_actions, support: (p) => p.support_requests.length,
  };
  function draw() {
    const q = f.q.toLowerCase();
    let rows = programs.filter((p) => (!q || [p.name, p.sponsor, p.manager, p.code].some((x) => x.toLowerCase().includes(q))) && (!f.health || p.health === f.health) && (!f.status || p.status === f.status) && (!f.manager || p.manager === f.manager));
    const g = val[sort.key] || val.name;
    rows = [...rows].sort((a, b) => (g(a) > g(b) ? 1 : g(a) < g(b) ? -1 : 0) * sort.dir);
    host.replaceChildren(dataTable(cols, rows, { sort, onSort: (k) => { sort = { key: k, dir: sort.key === k ? -sort.dir : 1 }; draw(); }, onRow: (p) => { location.hash = `#/p/${p.id}/overview`; }, empty: 'No programs match these filters.' }),
      h('p', { class: 'muted small' }, `${rows.length} of ${programs.length} programs. Forecast = actual spend + estimate to complete. Click a row to open the workspace.`));
  }
  draw();
  return h('div', head, kpis, note, h('div', { class: 'card', style: { marginTop: '16px' } }, h('div', { class: 'card-head' }, h('h2', 'Programs')), filters, host));
}

function dot(v) {
  const labels = { green: 'on track', amber: 'at risk', red: 'off track' };
  return h('span', { class: `dot ${v}`, role: 'img', 'aria-label': labels[v], title: labels[v] });
}
