// Pure calculation engine. Everything the UI shows (schedule, effort, cost, forecast, health,
// baseline variance) is derived here from the shared data model, so one edit flows everywhere.

const MS = 86400000;
export const toDate = (s) => new Date(`${s}T00:00:00Z`);
export const fmt = (d) => d.toISOString().slice(0, 10);
export const addDays = (s, n) => fmt(new Date(toDate(s).getTime() + n * MS));
export const diffDays = (a, b) => Math.round((toDate(b).getTime() - toDate(a).getTime()) / MS);
export const todayStr = () => fmt(new Date());
export const isWeekend = (s) => [0, 6].includes(toDate(s).getUTCDay());
export const nextWorkday = (s) => { let d = s; while (isWeekend(d)) d = addDays(d, 1); return d; };
export const monthKey = (s) => s.slice(0, 7);
const monthEnd = (key) => { const [y, m] = key.split('-').map(Number); return fmt(new Date(Date.UTC(y, m, 0))); };
export function weekKey(s) {
  const d = toDate(s);
  return fmt(new Date(d.getTime() - ((d.getUTCDay() + 6) % 7) * MS));
}
export function workdays(start, end) {
  const out = [];
  for (let t = toDate(start).getTime(), e = toDate(end).getTime(); t <= e; t += MS) {
    const d = new Date(t);
    const w = d.getUTCDay();
    if (w !== 0 && w !== 6) out.push(fmt(d));
  }
  return out;
}
const round = (n, p = 2) => Math.round(n * 10 ** p) / 10 ** p;
const sum = (a, f) => a.reduce((s, x) => s + f(x), 0);

/** Spread hours evenly over the working days in [start,end]. Returns [[date,hours],...]. */
export function spread(hours, start, end) {
  if (!hours) return [];
  if (end < start) end = start;
  const days = workdays(start, end);
  if (!days.length) return [[start, hours]];
  return days.map((d) => [d, hours / days.length]);
}

/** Finish-to-start rule. Milestones may land on the predecessor's end date; tasks start the day after. */
export function requiredStart(pred, succ) {
  const predEnd = pred.end ?? pred.end_date;
  return pred.type === 'milestone' || succ.type === 'milestone' ? predEnd : addDays(predEnd, 1);
}

export function findCycle(ids, edges) {
  const adj = new Map(ids.map((i) => [i, []]));
  for (const [a, b] of edges) adj.get(a)?.push(b);
  const state = new Map();
  const stack = [];
  let found = null;
  const dfs = (n) => {
    state.set(n, 1);
    stack.push(n);
    for (const m of adj.get(n) || []) {
      if (found) return;
      if (state.get(m) === 1) { found = [...stack.slice(stack.indexOf(m)), m]; return; }
      if (!state.get(m)) dfs(m);
    }
    stack.pop();
    state.set(n, 2);
  };
  for (const i of ids) { if (!state.get(i) && !found) dfs(i); }
  return found;
}

const deriveStatus = (children) => {
  if (children.every((c) => c.status === 'complete')) return 'complete';
  if (children.some((c) => c.status === 'blocked')) return 'blocked';
  if (children.some((c) => c.status === 'in_progress' || c.status === 'complete' || c.pct > 0)) return 'in_progress';
  return 'not_started';
};

// ------------------------------------------------------------------ schedule
export function computePlan(model, today) {
  const { program } = model;
  const nodes = model.tasks.map((t) => ({ ...t, predecessors: t.predecessors || [], kids: [] }));
  const byId = new Map(nodes.map((n) => [n.id, n]));
  const roots = [];
  for (const n of nodes) {
    const p = n.parent_id ? byId.get(n.parent_id) : null;
    (p ? p.kids : roots).push(n);
  }
  const order = [];
  const walk = (list, prefix, depth) => {
    list.sort((a, b) => a.sort - b.sort || a.start_date.localeCompare(b.start_date) || a.name.localeCompare(b.name));
    list.forEach((n, i) => {
      n.wbs = prefix ? `${prefix}.${i + 1}` : `${i + 1}`;
      n.depth = depth;
      order.push(n);
      walk(n.kids, n.wbs, depth + 1);
    });
  };
  walk(roots, '', 0);

  const expected = (s, e) => {
    if (today < s) return 0;
    if (today >= e) return 100;
    return Math.round((100 * workdays(s, today).length) / (workdays(s, e).length || 1));
  };

  for (let i = order.length - 1; i >= 0; i--) {
    const n = order[i];
    n.isSummary = n.kids.length > 0;
    if (n.isSummary) {
      const c = n.kids;
      n.start = c.reduce((a, x) => (x.start < a ? x.start : a), c[0].start);
      n.end = c.reduce((a, x) => (x.end > a ? x.end : a), c[0].end);
      n.estimate = sum(c, (x) => x.estimate);
      n.actual = sum(c, (x) => x.actual);
      const w = n.estimate;
      n.pct = Math.round(w > 0 ? sum(c, (x) => x.estimate * x.pct) / w : sum(c, (x) => x.pct) / c.length);
      n.expectedPct = Math.round(w > 0 ? sum(c, (x) => x.estimate * x.expectedPct) / w : sum(c, (x) => x.expectedPct) / c.length);
      n.status = deriveStatus(c);
      n.done = n.status === 'complete';
    } else {
      n.start = n.start_date;
      n.end = n.end_date;
      n.estimate = n.type === 'milestone' ? 0 : Number(n.estimate_hrs) || 0;
      n.actual = Number(n.actual_hrs) || 0;
      n.pct = n.type === 'milestone' ? (n.status === 'complete' ? 100 : 0) : n.pct_complete;
      n.expectedPct = n.type === 'milestone' ? (today >= n.end ? 100 : 0) : expected(n.start, n.end);
      n.done = n.pct >= 100 || n.status === 'complete';
    }
    n.duration = diffDays(n.start, n.end) + 1;
    n.overdue = !n.done && n.end < today;
    n.lateStart = !n.done && n.status === 'not_started' && n.start < today;
    const gap = n.expectedPct - n.pct;
    n.rag = n.done ? 'done' : n.status === 'blocked' || n.overdue || gap > 25 ? 'red' : gap > 10 || n.lateStart ? 'amber' : 'green';
  }

  // ---- validation
  const issues = [];
  const ids = nodes.map((n) => n.id);
  const edges = [];
  for (const n of nodes) for (const p of n.predecessors) if (byId.has(p)) edges.push([p, n.id]);
  const cycle = findCycle(ids, edges);
  if (cycle) {
    issues.push({ level: 'error', message: `Circular dependency: ${cycle.map((id) => byId.get(id)?.name).join(' → ')}` });
  }
  for (const n of nodes) {
    if (n.end_date < n.start_date) issues.push({ level: 'error', taskId: n.id, message: `"${n.name}" ends before it starts` });
    if (n.type === 'milestone' && n.end_date !== n.start_date) issues.push({ level: 'error', taskId: n.id, message: `Milestone "${n.name}" must be a single date` });
    for (const pid of n.predecessors) {
      const p = byId.get(pid);
      if (!p) continue;
      if (n.start < requiredStart(p, n)) {
        issues.push({ level: 'warning', taskId: n.id, message: `"${n.name}" starts before predecessor "${p.name}" finishes (${p.end})` });
      }
    }
    if (n.start < program.start_date || n.end > program.end_date) {
      issues.push({ level: 'warning', taskId: n.id, message: `"${n.name}" falls outside the program dates` });
    }
    if (!n.isSummary && n.type !== 'milestone' && n.estimate > 0 && !n.resource_id) {
      issues.push({ level: 'warning', taskId: n.id, message: `"${n.name}" has effort but no owner/resource` });
    }
  }

  // ---- float / critical path (only meaningful when acyclic)
  const succ = new Map(ids.map((i) => [i, []]));
  for (const [a, b] of edges) succ.get(a).push(b);
  const finish = order.length ? order.reduce((a, x) => (x.end > a ? x.end : a), order[0].end) : program.end_date;
  const memo = new Map();
  const floatOf = (id, guard = new Set()) => {
    if (memo.has(id)) return memo.get(id);
    if (guard.has(id)) return 0;
    guard.add(id);
    const n = byId.get(id);
    const ss = succ.get(id);
    let f = diffDays(n.end, finish);
    for (const s of ss) {
      const sn = byId.get(s);
      f = Math.min(f, Math.max(0, diffDays(requiredStart(n, sn), sn.start)) + floatOf(s, guard));
    }
    guard.delete(id);
    memo.set(id, f);
    return f;
  };
  for (const n of order) {
    if (n.isSummary || cycle) { n.float = null; n.critical = false; continue; }
    n.float = floatOf(n.id);
    n.critical = !n.done && n.float <= 0 && (n.predecessors.length > 0 || succ.get(n.id).length > 0);
  }

  // ---- roll-ups
  const leaves = order.filter((n) => !n.isSummary && n.type !== 'milestone');
  const totEst = sum(leaves, (n) => n.estimate);
  const wavg = (f) => (totEst > 0 ? sum(leaves, (n) => n.estimate * f(n)) / totEst : leaves.length ? sum(leaves, f) / leaves.length : 0);
  const milestones = order.filter((n) => n.type === 'milestone');
  const nextMilestones = milestones.filter((m) => !m.done).sort((a, b) => a.end.localeCompare(b.end));

  const out = order.map((n) => {
    const { kids, ...rest } = n;
    return { ...rest, children: kids.map((k) => k.id) };
  });
  return {
    nodes: out,
    issues,
    hasCycle: !!cycle,
    progress: Math.round(wavg((n) => n.pct)),
    plannedProgress: Math.round(wavg((n) => n.expectedPct)),
    milestones: milestones.map((m) => ({ id: m.id, name: m.name, end: m.end, done: m.done, overdue: m.overdue })),
    nextMilestones: nextMilestones.slice(0, 5).map((m) => ({ id: m.id, name: m.name, end: m.end, overdue: m.overdue, rag: m.rag, critical: m.critical })),
    keyMilestone: nextMilestones[0] ? { id: nextMilestones[0].id, name: nextMilestones[0].name, end: nextMilestones[0].end, overdue: nextMilestones[0].overdue, rag: nextMilestones[0].rag } : null,
    forecastEnd: finish,
    overdueTasks: leaves.filter((n) => n.overdue).length,
    overdueMilestones: milestones.filter((m) => m.overdue).length,
  };
}

// ------------------------------------------------------------------ resources
export const FORECAST_METHODS = {
  percent: 'Remaining = estimate × (1 − % complete)',
  remaining: 'Remaining = estimate − actual effort (not below zero)',
  performance: 'Remaining = actual ÷ % complete − actual (extrapolates current productivity)',
};

function etcHours(n, method) {
  if (n.done) return 0;
  if (method === 'remaining') return Math.max(n.estimate - n.actual, 0);
  if (method === 'performance' && n.pct > 0 && n.actual > 0) return Math.max(n.actual / (n.pct / 100) - n.actual, 0);
  return n.estimate * (1 - n.pct / 100);
}

export function resolveAssumptions(program) {
  const a = program.assumptions || {};
  return {
    contingency_pct: a.contingency_pct ?? 10,
    forecast_method: FORECAST_METHODS[a.forecast_method] ? a.forecast_method : 'percent',
    utilisation_pct: a.utilisation_pct ?? 80,
    fx: a.fx || {},
  };
}

export function computeResources(model, plan, today) {
  const { program } = model;
  const A = resolveAssumptions(program);
  const cur = program.currency;
  const acc = new Map();
  const mk = (r) => ({
    ...r,
    rate_issue: null,
    rate_pc: null,
    weekly_capacity: 0,
    planned_hrs: 0, actual_hrs: 0, etc_hrs: 0,
    byMonth: {}, byWeek: {},
  });
  for (const r of model.resources) {
    const x = mk(r);
    x.weekly_capacity = (r.capacity_hrs_week * r.allocation_pct) / 100;
    if (r.rate == null) x.rate_issue = 'missing_rate';
    else if (!r.rate_currency || r.rate_currency === cur) x.rate_pc = r.rate;
    else if (A.fx[r.rate_currency] != null) x.rate_pc = r.rate * A.fx[r.rate_currency];
    else x.rate_issue = 'missing_fx';
    acc.set(r.id, x);
  }
  const UNASSIGNED = '_unassigned';
  const m = (x, k) => (x.byMonth[k] ||= { planned: 0, actual: 0, forecast: 0 });
  const add = (x, kind, date, h) => { m(x, monthKey(date))[kind] += h; };

  for (const n of plan.nodes) {
    if (n.isSummary || n.type === 'milestone') continue;
    if (!n.estimate && !n.actual) continue;
    let x = acc.get(n.resource_id);
    if (!x) {
      if (!acc.has(UNASSIGNED)) acc.set(UNASSIGNED, { ...mk({ id: UNASSIGNED, name: 'Unassigned', role: 'Unassigned', rate: null, chargeable: false, capacity_hrs_week: 0, allocation_pct: 0 }), unassigned: true });
      x = acc.get(UNASSIGNED);
    }
    for (const [d, h] of spread(n.estimate, n.start, n.end)) {
      add(x, 'planned', d, h);
      x.byWeek[weekKey(d)] = (x.byWeek[weekKey(d)] || 0) + h;
    }
    x.planned_hrs += n.estimate;
    // actual effort: spread up to today (or the full task if it is finished / in the past)
    const aEnd = n.done || n.end < today ? n.end : today < n.start ? n.start : today;
    for (const [d, h] of spread(n.actual, n.start, aEnd)) { add(x, 'actual', d, h); add(x, 'forecast', d, h); }
    x.actual_hrs += n.actual;
    // estimate-to-complete: spread over remaining working time
    const etc = etcHours(n, A.forecast_method);
    if (etc > 0) {
      const eStart = today > n.start ? today : n.start;
      const eEnd = n.end > eStart ? n.end : eStart;
      for (const [d, h] of spread(etc, eStart, eEnd)) add(x, 'forecast', d, h);
      x.etc_hrs += etc;
    }
  }

  // periods
  let first = program.start_date;
  let last = program.end_date > plan.forecastEnd ? program.end_date : plan.forecastEnd;
  for (const x of acc.values()) for (const k of Object.keys(x.byMonth)) { if (k + '-01' < first) first = k + '-01'; if (monthEnd(k) > last) last = monthEnd(k); }
  const periods = [];
  let [py, pm] = first.slice(0, 7).split('-').map(Number);
  for (;;) {
    const k = `${py}-${String(pm).padStart(2, '0')}`;
    if (k > monthKey(last)) break;
    periods.push(k);
    if (++pm > 12) { pm = 1; py++; }
  }
  const monthWorkdays = Object.fromEntries(periods.map((p) => [p, workdays(`${p}-01`, monthEnd(p)).length]));

  const finalise = (x) => {
    const rate = x.rate_pc || 0;
    x.forecast_hrs = x.actual_hrs + x.etc_hrs;
    x.planned_cost = x.planned_hrs * rate;
    x.actual_cost = x.actual_hrs * rate;
    x.etc_cost = x.etc_hrs * rate;
    x.forecast_cost = x.actual_cost + x.etc_cost;
    x.overWeeks = [];
    let peak = 0;
    for (const [w, h] of Object.entries(x.byWeek)) {
      const util = x.weekly_capacity > 0 ? h / x.weekly_capacity : h > 0 ? Infinity : 0;
      if (util > 1.0001) x.overWeeks.push({ week: w, hours: round(h, 1), capacity: round(x.weekly_capacity, 1) });
      if (util > peak) peak = util;
    }
    x.overWeeks.sort((a, b) => a.week.localeCompare(b.week));
    x.peak_util = peak === Infinity ? null : round(peak * 100, 0);
    x.over_allocated = !x.unassigned && x.overWeeks.length > 0;
    x.missing_rate = !!x.rate_issue && x.chargeable && (x.planned_hrs > 0 || x.actual_hrs > 0);
    x.months = {};
    for (const p of periods) {
      const b = x.byMonth[p] || { planned: 0, actual: 0, forecast: 0 };
      const cap = (x.weekly_capacity * monthWorkdays[p]) / 5;
      x.months[p] = {
        planned: round(b.planned, 1), actual: round(b.actual, 1), forecast: round(b.forecast, 1),
        plannedCost: round(b.planned * rate, 0), actualCost: round(b.actual * rate, 0), forecastCost: round(b.forecast * rate, 0),
        capacity: round(cap, 1), util: cap > 0 ? Math.round((100 * b.planned) / cap) : null,
      };
    }
    delete x.byMonth; delete x.byWeek;
    return x;
  };
  const list = [...acc.values()].map(finalise);

  const roleMap = new Map();
  for (const x of list) {
    const key = x.role || x.name;
    if (!roleMap.has(key)) roleMap.set(key, { role: key, people: 0, planned_hrs: 0, actual_hrs: 0, etc_hrs: 0, forecast_hrs: 0, planned_cost: 0, actual_cost: 0, forecast_cost: 0, months: {} });
    const r = roleMap.get(key);
    r.people++;
    for (const k of ['planned_hrs', 'actual_hrs', 'etc_hrs', 'forecast_hrs', 'planned_cost', 'actual_cost', 'forecast_cost']) r[k] += x[k];
    for (const p of periods) {
      const t = (r.months[p] ||= { planned: 0, actual: 0, forecast: 0, plannedCost: 0, actualCost: 0, forecastCost: 0 });
      for (const k of Object.keys(t)) t[k] += x.months[p][k];
    }
  }
  const totals = {
    planned_hrs: sum(list, (x) => x.planned_hrs), actual_hrs: sum(list, (x) => x.actual_hrs), etc_hrs: sum(list, (x) => x.etc_hrs),
    forecast_hrs: sum(list, (x) => x.forecast_hrs), planned_cost: sum(list, (x) => x.planned_cost), actual_cost: sum(list, (x) => x.actual_cost),
    etc_cost: sum(list, (x) => x.etc_cost), forecast_cost: sum(list, (x) => x.forecast_cost),
  };
  const flags = [];
  for (const x of list) {
    if (x.over_allocated) flags.push({ level: 'warning', resourceId: x.id, message: `${x.name} is over-allocated in ${x.overWeeks.length} week(s) (peak ${x.peak_util}% of capacity)` });
    if (x.missing_rate) flags.push({ level: 'error', resourceId: x.id, message: x.rate_issue === 'missing_fx' ? `${x.name}: no FX rate to convert ${x.rate_currency} to ${cur}` : `${x.name} has planned effort but no rate — cost is understated` });
    if (x.unassigned && x.planned_hrs > 0) flags.push({ level: 'warning', resourceId: x.id, message: `${round(x.planned_hrs, 0)} planned hours are not assigned to anyone` });
  }
  return { resources: list, roles: [...roleMap.values()], periods, totals, flags, assumptions: A };
}

// ------------------------------------------------------------------ budget
export function computeBudget(model, res) {
  const A = res.assumptions;
  const lines = model.budget_lines.map((l) => {
    const planned = Number(l.planned_amount) || 0;
    const actual = Number(l.actual_amount) || 0;
    const etc = l.forecast_override != null ? Number(l.forecast_override) : Math.max(planned - actual, 0);
    return { ...l, planned_amount: planned, actual_amount: actual, etc, forecast: actual + etc, variance: planned - (actual + etc) };
  });
  const nl = { planned: sum(lines, (l) => l.planned_amount), actual: sum(lines, (l) => l.actual_amount), etc: sum(lines, (l) => l.etc) };
  nl.forecast = nl.actual + nl.etc;
  const t = res.totals;
  const labour = { planned: t.planned_cost, actual: t.actual_cost, etc: t.etc_cost, forecast: t.forecast_cost };
  const plannedCost = labour.planned + nl.planned;
  const contingency = (plannedCost * A.contingency_pct) / 100;
  const approved = Number(model.program.approved_budget) || 0;
  const actual = labour.actual + nl.actual;
  const forecast = labour.forecast + nl.forecast;
  return {
    lines, labour, nonLabour: nl, contingency, contingency_pct: A.contingency_pct,
    plannedCost, plannedBudget: plannedCost + contingency, approved, actual, forecast,
    etc: forecast - actual, variance: approved - forecast, variancePct: approved > 0 ? ((approved - forecast) / approved) * 100 : null,
    spentPct: approved > 0 ? (actual / approved) * 100 : null,
    missingRateHours: sum(res.resources.filter((r) => r.missing_rate), (r) => r.planned_hrs),
  };
}

// ------------------------------------------------------------------ RAID
export const HIGH_SCORE = 15;
export function computeRaid(model, today) {
  const idsToName = new Map(model.tasks.map((t) => [t.id, t.name]));
  const wsName = new Map(model.workstreams.map((w) => [w.id, w.name]));
  const items = model.raid.map((r) => {
    const open = r.status !== 'closed';
    let score = null;
    if (r.impact && r.likelihood) score = r.impact * r.likelihood;
    else if (r.type === 'issue' && r.impact) score = r.impact * 5;
    const overdue = open && !!r.due_date && r.due_date < today;
    const priority = score == null ? (overdue ? 'high' : 'normal') : score >= HIGH_SCORE ? 'high' : score >= 8 ? 'medium' : 'low';
    return {
      ...r, open, score, overdue, priority,
      daysOverdue: overdue ? diffDays(r.due_date, today) : 0,
      task_ids: r.task_ids || [],
      task_names: (r.task_ids || []).map((i) => idsToName.get(i)).filter(Boolean),
      workstream_name: r.workstream_id ? wsName.get(r.workstream_id) || '' : '',
    };
  });
  const open = items.filter((i) => i.open);
  const topRisks = open.filter((i) => i.type === 'risk' && i.score != null).sort((a, b) => b.score - a.score).slice(0, 3)
    .map((i) => ({ id: i.id, title: i.title, score: i.score, owner: i.owner }));
  const overdue = open.filter((i) => i.overdue);
  const matrix = {};
  for (const i of open.filter((x) => x.type === 'risk' && x.impact && x.likelihood)) {
    const k = `${i.impact}-${i.likelihood}`;
    matrix[k] = (matrix[k] || 0) + 1;
  }
  return {
    items, topRisks, matrix,
    openCount: open.length,
    highCount: open.filter((i) => i.priority === 'high').length,
    criticalCount: open.filter((i) => i.score >= 20).length,
    overdueCount: overdue.length,
    overdueDecisions: overdue.filter((i) => i.type === 'decision').length,
    overdueActions: overdue.filter((i) => i.type !== 'decision').length,
  };
}

// ------------------------------------------------------------------ baseline
export function makeSnapshot(model, plan, budget) {
  return {
    start_date: model.program.start_date,
    end_date: plan.forecastEnd,
    approved_budget: budget.approved,
    planned_cost: round(budget.plannedCost, 2),
    planned_hours: round(sum(plan.nodes.filter((n) => !n.isSummary), (n) => n.estimate), 1),
    currency: model.program.currency,
    tasks: plan.nodes.map((n) => ({ id: n.id, wbs: n.wbs, name: n.name, type: n.type, parent_id: n.parent_id, start: n.start, end: n.end, estimate: n.estimate, isSummary: n.isSummary })),
  };
}

export function baselineVariance(baseline, plan, budget) {
  const snap = baseline.snapshot;
  const cur = new Map(plan.nodes.map((n) => [n.id, n]));
  const base = new Map(snap.tasks.map((t) => [t.id, t]));
  const tasks = [];
  for (const b of snap.tasks) {
    const c = cur.get(b.id);
    if (!c) { tasks.push({ id: b.id, wbs: b.wbs, name: b.name, type: b.type, removed: true }); continue; }
    const startSlip = diffDays(b.start, c.start);
    const endSlip = diffDays(b.end, c.end);
    const estDelta = round(c.estimate - b.estimate, 1);
    if (startSlip || endSlip || estDelta) tasks.push({ id: b.id, wbs: c.wbs, name: c.name, type: c.type, isSummary: c.isSummary, baseStart: b.start, baseEnd: b.end, start: c.start, end: c.end, startSlip, endSlip, estDelta });
  }
  for (const c of plan.nodes) if (!base.has(c.id)) tasks.push({ id: c.id, wbs: c.wbs, name: c.name, type: c.type, added: true, start: c.start, end: c.end, estDelta: c.estimate });
  const planned_hours = sum(plan.nodes.filter((n) => !n.isSummary), (n) => n.estimate);
  return {
    version: baseline.version, approved_by: baseline.approved_by, approved_at: baseline.approved_at, note: baseline.note,
    baseEnd: snap.end_date, endSlip: diffDays(snap.end_date, plan.forecastEnd),
    baseBudget: snap.approved_budget, budgetDelta: budget.approved - snap.approved_budget,
    baseCost: snap.planned_cost, costDelta: round(budget.plannedCost - snap.planned_cost, 2),
    baseHours: snap.planned_hours, hoursDelta: round(planned_hours - snap.planned_hours, 1),
    forecastVsBaseCost: round(budget.forecast - snap.planned_cost, 2),
    changed: tasks.filter((t) => !t.isSummary),
    milestoneSlips: tasks.filter((t) => t.type === 'milestone' && t.endSlip > 0).length,
  };
}

// ------------------------------------------------------------------ health
const RANK = { green: 0, amber: 1, red: 2 };
const worst = (...c) => c.reduce((a, b) => (RANK[b] > RANK[a] ? b : a), 'green');

export function computeHealth(model, plan, budget, raid, variance) {
  const p = model.program;
  const reasons = [];
  const slip = variance ? variance.endSlip : 0;
  const behind = plan.plannedProgress - plan.progress;
  let schedule = 'green';
  if (slip > 14 || plan.overdueMilestones >= 2 || behind >= 20) schedule = 'red';
  else if (slip > 0 || plan.overdueMilestones >= 1 || plan.overdueTasks > 0 || behind >= 8) schedule = 'amber';
  if (slip > 0) reasons.push(`Forecast finish is ${slip} day(s) later than baseline`);
  if (plan.overdueMilestones) reasons.push(`${plan.overdueMilestones} milestone(s) overdue`);
  if (plan.overdueTasks) reasons.push(`${plan.overdueTasks} task(s) overdue`);
  if (behind >= 8) reasons.push(`Progress ${plan.progress}% vs ${plan.plannedProgress}% expected`);

  let bud = 'green';
  if (!budget.approved) { bud = 'amber'; reasons.push('No approved budget set'); }
  else {
    const ratio = budget.forecast / budget.approved;
    if (ratio > 1.1) bud = 'red';
    else if (ratio > 1 || budget.plannedBudget > budget.approved) bud = 'amber';
    if (ratio > 1) reasons.push(`Forecast is ${Math.round((ratio - 1) * 100)}% over approved budget`);
    else if (budget.plannedBudget > budget.approved) reasons.push('Plan cost incl. contingency exceeds approved budget');
  }

  let r = 'green';
  if (raid.criticalCount > 0 || raid.overdueCount >= 3) r = 'red';
  else if (raid.highCount > 0 || raid.overdueCount > 0) r = 'amber';
  if (raid.criticalCount) reasons.push(`${raid.criticalCount} critical open risk/issue(s)`);
  if (raid.overdueCount) reasons.push(`${raid.overdueCount} RAID item(s) overdue`);

  const computed = worst(schedule, bud, r);
  let overall = computed;
  let overridden = false;
  if (p.status === 'draft') overall = 'draft';
  else if (p.status === 'complete') overall = 'complete';
  else if (p.health_override) { overall = p.health_override; overridden = true; }
  return { overall, computed, overridden, override_reason: p.health_override_reason || '', schedule, budget: bud, raid: r, reasons };
}

// ------------------------------------------------------------------ composite
export function computeProgram(model, today = todayStr()) {
  const plan = computePlan(model, today);
  const resources = computeResources(model, plan, today);
  const budget = computeBudget(model, resources);
  const raid = computeRaid(model, today);
  const variance = model.baseline ? baselineVariance(model.baseline, plan, budget) : null;
  if (model.baseline) {
    const b = new Map(model.baseline.snapshot.tasks.map((t) => [t.id, t]));
    for (const n of plan.nodes) { const t = b.get(n.id); if (t) n.baseline = { start: t.start, end: t.end, estimate: t.estimate }; }
  }
  const health = computeHealth(model, plan, budget, raid, variance);
  return { today, plan, resources, budget, raid, variance, health };
}

/** Compact row for the portfolio table. */
export function programSummary(model, c) {
  const p = model.program;
  const open = (p.support_requests || []).filter((s) => s.status === 'open');
  return {
    id: p.id, code: p.code, name: p.name, status: p.status, sponsor: p.sponsor, manager: p.manager, currency: p.currency,
    health: c.health.overall, health_parts: { schedule: c.health.schedule, budget: c.health.budget, raid: c.health.raid },
    health_reasons: c.health.reasons, overridden: c.health.overridden,
    progress: c.plan.progress, planned_progress: c.plan.plannedProgress,
    start_date: p.start_date, end_date: p.end_date, forecast_end: c.plan.forecastEnd, baseline_end: c.variance?.baseEnd || null,
    key_milestone: c.plan.keyMilestone,
    approved_budget: c.budget.approved, forecast: round(c.budget.forecast, 0), actual: round(c.budget.actual, 0),
    top_risks: c.raid.topRisks, overdue_decisions: c.raid.overdueDecisions, overdue_actions: c.raid.overdueActions,
    high_items: c.raid.highCount, support_requests: open.map((s) => s.text), baselined: !!model.baseline,
  };
}

// ------------------------------------------------------------------ write-time rules
const LEAF_TYPES = ['task', 'subtask', 'milestone'];

/**
 * Validate a proposed task (create or update). `tasks` is the current raw task list (with predecessors).
 * Returns an array of error strings (empty = ok).
 */
export function validateTask(tasks, draft, id = null) {
  const errs = [];
  const byId = new Map(tasks.map((t) => [t.id, t]));
  if (draft.end_date < draft.start_date) errs.push('End date cannot be before start date');
  if (draft.type === 'milestone' && draft.end_date !== draft.start_date) errs.push('A milestone must have the same start and end date');
  if (draft.type === 'phase' && draft.parent_id) errs.push('A phase cannot have a parent');
  if (draft.parent_id) {
    const parent = byId.get(draft.parent_id);
    if (!parent) errs.push('Parent not found in this program');
    else {
      if (id && draft.parent_id === id) errs.push('A task cannot be its own parent');
      for (let p = parent, i = 0; p && id && i < 50; p = byId.get(p.parent_id), i++) {
        if (p.id === id) { errs.push('Parent would create a loop in the hierarchy'); break; }
      }
      if (parent.type === 'milestone') errs.push('A milestone cannot contain other items');
      if (draft.type === 'subtask' && parent.type !== 'task') errs.push('A subtask must sit under a task');
      if (draft.type === 'task' && parent.type !== 'phase') errs.push('A task must sit under a phase (or at the top level)');
    }
  } else if (draft.type === 'subtask') errs.push('A subtask needs a parent task');
  const preds = draft.predecessors || [];
  if (preds.length) {
    const hasChildren = id && tasks.some((t) => t.parent_id === id);
    if (draft.type === 'phase' || hasChildren) errs.push('Dependencies can only be set on leaf tasks and milestones, not on phases or parent tasks');
    for (const pid of preds) {
      const pt = byId.get(pid);
      if (!pt) { errs.push('A predecessor was not found in this program'); continue; }
      if (pid === id) errs.push('A task cannot depend on itself');
      if (!LEAF_TYPES.includes(pt.type) || tasks.some((t) => t.parent_id === pid)) errs.push(`"${pt.name}" is a phase/parent and cannot be a predecessor`);
    }
    const key = id || '__new__';
    const edges = [];
    for (const t of tasks) if (t.id !== id) for (const p of t.predecessors || []) edges.push([p, t.id]);
    for (const p of preds) edges.push([p, key]);
    const cyc = findCycle([...tasks.map((t) => t.id), key], edges);
    if (cyc) errs.push(`Circular dependency: ${cyc.map((x) => (x === key ? draft.name || 'this task' : byId.get(x)?.name)).join(' → ')}`);
  }
  return errs;
}

/** Push successors out so finish-to-start holds after `seedIds` moved. Returns [{id,start_date,end_date}]. */
export function cascadeShifts(tasks, seedIds) {
  const t = new Map(tasks.map((x) => [x.id, { id: x.id, type: x.type, start_date: x.start_date, end_date: x.end_date }]));
  const succ = new Map();
  for (const x of tasks) for (const p of x.predecessors || []) (succ.get(p) || succ.set(p, []).get(p)).push(x.id);
  const changed = new Map();
  const queue = [...seedIds];
  let guard = 0;
  while (queue.length && guard++ < 20000) {
    const pid = queue.shift();
    const p = t.get(pid);
    for (const sid of succ.get(pid) || []) {
      const s = t.get(sid);
      let need = requiredStart({ type: p.type, end: p.end_date }, s);
      if (s.type !== 'milestone') need = nextWorkday(need);
      if (s.start_date < need) {
        const dur = diffDays(s.start_date, s.end_date);
        s.start_date = need;
        s.end_date = addDays(need, dur);
        changed.set(sid, { id: sid, start_date: s.start_date, end_date: s.end_date });
        queue.push(sid);
      }
    }
  }
  return [...changed.values()];
}
