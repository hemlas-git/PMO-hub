import { h, date, datetime, num, money, days, signed, dataTable, emptyState } from '../dom.js';
import { get } from '../api.js';

const CATS = [['', 'All changes'], ['baseline', 'Baseline approvals'], ['material', 'Material edits'], ['status', 'Status changes'], ['progress', 'Progress & actuals']];
const CAT_BADGE = { baseline: 'b-blue', material: 'b-amber', status: 'b-green', progress: 'b-grey', access: 'b-grey' };
let cat = 'material';
let q = '';

export async function render(ctx) {
  const d = ctx.data;
  const v = d.variance;
  const cur = d.program.currency;
  const host = h('div');
  const tableHost = h('div');

  async function load() {
    tableHost.replaceChildren(h('div', { class: 'loading' }, 'Loading…'));
    const { entries } = await get(`/programs/${ctx.id}/audit?limit=500${cat ? `&category=${cat}` : ''}`);
    const needle = q.toLowerCase();
    const rows = entries.filter((e) => !needle || `${e.summary} ${e.entity_name} ${e.user_name} ${e.field}`.toLowerCase().includes(needle));
    const cols = [
      { key: 'at', label: 'When', render: (e) => h('span', { class: 'nowrap small' }, datetime(e.at)) },
      { key: 'who', label: 'Who', render: (e) => e.user_name },
      { key: 'cat', label: 'Type', render: (e) => h('span', { class: `badge ${CAT_BADGE[e.category]}` }, CATS.find((c) => c[0] === e.category)?.[1] || e.category) },
      { key: 'what', label: 'Change', render: (e) => h('div', e.summary || `${e.entity} ${e.entity_name}`, e.field && e.field !== 'baseline' ? h('div', { class: 'small' }, h('strong', e.field.replace(/_/g, ' ')), ': ', h('span', { class: 'muted' }, trunc(e.old_value) || '(empty)'), ' → ', trunc(e.new_value) || '(empty)') : null) },
    ];
    tableHost.replaceChildren(dataTable(cols, rows, { empty: 'No changes recorded for this filter.' }), h('p', { class: 'muted small' }, `${rows.length} entries shown (most recent first).`));
  }

  const filters = h('div', { class: 'filters' },
    h('label', { class: 'field' }, 'Show', h('select', { onChange: (e) => { cat = e.target.value; load(); } }, CATS.map(([k, l]) => h('option', { value: k, selected: cat === k }, l)))),
    h('label', { class: 'field' }, 'Search', h('input', { type: 'search', value: q, onInput: (e) => { q = e.target.value; load(); } })));

  const baselines = d.baselines.length
    ? h('ul', { class: 'plain' }, d.baselines.map((b) => h('li', h('strong', `v${b.version}`), ` approved ${datetime(b.approved_at)} by ${b.approved_by}`, b.note ? h('div', { class: 'muted small' }, b.note) : null)))
    : emptyState('No baseline yet', 'Approve a baseline to freeze the plan and track variance against it.');

  let variance;
  if (!v) variance = h('p', { class: 'muted' }, 'Variance appears after a baseline is approved.');
  else {
    const rows = v.changed.filter((t) => !t.added || t.type !== 'phase').slice(0, 200);
    const cols = [
      { key: 'wbs', label: 'WBS', render: (t) => h('span', { class: 'muted small' }, t.wbs) },
      { key: 'name', label: 'Item', render: (t) => h('span', t.name, t.added ? h('span', { class: 'badge b-blue', style: { marginLeft: '6px' } }, 'added') : null, t.removed ? h('span', { class: 'badge b-grey', style: { marginLeft: '6px' } }, 'removed') : null) },
      { key: 'bs', label: 'Baseline', render: (t) => (t.baseStart ? h('span', { class: 'small nowrap' }, `${date(t.baseStart)} → ${date(t.baseEnd)}`) : '') },
      { key: 'cs', label: 'Current', render: (t) => (t.start ? h('span', { class: 'small nowrap' }, `${date(t.start)} → ${date(t.end)}`) : '') },
      { key: 'sl', label: 'Finish variance', num: true, render: (t) => (t.endSlip !== undefined ? h('span', { class: t.endSlip > 0 ? 'bad' : t.endSlip < 0 ? 'good' : '' }, days(t.endSlip)) : '') },
      { key: 'ed', label: 'Effort variance (h)', num: true, render: (t) => (t.estDelta ? h('span', { class: t.estDelta > 0 ? 'bad' : 'good' }, signed(t.estDelta, 1)) : '') },
    ];
    variance = h('div',
      h('div', { class: 'grid g4' },
        kpi('Finish date', days(v.endSlip), `Baseline ${date(v.baseEnd)}`, v.endSlip > 0 ? 'bad' : ''),
        kpi('Planned effort', `${signed(v.hoursDelta)} h`, `Baseline ${num(v.baseHours)} h`, v.hoursDelta > 0 ? 'warn' : ''),
        kpi('Planned cost', signed(v.costDelta), `Baseline ${money(v.baseCost, cur, true)}`, v.costDelta > 0 ? 'warn' : ''),
        kpi('Approved budget', signed(v.budgetDelta), `Baseline ${money(v.baseBudget, cur, true)}`, v.budgetDelta ? 'warn' : '')),
      h('div', { style: { marginTop: '12px' } }, rows.length ? dataTable(cols, rows) : h('p', { class: 'muted' }, 'The current plan matches the baseline.')),
      h('p', { class: 'muted small' }, `Compared with baseline v${v.version}. Only items whose dates or effort differ are listed. The baseline itself is never edited — re-baselining creates a new version.`));
  }

  host.append(
    h('div', { class: 'card' }, h('h2', 'Variance against approved baseline'), variance),
    h('div', { class: 'grid g-main', style: { marginTop: '16px' } },
      h('div', { class: 'card', style: { marginTop: 0 } }, h('h2', 'Audit trail'), filters, tableHost),
      h('div', { class: 'card', style: { marginTop: 0 } }, h('h2', 'Baselines'), baselines)));
  await load();
  return host;
}

const trunc = (s) => (s && s.length > 90 ? `${s.slice(0, 90)}…` : s);
const kpi = (label, value, sub, cls = '') => h('div', { class: 'kpi' }, h('div', { class: 'label' }, label), h('div', { class: `value ${cls}` }, value), sub ? h('div', { class: 'sub' }, sub) : null);
