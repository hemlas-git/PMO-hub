-- PMO Hub schema (PostgreSQL 13+). Idempotent: safe to run on every start.

CREATE TABLE IF NOT EXISTS users (
  id            uuid PRIMARY KEY,
  email         text NOT NULL UNIQUE,
  name          text NOT NULL,
  password_hash text NOT NULL,
  global_role   text NOT NULL DEFAULT 'member'
                CHECK (global_role IN ('admin','portfolio_leader','program_manager','member')),
  active        boolean NOT NULL DEFAULT true,
  failed_logins int NOT NULL DEFAULT 0,
  locked_until  timestamptz,
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS sessions (
  token_hash text PRIMARY KEY,               -- sha256 of the cookie token; the raw token is never stored
  user_id    uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS settings (
  key   text PRIMARY KEY,
  value jsonb NOT NULL
);

CREATE TABLE IF NOT EXISTS programs (
  id                   uuid PRIMARY KEY,
  code                 text NOT NULL DEFAULT '',
  name                 text NOT NULL,
  status               text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','active','on_hold','complete')),
  sponsor              text NOT NULL DEFAULT '',
  manager              text NOT NULL DEFAULT '',
  delivery_approach    text NOT NULL DEFAULT 'hybrid' CHECK (delivery_approach IN ('waterfall','agile','hybrid')),
  start_date           date NOT NULL,
  end_date             date NOT NULL,
  currency             text NOT NULL DEFAULT 'USD',
  geography            text NOT NULL DEFAULT '',
  approved_budget      numeric(14,2),
  summary              text NOT NULL DEFAULT '',
  objectives           text NOT NULL DEFAULT '',
  outcomes             text NOT NULL DEFAULT '',
  success_measures     text NOT NULL DEFAULT '',
  scope                text NOT NULL DEFAULT '',
  exclusions           text NOT NULL DEFAULT '',
  governance           text NOT NULL DEFAULT '',
  constraints          text NOT NULL DEFAULT '',
  -- calculation assumptions: {contingency_pct, forecast_method, utilisation_pct, fx:{EUR:1.08}}
  assumptions          jsonb NOT NULL DEFAULT '{}'::jsonb,
  status_narrative     text NOT NULL DEFAULT '',
  narrative_updated_at timestamptz,
  narrative_updated_by text NOT NULL DEFAULT '',
  health_override      text CHECK (health_override IN ('green','amber','red')),
  health_override_reason text NOT NULL DEFAULT '',
  -- [{id,text,status:'open'|'resolved',needed_by,raised_on}]
  support_requests     jsonb NOT NULL DEFAULT '[]'::jsonb,
  -- {sections:{summary:true,...}, assumptions:[text]} -> generated content not yet reviewed
  proposal_state       jsonb NOT NULL DEFAULT '{}'::jsonb,
  baseline_id          uuid,
  created_by           uuid REFERENCES users(id),
  created_at           timestamptz NOT NULL DEFAULT now(),
  updated_at           timestamptz NOT NULL DEFAULT now(),
  CHECK (end_date >= start_date)
);

CREATE TABLE IF NOT EXISTS program_members (
  program_id uuid NOT NULL REFERENCES programs(id) ON DELETE CASCADE,
  user_id    uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role       text NOT NULL CHECK (role IN ('manager','lead','finance','viewer')),
  PRIMARY KEY (program_id, user_id)
);
CREATE INDEX IF NOT EXISTS program_members_user_idx ON program_members(user_id);

CREATE TABLE IF NOT EXISTS workstreams (
  id          uuid PRIMARY KEY,
  program_id  uuid NOT NULL REFERENCES programs(id) ON DELETE CASCADE,
  name        text NOT NULL,
  lead        text NOT NULL DEFAULT '',
  description text NOT NULL DEFAULT '',
  sort        int  NOT NULL DEFAULT 0,
  is_proposed boolean NOT NULL DEFAULT false
);
CREATE INDEX IF NOT EXISTS workstreams_program_idx ON workstreams(program_id);

CREATE TABLE IF NOT EXISTS resources (
  id                 uuid PRIMARY KEY,
  program_id         uuid NOT NULL REFERENCES programs(id) ON DELETE CASCADE,
  name               text NOT NULL,
  role               text NOT NULL DEFAULT '',
  rate               numeric(10,2),             -- hourly; NULL = missing rate (flagged)
  rate_currency      text NOT NULL DEFAULT '',  -- '' = program currency
  rate_assumed       boolean NOT NULL DEFAULT false,
  capacity_hrs_week  double precision NOT NULL DEFAULT 40,
  allocation_pct     int NOT NULL DEFAULT 100 CHECK (allocation_pct BETWEEN 0 AND 100),
  chargeable         boolean NOT NULL DEFAULT true,
  is_placeholder     boolean NOT NULL DEFAULT false,
  is_proposed        boolean NOT NULL DEFAULT false,
  sort               int NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS resources_program_idx ON resources(program_id);

CREATE TABLE IF NOT EXISTS tasks (
  id            uuid PRIMARY KEY,
  program_id    uuid NOT NULL REFERENCES programs(id) ON DELETE CASCADE,
  parent_id     uuid REFERENCES tasks(id) ON DELETE CASCADE,
  workstream_id uuid REFERENCES workstreams(id) ON DELETE SET NULL,
  resource_id   uuid REFERENCES resources(id) ON DELETE SET NULL,   -- owner / assignee
  type          text NOT NULL CHECK (type IN ('phase','task','subtask','milestone')),
  name          text NOT NULL,
  start_date    date NOT NULL,
  end_date      date NOT NULL,
  estimate_hrs  double precision NOT NULL DEFAULT 0 CHECK (estimate_hrs >= 0),
  actual_hrs    double precision NOT NULL DEFAULT 0 CHECK (actual_hrs >= 0),
  pct_complete  int NOT NULL DEFAULT 0 CHECK (pct_complete BETWEEN 0 AND 100),
  status        text NOT NULL DEFAULT 'not_started'
                CHECK (status IN ('not_started','in_progress','complete','blocked')),
  notes         text NOT NULL DEFAULT '',
  sort          int NOT NULL DEFAULT 0,
  is_proposed   boolean NOT NULL DEFAULT false,
  CHECK (end_date >= start_date)
);
CREATE INDEX IF NOT EXISTS tasks_program_idx ON tasks(program_id);

CREATE TABLE IF NOT EXISTS task_deps (
  task_id        uuid NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  predecessor_id uuid NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  PRIMARY KEY (task_id, predecessor_id),
  CHECK (task_id <> predecessor_id)
);

CREATE TABLE IF NOT EXISTS budget_lines (
  id                uuid PRIMARY KEY,
  program_id        uuid NOT NULL REFERENCES programs(id) ON DELETE CASCADE,
  category          text NOT NULL,
  description       text NOT NULL DEFAULT '',
  planned_amount    numeric(14,2) NOT NULL DEFAULT 0,
  actual_amount     numeric(14,2) NOT NULL DEFAULT 0,
  forecast_override numeric(14,2),             -- estimate-to-complete override; NULL = planned - actual
  is_assumption     boolean NOT NULL DEFAULT false,
  is_proposed       boolean NOT NULL DEFAULT false,
  notes             text NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS budget_lines_program_idx ON budget_lines(program_id);

CREATE TABLE IF NOT EXISTS raid_items (
  id            uuid PRIMARY KEY,
  program_id    uuid NOT NULL REFERENCES programs(id) ON DELETE CASCADE,
  type          text NOT NULL CHECK (type IN ('risk','assumption','issue','dependency','decision')),
  title         text NOT NULL,
  description   text NOT NULL DEFAULT '',
  owner         text NOT NULL DEFAULT '',
  status        text NOT NULL DEFAULT 'open' CHECK (status IN ('open','in_progress','closed')),
  impact        int CHECK (impact BETWEEN 1 AND 5),
  likelihood    int CHECK (likelihood BETWEEN 1 AND 5),
  response      text NOT NULL DEFAULT '',
  due_date      date,
  workstream_id uuid REFERENCES workstreams(id) ON DELETE SET NULL,
  is_proposed   boolean NOT NULL DEFAULT false,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS raid_program_idx ON raid_items(program_id);

CREATE TABLE IF NOT EXISTS raid_links (
  raid_id uuid NOT NULL REFERENCES raid_items(id) ON DELETE CASCADE,
  task_id uuid NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  PRIMARY KEY (raid_id, task_id)
);

CREATE TABLE IF NOT EXISTS baselines (
  id          uuid PRIMARY KEY,
  program_id  uuid NOT NULL REFERENCES programs(id) ON DELETE CASCADE,
  version     int  NOT NULL,
  approved_by text NOT NULL,
  approved_at timestamptz NOT NULL DEFAULT now(),
  note        text NOT NULL DEFAULT '',
  snapshot    jsonb NOT NULL,
  UNIQUE (program_id, version)
);

CREATE TABLE IF NOT EXISTS audit_log (
  id          serial PRIMARY KEY,
  program_id  uuid REFERENCES programs(id) ON DELETE CASCADE,   -- NULL for global (access/admin) events
  user_id     uuid,
  user_name   text NOT NULL DEFAULT '',
  at          timestamptz NOT NULL DEFAULT now(),
  category    text NOT NULL CHECK (category IN ('baseline','material','status','progress','access')),
  entity      text NOT NULL,
  entity_id   text NOT NULL DEFAULT '',
  entity_name text NOT NULL DEFAULT '',
  field       text NOT NULL DEFAULT '',
  old_value   text NOT NULL DEFAULT '',
  new_value   text NOT NULL DEFAULT '',
  summary     text NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS audit_program_idx ON audit_log(program_id, at DESC);
