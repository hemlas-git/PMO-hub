import { initDb, migrate, closeDb } from '../src/db.js';

await initDb();
await migrate();
console.log('Database schema is up to date.');
await closeDb();
