import express, { Router } from 'express';
import { z } from 'zod';
import { HttpError, canCreateProgram } from '../auth.js';
import { extractText, analyzeDocuments } from '../analyze.js';
import { config } from '../config.js';

const r = Router();
r.use((req, _res, next) => {
  if (!canCreateProgram(req.user)) throw new HttpError(403, 'You cannot create programs');
  next();
});

// Documents are processed in memory and never stored.
r.post('/extract', express.raw({ type: () => true, limit: '10mb' }), async (req, res) => {
  if (!Buffer.isBuffer(req.body) || !req.body.length) throw new HttpError(400, 'No file received');
  let name = 'document';
  try { name = decodeURIComponent(req.get('x-filename') || 'document').replace(/[^\w .()\-]/g, '_').slice(0, 120); } catch { /* keep default */ }
  const { text, truncated } = await extractText(req.body, name);
  res.json({ name, text, chars: text.length, truncated });
});

const analyzeSchema = z.object({
  documents: z.array(z.object({ name: z.string().trim().max(150), text: z.string().min(20).max(160000) })).min(1).max(10),
});
r.post('/analyze', async (req, res) => {
  const { documents } = analyzeSchema.parse(req.body);
  const out = await analyzeDocuments(documents);
  res.json({ ...out, ai_enabled: !!config.anthropic.key });
});

r.get('/status', (_req, res) => res.json({ ai_enabled: !!config.anthropic.key }));

export default r;
