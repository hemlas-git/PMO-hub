BUILT · DEMO

# Program and portfolio dashboard (PMO Hub)

Turns a few answers, or an uploaded SOW or charter, into a draft plan, budget forecast and RAID log, labelled as a proposal until approved. Plan, cost, risks and health stay connected, so one change updates the portfolio view of health, budget and decisions needed. Built with Claude Code on sample data.
