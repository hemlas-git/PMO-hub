export class ApiError extends Error {
  constructor(message, status, errors = []) { super(message); this.status = status; this.errors = errors; }
}

export const getDisplayName = () => { try { return localStorage.getItem('pmo_name') || ''; } catch { return ''; } };
export const setDisplayName = (n) => { try { localStorage.setItem('pmo_name', n); } catch { /* ignore */ } };
const nameHeader = () => (getDisplayName() ? { 'X-Display-Name': encodeURIComponent(getDisplayName()) } : {});

export async function api(method, path, body) {
  let res;
  try {
    res = await fetch(`/api${path}`, {
      method, credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'pmo', ...nameHeader() },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
  } catch {
    throw new ApiError('Network error — check your connection and try again', 0);
  }
  let data = null;
  try { data = await res.json(); } catch { /* empty body */ }
  if (!res.ok) {
    if (res.status === 401 && !path.startsWith('/auth/login')) window.dispatchEvent(new Event('pmo:unauth'));
    throw Object.assign(new ApiError(data?.error || `Request failed (${res.status})`, res.status, data?.errors || []), { data });
  }
  return data;
}
/** Upload a File as raw bytes (used for document analysis). */
export async function upload(path, file) {
  let res;
  try {
    res = await fetch(`/api${path}`, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/octet-stream', 'X-Requested-With': 'pmo', ...nameHeader(), 'X-Filename': encodeURIComponent(file.name) }, body: file });
  } catch { throw new ApiError('Network error — check your connection and try again', 0); }
  let data = null;
  try { data = await res.json(); } catch { /* empty */ }
  if (!res.ok) throw new ApiError(data?.error || `Upload failed (${res.status})`, res.status, data?.errors || []);
  return data;
}
export const get =(p) => api('GET', p);
export const post = (p, b) => api('POST', p, b ?? {});
export const patch = (p, b) => api('PATCH', p, b);
export const put = (p, b) => api('PUT', p, b);
export const del = (p) => api('DELETE', p);
