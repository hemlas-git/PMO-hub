// Demo data: four programs at different stages, built through the same code path as the UI
// (proposal -> baseline) and then "lived in" so health, variance, RAID and forecasts look real.
// All dates are relative to today so the sample never goes stale. LOCAL/DEMO USE ONLY.
import crypto from 'node:crypto';
import { query, tx } from './db.js';
import { config } from './config.js';
import { hashPassword } from './auth.js';
import { addDays, diffDays, workdays, cascadeShifts, nextWorkday, todayStr } from './calc.js';
import { generateProposal } from './proposal.js';
import { createProgram, approveBaseline, logAudit } from './service.js';

const uid = () => crypto.randomUUID();
const today = () => todayStr();
const d = (offset) => nextWorkday(addDays(today(), offset));
const hash = (s) => [...s].reduce((a, c) => a + c.charCodeAt(0), 0);

const PROGRAMS = [
  {
    key: 'p1', manager: 'pm.alex', lag: 6, over: 1.1, slip: { ws: 'Data Migration', days: 14 }, baselineAgo: 150,
    answers: {
      name: 'Customer Platform Modernisation', program_type: 'technology', delivery_approach: 'hybrid',
      sponsor: 'Dana Whitfield (CIO)', manager: 'Alex Rivera', start_date: d(-150), end_date: d(200), currency: 'USD', geography: 'North America and UK',
      objectives: 'Replace the legacy CRM with a single customer platform\nReduce customer onboarding time from 12 days to 4\nRetire three legacy systems and cut run costs',
      outcomes: 'Unified customer record live for all sales and service teams\nSelf-service onboarding portal live\nLegacy CRM decommissioned',
      scope: 'Customer data model and migration\nOnboarding portal and APIs\nIdentity and access integration\nStaff training and cutover',
      exclusions: 'Billing system replacement\nMarketing automation changes',
      constraints: 'No production changes during quarter-end freeze\nLegacy CRM vendor support ends in 14 months',
      workstreams: [{ name: 'Platform Engineering', lead: 'Priya Nair' }, { name: 'Data Migration', lead: 'Tom Becker' }, { name: 'Customer Experience', lead: 'Aisha Khan' }, { name: 'Integration & Security', lead: 'Luis Ortega' }],
      team_roles: [{ role: 'Business Analyst', count: 1, name: 'Sam Idowu', rate: 78 }, { role: 'Solution Architect', count: 1, name: 'Mei Tanaka', rate: 125 }, { role: 'Software Engineer', count: 3 }, { role: 'QA Analyst', count: 1 }],
      dependencies: [{ name: 'Identity provider upgrade (Enterprise IT)', description: 'SSO upgrade must be complete before portal go-live', owner: 'Enterprise IT', needed_by: d(40) }, { name: 'Data warehouse refresh (Analytics team)', description: 'Needed for reporting migration', owner: 'Analytics', needed_by: d(90) }],
      budget_pad: 1.02,
    },
    after: async (q, pid, users) => {
      await rename(q, pid, 'TBC – Software Engineer 1', 'Jordan Lee');
      await rename(q, pid, 'TBC – Software Engineer 2', 'Chris Alvarez', { allocation_pct: 50 }); // deliberately over-allocated
      await rename(q, pid, 'TBC – Software Engineer 3', 'Contractor – DevOps', { rate: null }); // deliberately missing rate
      await rename(q, pid, 'TBC – QA Analyst', 'Ravi Menon');
      await q.query('UPDATE programs SET status_narrative=$2, narrative_updated_at=now(), narrative_updated_by=$3, support_requests=$4::jsonb WHERE id=$1', [pid,
        'Platform build is on track and the portal beta started this month. Data Migration has slipped two weeks after poor legacy data quality was found; a contractor surge is proposed to recover. Identity provider upgrade remains the main external dependency.',
        'Alex Rivera', JSON.stringify([{ id: uid(), text: 'Approve $45k contractor surge to recover the Data Migration slippage', status: 'open', needed_by: d(10), raised_on: d(-5) }, { id: uid(), text: 'Escalate the identity provider upgrade date with Enterprise IT leadership', status: 'open', needed_by: d(20), raised_on: d(-12) }])]);
      await addBudget(q, pid, { category: 'Contractor surge (change request)', description: 'Data Migration recovery — pending SteerCo approval', planned_amount: 45000, actual_amount: 12000, notes: 'Added after baseline' });
      await addRaid(q, pid, { type: 'risk', title: 'Legacy CRM data quality prevents migration cutover', description: '30% of customer records fail validation rules.', owner: 'Tom Becker', impact: 4, likelihood: 4, response: 'Data cleansing sprint; contractor surge requested.', due_date: d(14), status: 'in_progress' });
      await addRaid(q, pid, { type: 'decision', title: 'Select SSO approach for the customer portal', owner: 'Dana Whitfield (CIO)', due_date: d(-9), response: 'Options paper circulated; awaiting SteerCo decision.' });
      await addRaid(q, pid, { type: 'issue', title: 'Test environment unavailable two days a week', owner: 'Luis Ortega', impact: 3, status: 'in_progress', due_date: d(-4), response: 'Infrastructure team investigating capacity.' });
    },
  },
  {
    key: 'p2', manager: 'pm.sam', lag: 0, over: 1.0, slip: null, baselineAgo: 100,
    answers: {
      name: 'EMEA Finance Process Transformation', program_type: 'transformation', delivery_approach: 'waterfall',
      sponsor: 'Helena Brandt (CFO EMEA)', manager: 'Sam Chen', start_date: d(-100), end_date: d(120), currency: 'EUR', geography: 'UK, Germany, France',
      objectives: 'Standardise order-to-cash and procure-to-pay across three countries\nShorten month-end close from 9 to 5 working days',
      outcomes: 'Common finance processes adopted in all three countries\nClose calendar of 5 days achieved for two consecutive months',
      scope: 'Process design and harmonisation\nShared-service hand-offs\nTraining and adoption support',
      exclusions: 'ERP upgrade\nTax compliance changes',
      constraints: 'Works council consultation in Germany and France',
      workstreams: [{ name: 'Order-to-Cash', lead: 'Marco Bellini' }, { name: 'Procure-to-Pay', lead: 'Ines Duarte' }, { name: 'Financial Close', lead: 'Oskar Lindqvist' }, { name: 'Change & Training', lead: 'Grace Okafor' }],
      team_roles: [{ role: 'Change Manager', count: 1, name: 'Grace Okafor', rate: 85 }, { role: 'Business Analyst', count: 2, rate: 70 }, { role: 'Process Specialist', count: 2, rate: 72 }, { role: 'Training Lead', count: 1, name: 'Elena Petrova', rate: 68 }],
      dependencies: [{ name: 'Works council consultation outcome', owner: 'HR EMEA', needed_by: d(25) }],
      budget_pad: 1.05,
    },
    after: async (q, pid) => {
      await q.query("UPDATE resources SET rate_currency='EUR' WHERE program_id=$1 AND chargeable", [pid]);
      await q.query('UPDATE programs SET status_narrative=$2, narrative_updated_at=now(), narrative_updated_by=$3 WHERE id=$1', [pid, 'Design workshops completed in all three countries and the pilot starts next month. Works council consultation is progressing to plan. Spend is tracking just under forecast.', 'Sam Chen']);
      await addRaid(q, pid, { type: 'risk', title: 'Pilot team capacity clashes with year-end close', owner: 'Oskar Lindqvist', impact: 3, likelihood: 3, response: 'Schedule pilot outside close weeks.', due_date: d(21), status: 'in_progress' });
    },
  },
  {
    key: 'p3', manager: 'pm.sam', lag: 20, over: 1.28, slip: { ws: 'Construction', days: 28, any: true }, baselineAgo: 220,
    answers: {
      name: 'Data Centre Exit', program_type: 'infrastructure', delivery_approach: 'waterfall',
      sponsor: 'Robert Hale (COO)', manager: 'Sam Chen', start_date: d(-220), end_date: d(60), currency: 'GBP', geography: 'UK',
      objectives: 'Vacate the Reading data centre before lease expiry\nMove 85% of workloads to cloud and 15% to colocation',
      outcomes: 'All workloads migrated and Reading site handed back\nAnnual hosting cost reduced by 30%',
      scope: 'Workload assessment and migration waves\nColocation fit-out\nDecommissioning and site hand-back',
      exclusions: 'Application re-architecture',
      constraints: 'Lease expires in 9 months\nChange freeze in December',
      workstreams: [{ name: 'Cloud Migration', lead: 'Neil Parker' }, { name: 'Colocation Fit-out', lead: 'Sandra Wu' }, { name: 'Decommissioning', lead: 'Hugh Bell' }],
      team_roles: [{ role: 'Engineer', count: 3, rate: 88 }, { role: 'Procurement Specialist', count: 1, name: 'Dev Patel', rate: 72 }, { role: 'Health & Safety Officer', count: 1, name: 'Carla Jones', rate: 70 }],
      dependencies: [{ name: 'Colocation provider rack delivery', owner: 'Sandra Wu', needed_by: d(-30) }],
      budget_pad: 1.0,
    },
    after: async (q, pid) => {
      await rename(q, pid, 'TBC – Engineer 1', 'Kieran Doyle');
      await rename(q, pid, 'TBC – Engineer 2', 'Anita Rao');
      await rename(q, pid, 'TBC – Engineer 3', 'Ben Fraser');
      await q.query('UPDATE programs SET status_narrative=$2, narrative_updated_at=now(), narrative_updated_by=$3, support_requests=$4::jsonb WHERE id=$1', [pid,
        'Migration waves 1 and 2 are late because colocation racks arrived five weeks behind plan. Forecast completion is now beyond the lease expiry and costs are running above budget. SteerCo decision needed on a short lease extension.',
        'Sam Chen', JSON.stringify([{ id: uid(), text: 'Decide on a 3-month lease extension at Reading (cost £180k) or fund overtime to protect the exit date', status: 'open', needed_by: d(7), raised_on: d(-14) }])]);
      await addRaid(q, pid, { type: 'risk', title: 'Lease expires before decommissioning completes', description: 'Landlord penalty clause applies after expiry.', owner: 'Robert Hale (COO)', impact: 5, likelihood: 4, response: 'Negotiate extension; prepare overtime plan.', due_date: d(7), status: 'in_progress' });
      await addRaid(q, pid, { type: 'decision', title: 'Approve lease extension or overtime funding', owner: 'Robert Hale (COO)', due_date: d(-10) });
      await addRaid(q, pid, { type: 'issue', title: 'Colocation racks delivered five weeks late', owner: 'Sandra Wu', impact: 4, status: 'in_progress', due_date: d(-20), response: 'Provider has committed to a revised delivery plan.' });
      await addRaid(q, pid, { type: 'issue', title: 'Two legacy applications lack documented dependencies', owner: 'Neil Parker', impact: 3, status: 'open', due_date: d(-3) });
    },
  },
  {
    key: 'p4', manager: 'pm.alex', draft: true,
    answers: {
      name: 'Customer Loyalty Programme Relaunch', program_type: 'product', delivery_approach: 'hybrid',
      sponsor: 'Imani Clarke (CMO)', manager: 'Alex Rivera', start_date: d(21), end_date: d(300), currency: 'USD', geography: 'North America',
      objectives: 'Relaunch the loyalty programme with tiered rewards\nIncrease repeat purchase rate by 12%',
      outcomes: 'New loyalty app and rewards catalogue live\nPartner reward integrations signed',
      scope: 'Rewards design and partner integrations\nMobile app features\nLaunch campaign',
      exclusions: 'Point-of-sale hardware changes',
      constraints: 'Launch must land before the holiday trading period',
      workstreams: [{ name: 'Rewards & Partners', lead: 'Zoe Hart' }, { name: 'Mobile App', lead: 'Kamal Singh' }, { name: 'Launch & Marketing', lead: '' }],
      team_roles: [],
      dependencies: [{ name: 'Partner contract approvals (Legal)', owner: 'Legal', needed_by: d(80) }],
    },
  },
];

async function rename(q, pid, from, to, extra = {}) {
  const sets = ['name=$3', 'is_placeholder=false'];
  const vals = [pid, from, to];
  for (const [k, v] of Object.entries(extra)) { vals.push(v); sets.push(`${k}=$${vals.length}`); }
  if ('rate' in extra) sets.push('rate_assumed=false');
  await q.query(`UPDATE resources SET ${sets.join(', ')} WHERE program_id=$1 AND name=$2`, vals);
}
async function addBudget(q, pid, b) {
  await q.query('INSERT INTO budget_lines (id,program_id,category,description,planned_amount,actual_amount,notes) VALUES ($1,$2,$3,$4,$5,$6,$7)', [uid(), pid, b.category, b.description || '', b.planned_amount, b.actual_amount || 0, b.notes || '']);
}
async function addRaid(q, pid, r) {
  await q.query(`INSERT INTO raid_items (id,program_id,type,title,description,owner,status,impact,likelihood,response,due_date) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
    [uid(), pid, r.type, r.title, r.description || '', r.owner || '', r.status || 'open', r.impact || null, r.likelihood || null, r.response || '', r.due_date || null]);
}

const expected = (s, e, t) => (t < s ? 0 : t >= e ? 100 : Math.round((100 * workdays(s, t).length) / (workdays(s, e).length || 1)));

/** Move the programme forward in time: progress, actuals, spend, closed historic RAID. */
async function simulate(q, pid, cfg) {
  const t = today();
  const tasks = await q.query('SELECT * FROM tasks WHERE program_id=$1', [pid]);
  const parents = new Set(tasks.map((x) => x.parent_id).filter(Boolean));
  const deps = await q.query('SELECT d.task_id, d.predecessor_id FROM task_deps d JOIN tasks x ON x.id=d.task_id WHERE x.program_id=$1', [pid]);
  const done = new Map();
  for (const x of tasks.filter((x) => !parents.has(x.id) && x.type !== 'milestone' && x.type !== 'phase')) {
    const exp = expected(x.start_date, x.end_date, t);
    const h = hash(x.id);
    let pct = exp >= 100 ? (cfg.lag > 12 && h % 3 === 0 ? 85 : 100) : exp === 0 ? 0 : Math.max(0, Math.min(99, exp - cfg.lag + (h % 7) - 3));
    if (exp > 0 && exp < 100 && pct === 0) pct = 3;
    const actual = Math.round(x.estimate_hrs * (pct / 100) * cfg.over * (1 + ((h % 11) - 5) / 100));
    done.set(x.id, pct >= 100);
    await q.query('UPDATE tasks SET pct_complete=$2, actual_hrs=$3, status=$4 WHERE id=$1', [x.id, pct, actual, pct >= 100 ? 'complete' : pct > 0 ? 'in_progress' : 'not_started']);
  }
  for (const m of tasks.filter((x) => x.type === 'milestone')) {
    const preds = deps.filter((x) => x.task_id === m.id).map((x) => x.predecessor_id);
    if (m.end_date <= t && preds.every((p) => done.get(p) ?? false)) {
      await q.query("UPDATE tasks SET status='complete', pct_complete=100 WHERE id=$1", [m.id]);
      done.set(m.id, true);
    }
  }
  // non-labour spend follows elapsed time
  const [p] = await q.query('SELECT start_date,end_date FROM programs WHERE id=$1', [pid]);
  const frac = Math.max(0, Math.min(1, diffDays(p.start_date, t) / Math.max(1, diffDays(p.start_date, p.end_date))));
  await q.query('UPDATE budget_lines SET actual_amount=round(planned_amount*$2*$3) WHERE program_id=$1', [pid, frac, cfg.over]);
  // historic RAID: decisions/dependencies done, risk responses underway
  await q.query("UPDATE raid_items SET status='closed' WHERE program_id=$1 AND type IN ('decision','dependency') AND due_date < $2", [pid, t]);
  await q.query("UPDATE raid_items SET status='in_progress', due_date=$2 WHERE program_id=$1 AND type='risk' AND due_date < $2 AND status='open'", [pid, addDays(t, 28)]);
}

async function slip(q, user, pid, cfg) {
  const rows = await q.query(
    `SELECT t.*, w.name AS ws FROM tasks t LEFT JOIN workstreams w ON w.id=t.workstream_id
     WHERE t.program_id=$1 AND t.type='subtask' AND t.status<>'complete' AND t.pct_complete<100 ORDER BY t.start_date`, [pid]);
  const pick = rows.find((r) => cfg.any || (r.ws || '').includes(cfg.ws)) || rows[0];
  if (!pick) return;
  const all = await q.query('SELECT * FROM tasks WHERE program_id=$1', [pid]);
  const deps = await q.query('SELECT d.task_id, d.predecessor_id FROM task_deps d JOIN tasks x ON x.id=d.task_id WHERE x.program_id=$1', [pid]);
  const tasks = all.map((x) => ({ ...x, predecessors: deps.filter((e) => e.task_id === x.id).map((e) => e.predecessor_id) }));
  const t0 = tasks.find((x) => x.id === pick.id);
  const newEnd = addDays(t0.end_date, cfg.days);
  await q.query('UPDATE tasks SET end_date=$2 WHERE id=$1', [pick.id, newEnd]);
  await logAudit(q, user, pid, { category: 'material', entity: 'Task', entity_id: pick.id, entity_name: pick.name, field: 'end_date', old: t0.end_date, new: newEnd, summary: `Task "${pick.name}": end date changed (forecast slip)` });
  t0.end_date = newEnd;
  for (const s of cascadeShifts(tasks, [pick.id])) {
    await q.query('UPDATE tasks SET start_date=$2, end_date=$3 WHERE id=$1', [s.id, s.start_date, s.end_date]);
  }
}

export async function seedDemo() {
  const pw = await hashPassword(config.demoPassword);
  const mk = async (email, name, role) => {
    const id = uid();
    await query('INSERT INTO users (id,email,name,password_hash,global_role) VALUES ($1,$2,$3,$4,$5)', [id, `${email}@demo.test`, name, pw, role]);
    return { id, name, email };
  };
  const users = {
    admin: await mk('admin', 'Avery Admin', 'admin'),
    steerco: await mk('steerco', 'Morgan Okoye (SteerCo)', 'portfolio_leader'),
    'pm.alex': await mk('pm.alex', 'Alex Rivera', 'program_manager'),
    'pm.sam': await mk('pm.sam', 'Sam Chen', 'program_manager'),
    lead: await mk('lead', 'Priya Nair', 'member'),
    finance: await mk('finance', 'Fiona Finance', 'member'),
  };
  await query("INSERT INTO settings (key,value) VALUES ('portfolio',$1::jsonb) ON CONFLICT (key) DO NOTHING", [JSON.stringify({ base_currency: 'USD', fx: { EUR: 1.08, GBP: 1.27 } })]);

  const ids = {};
  for (const cfg of PROGRAMS) {
    const pm = users[cfg.manager];
    const a = { ...cfg.answers };
    const prop = generateProposal({ ...a, budget_guidance: null });
    a.budget_guidance = Math.ceil((prop.stats.withContingency * (a.budget_pad || 1)) / 1000) * 1000;
    delete a.budget_pad;
    const { id } = await tx((t) => createProgram(t, pm, a, {}));
    ids[cfg.key] = id;
    if (cfg.draft) {
      await query("INSERT INTO program_members (program_id,user_id,role) VALUES ($1,$2,'viewer') ON CONFLICT DO NOTHING", [id, users.finance.id]);
      continue;
    }
    await tx((t) => approveBaseline(t, pm, id, { note: 'Initial baseline approved at SteerCo', confirm: true }));
    await query("UPDATE baselines SET approved_at = now() - ($2 || ' days')::interval WHERE program_id=$1", [id, String(cfg.baselineAgo)]);
    await query("UPDATE audit_log SET at = now() - ($2 || ' days')::interval WHERE program_id=$1", [id, String(cfg.baselineAgo)]);
    await simulate({ query }, id, cfg);
    if (cfg.slip) await slip({ query }, pm, id, cfg.slip);
    await cfg.after({ query }, id, users);
    await query("INSERT INTO program_members (program_id,user_id,role) VALUES ($1,$2,'finance') ON CONFLICT DO NOTHING", [id, users.finance.id]);
    if (cfg.key === 'p1') await query("INSERT INTO program_members (program_id,user_id,role) VALUES ($1,$2,'lead') ON CONFLICT DO NOTHING", [id, users.lead.id]);
  }
  await query("UPDATE programs SET status_narrative=$2, narrative_updated_at=now(), narrative_updated_by='Alex Rivera' WHERE id=$1 AND status_narrative=''", [ids.p4, 'Draft proposal — not yet reviewed or baselined.']);
  return ids;
}
