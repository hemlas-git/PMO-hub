import crypto from 'node:crypto';
import { promisify } from 'node:util';
import { query } from './db.js';
import { config } from './config.js';

const scrypt = promisify(crypto.scrypt);
const COOKIE = 'pmo_sid';

export class HttpError extends Error {
  constructor(status, message, extra = {}) { super(message); this.status = status; this.extra = extra; }
}

export async function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const key = await scrypt(pw, salt, 64, { N: 16384, r: 8, p: 1 });
  return `scrypt$${salt.toString('base64')}$${key.toString('base64')}`;
}

export async function verifyPassword(pw, stored) {
  const [alg, s, k] = String(stored).split('$');
  if (alg !== 'scrypt') return false;
  const key = await scrypt(pw, Buffer.from(s, 'base64'), 64, { N: 16384, r: 8, p: 1 });
  const expected = Buffer.from(k, 'base64');
  return key.length === expected.length && crypto.timingSafeEqual(key, expected);
}

const sha = (t) => crypto.createHash('sha256').update(t).digest('hex');

function parseCookies(header = '') {
  const out = {};
  for (const part of header.split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

export async function startSession(res, userId) {
  const token = crypto.randomBytes(32).toString('hex');
  const expires = new Date(Date.now() + config.sessionHours * 3600e3);
  await query('INSERT INTO sessions (token_hash, user_id, expires_at) VALUES ($1,$2,$3)', [sha(token), userId, expires.toISOString()]);
  res.cookie(COOKIE, token, { httpOnly: true, sameSite: 'lax', secure: config.secureCookies, expires, path: '/' });
}

export async function endSession(req, res) {
  const token = parseCookies(req.headers.cookie)[COOKIE];
  if (token) await query('DELETE FROM sessions WHERE token_hash=$1', [sha(token)]);
  res.clearCookie(COOKIE, { path: '/' });
}

let sharedUser = null;
/** Login-free mode: every visitor acts as one shared administrator account. */
async function getSharedUser() {
  if (sharedUser) return sharedUser;
  let [u] = await query("SELECT id,email,name,global_role FROM users WHERE email='shared@pmo.local'");
  if (!u) {
    const id = crypto.randomUUID();
    // random, never-disclosed password: nobody can sign in as this account through the login form
    await query('INSERT INTO users (id,email,name,password_hash,global_role) VALUES ($1,$2,$3,$4,$5)', [id, 'shared@pmo.local', 'Shared user', await hashPassword(crypto.randomBytes(24).toString('hex')), 'admin']);
    u = { id, email: 'shared@pmo.local', name: 'Shared user', global_role: 'admin' };
  }
  return (sharedUser = u);
}

export async function loadUser(req, _res, next) {
  if (!config.requireLogin) {
    const u = await getSharedUser();
    let display = '';
    try { display = decodeURIComponent(req.get('x-display-name') || '').replace(/[^\p{L}\p{N} .'\-]/gu, '').trim().slice(0, 60); } catch { /* ignore */ }
    req.user = { ...u, name: display || u.name };
    return next();
  }
  req.user = null;
  const token = parseCookies(req.headers.cookie)[COOKIE];
  if (token) {
    const [u] = await query(
      `SELECT u.id, u.email, u.name, u.global_role FROM sessions s JOIN users u ON u.id = s.user_id
       WHERE s.token_hash=$1 AND s.expires_at > now() AND u.active`, [sha(token)]);
    req.user = u || null;
  }
  next();
}

export function requireAuth(req, _res, next) {
  if (!req.user) throw new HttpError(401, 'Please sign in');
  next();
}
export function requireAdmin(req, _res, next) {
  if (req.user?.global_role !== 'admin') throw new HttpError(403, 'Administrator access required');
  next();
}

/** CSRF defence for cookie auth: mutating requests need a custom header and a same-origin Origin. */
export function csrfGuard(req, _res, next) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  if (req.get('x-requested-with') !== 'pmo') throw new HttpError(403, 'Missing CSRF header');
  const origin = req.get('origin');
  if (origin) {
    let host;
    try { host = new URL(origin).host; } catch { host = ''; }
    if (host !== req.get('host')) throw new HttpError(403, 'Cross-origin request blocked');
  }
  next();
}

// ------------------------------------------------------------ login throttling (per IP, in memory)
const attempts = new Map();
export function throttleLogin(req, _res, next) {
  const now = Date.now();
  const key = req.ip;
  const rec = (attempts.get(key) || []).filter((t) => now - t < 15 * 60e3);
  if (rec.length >= 20) throw new HttpError(429, 'Too many sign-in attempts. Try again later.');
  rec.push(now);
  attempts.set(key, rec);
  if (attempts.size > 5000) attempts.clear();
  next();
}

// ------------------------------------------------------------ program access
// Effective program role: admin | manager | lead | finance | viewer | portfolio (leader without membership)
export async function programRole(user, programId) {
  if (user.global_role === 'admin') return 'admin';
  const [m] = await query('SELECT role FROM program_members WHERE program_id=$1 AND user_id=$2', [programId, user.id]);
  if (m) return m.role;
  return user.global_role === 'portfolio_leader' ? 'portfolio' : null;
}

export const CAPS = {
  charter: ['admin', 'manager'],
  plan: ['admin', 'manager', 'lead'],
  resources: ['admin', 'manager', 'finance'],
  raid: ['admin', 'manager', 'lead'],
  baseline: ['admin', 'manager', 'portfolio'],
  delete: ['admin', 'manager'],
};
export const capsFor = (role) => Object.fromEntries(Object.entries(CAPS).map(([k, v]) => [k, v.includes(role)]));

/** Programs the user may see. Admins and portfolio leaders see all; others see memberships only. */
export async function accessibleProgramIds(user) {
  if (user.global_role === 'admin' || user.global_role === 'portfolio_leader') {
    return (await query('SELECT id FROM programs')).map((r) => r.id);
  }
  return (await query('SELECT program_id AS id FROM program_members WHERE user_id=$1', [user.id])).map((r) => r.id);
}

export const canCreateProgram = (u) => ['admin', 'portfolio_leader', 'program_manager'].includes(u.global_role);
