import { Router } from 'express';
import crypto from 'node:crypto';
import { query } from '../db.js';
import { HttpError, hashPassword, verifyPassword, startSession, endSession, requireAuth, requireAdmin, throttleLogin, canCreateProgram } from '../auth.js';
import { loginSchema, changePasswordSchema, userCreateSchema, userPatchSchema, membersSchema, portfolioSettingsSchema } from '../validate.js';
import { logAudit } from '../service.js';
import { config } from '../config.js';

export const authRouter = Router();
export const adminRouter = Router();

const DUMMY_HASH = 'scrypt$AAAAAAAAAAAAAAAAAAAAAA==$' + Buffer.alloc(64).toString('base64');
const publicUser = (u) => ({ id: u.id, email: u.email, name: u.name, global_role: u.global_role, can_create: canCreateProgram(u) });

authRouter.post('/login', throttleLogin, async (req, res) => {
  const { email, password } = loginSchema.parse(req.body);
  const [u] = await query('SELECT * FROM users WHERE email=$1', [email]);
  const locked = u?.locked_until && new Date(u.locked_until) > new Date();
  // always run a hash so response time doesn't reveal whether the account exists
  const ok = await verifyPassword(password, u?.password_hash || DUMMY_HASH);
  if (!u || !u.active || locked || !ok) {
    if (u && !ok && !locked) {
      const fails = u.failed_logins + 1;
      await query('UPDATE users SET failed_logins=$2, locked_until=$3 WHERE id=$1', [u.id, fails >= 5 ? 0 : fails, fails >= 5 ? new Date(Date.now() + 15 * 60e3).toISOString() : null]);
    }
    throw new HttpError(401, locked ? 'Account temporarily locked. Try again in 15 minutes.' : 'Invalid email or password');
  }
  await query('UPDATE users SET failed_logins=0, locked_until=NULL WHERE id=$1', [u.id]);
  await startSession(res, u.id);
  res.json({ user: publicUser(u) });
});

authRouter.post('/logout', async (req, res) => { await endSession(req, res); res.json({ ok: true }); });

authRouter.get('/me', (req, res) => {
  if (!req.user) return res.status(401).json({ error: 'Not signed in' });
  res.json({ user: publicUser(req.user), login_required: config.requireLogin });
});

authRouter.post('/password', requireAuth, async (req, res) => {
  const { current, next } = changePasswordSchema.parse(req.body);
  const [u] = await query('SELECT password_hash FROM users WHERE id=$1', [req.user.id]);
  if (!(await verifyPassword(current, u.password_hash))) throw new HttpError(422, 'Current password is incorrect');
  await query('UPDATE users SET password_hash=$2 WHERE id=$1', [req.user.id, await hashPassword(next)]);
  await query('DELETE FROM sessions WHERE user_id=$1', [req.user.id]);
  await startSession(res, req.user.id);
  res.json({ ok: true });
});

// ------------------------------------------------------------------ admin
adminRouter.use(requireAuth, requireAdmin);

adminRouter.get('/users', async (_req, res) => {
  res.json({ users: await query('SELECT id,email,name,global_role,active,created_at FROM users ORDER BY name') });
});

adminRouter.post('/users', async (req, res) => {
  const d = userCreateSchema.parse(req.body);
  const [dup] = await query('SELECT 1 AS x FROM users WHERE email=$1', [d.email]);
  if (dup) throw new HttpError(422, 'A user with that email already exists');
  const id = crypto.randomUUID();
  await query('INSERT INTO users (id,email,name,password_hash,global_role) VALUES ($1,$2,$3,$4,$5)', [id, d.email, d.name, await hashPassword(d.password), d.global_role]);
  await logAudit({ query }, req.user, null, { category: 'access', entity: 'User', entity_id: id, entity_name: d.email, summary: `User created (${d.global_role})` });
  res.status(201).json({ id });
});

adminRouter.patch('/users/:id', async (req, res) => {
  const d = userPatchSchema.parse(req.body);
  const [u] = await query('SELECT * FROM users WHERE id=$1', [req.params.id]);
  if (!u) throw new HttpError(404, 'User not found');
  if (u.id === req.user.id && (d.active === false || (d.global_role && d.global_role !== 'admin'))) throw new HttpError(422, 'You cannot remove your own administrator access');
  const sets = []; const vals = [u.id];
  for (const k of ['name', 'global_role', 'active']) if (d[k] !== undefined) { vals.push(d[k]); sets.push(`${k}=$${vals.length}`); }
  if (d.password) { vals.push(await hashPassword(d.password)); sets.push(`password_hash=$${vals.length}`, 'failed_logins=0', 'locked_until=NULL'); }
  if (sets.length) await query(`UPDATE users SET ${sets.join(',')} WHERE id=$1`, vals);
  if (d.password || d.active === false) await query('DELETE FROM sessions WHERE user_id=$1', [u.id]);
  await logAudit({ query }, req.user, null, { category: 'access', entity: 'User', entity_id: u.id, entity_name: u.email, summary: `User updated: ${Object.keys(d).map((k) => (k === 'password' ? 'password reset' : `${k}=${d[k]}`)).join(', ')}` });
  res.json({ ok: true });
});

adminRouter.get('/programs', async (_req, res) => {
  res.json({ programs: await query('SELECT id, code, name FROM programs ORDER BY name') });
});
adminRouter.get('/programs/:pid/members', async (req, res) => {
  res.json({ members: await query('SELECT user_id, role FROM program_members WHERE program_id=$1', [req.params.pid]) });
});
adminRouter.put('/programs/:pid/members', async (req, res) => {
  const { members } = membersSchema.parse(req.body);
  const [p] = await query('SELECT name FROM programs WHERE id=$1', [req.params.pid]);
  if (!p) throw new HttpError(404, 'Program not found');
  await query('DELETE FROM program_members WHERE program_id=$1', [req.params.pid]);
  for (const m of members) await query('INSERT INTO program_members (program_id,user_id,role) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING', [req.params.pid, m.user_id, m.role]);
  await logAudit({ query }, req.user, req.params.pid, { category: 'access', entity: 'Access', entity_name: p.name, summary: `Program access updated: ${members.length} member(s)` });
  res.json({ ok: true });
});

adminRouter.get('/settings', async (_req, res) => {
  const [s] = await query("SELECT value FROM settings WHERE key='portfolio'");
  res.json(s?.value || { base_currency: 'USD', fx: {} });
});
adminRouter.put('/settings', async (req, res) => {
  const v = portfolioSettingsSchema.parse(req.body);
  await query("INSERT INTO settings (key,value) VALUES ('portfolio',$1::jsonb) ON CONFLICT (key) DO UPDATE SET value=EXCLUDED.value", [JSON.stringify(v)]);
  await logAudit({ query }, req.user, null, { category: 'access', entity: 'Settings', entity_name: 'Portfolio FX', summary: `Portfolio currency settings updated (base ${v.base_currency})` });
  res.json(v);
});
