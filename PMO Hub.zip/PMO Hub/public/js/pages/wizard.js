import { h, buildFields, errorBox, money, num, toast, proposedTag } from '../dom.js';
import { post, get, upload } from '../api.js';

const TYPES = [['technology', 'Technology / software delivery'], ['transformation', 'Business or organisational change'], ['infrastructure', 'Infrastructure, construction or facilities'], ['product', 'Product development or launch'], ['other', 'General / other']];
const today = () => new Date().toISOString().slice(0, 10);
const plus = (n) => new Date(Date.now() + n * 864e5).toISOString().slice(0, 10);
const blank = () => ({
  name: '', program_type: 'technology', objectives: '', outcomes: '', scope: '', exclusions: '', sponsor: '', manager: '', start_date: plus(14), end_date: plus(14 + 270),
  delivery_approach: 'hybrid', phasesText: '', workstreams: [{ name: '', lead: '' }], constraints: '', geography: '', currency: 'USD', budget_guidance: null,
  team_roles: [], dependencies: [],
});
let a = blank();
let step = 0;
let proposal = null;
let edits = {};
let docs = []; // {name, text, chars, truncated}
let docResult = null;
let aiEnabled = null;
const FIELD_LABELS = { name: 'Name', program_type: 'Program type', objectives: 'Objectives', outcomes: 'Outcomes', scope: 'Scope', exclusions: 'Exclusions', sponsor: 'Sponsor', manager: 'Manager', start_date: 'Start date', end_date: 'End date', delivery_approach: 'Delivery approach', phases: 'Phases', workstreams: 'Workstreams', constraints: 'Constraints', geography: 'Geography', currency: 'Currency', budget_guidance: 'Budget guidance', team_roles: 'Team roles', dependencies: 'Dependencies' };
const STEPS = ['Basics', 'Objectives & scope', 'Structure', 'Team & dependencies', 'Review proposal'];

function listEditor(items, cols, newItem, addLabel) {
  const host = h('div', { class: 'list-edit' });
  const draw = () => {
    host.replaceChildren(...items.map((it, i) => h('div', { class: 'item', style: { '--cols': cols.length } },
      cols.map((c) => h('label', { class: 'field' }, c.label, h('input', { type: c.type || 'text', value: it[c.key] ?? '', placeholder: c.placeholder || null, min: c.min ?? null, 'aria-label': `${c.label} ${i + 1}`,
        onInput: (e) => { it[c.key] = c.type === 'number' ? (e.target.value === '' ? null : Number(e.target.value)) : e.target.value; } }))),
      h('button', { class: 'btn btn-sm btn-danger', type: 'button', 'aria-label': `Remove item ${i + 1}`, onClick: () => { items.splice(i, 1); draw(); } }, 'Remove'))),
    h('button', { class: 'btn btn-sm', type: 'button', onClick: () => { items.push(newItem()); draw(); } }, `+ ${addLabel}`));
  };
  draw();
  return host;
}

function payload() {
  const clean = (s) => String(s || '').trim();
  return {
    name: clean(a.name), program_type: a.program_type, objectives: clean(a.objectives), outcomes: clean(a.outcomes), scope: clean(a.scope), exclusions: clean(a.exclusions),
    sponsor: clean(a.sponsor), manager: clean(a.manager), start_date: a.start_date, end_date: a.end_date, delivery_approach: a.delivery_approach,
    phases: clean(a.phasesText).split(/\r?\n/).map(clean).filter(Boolean),
    workstreams: a.workstreams.filter((w) => clean(w.name)).map((w) => ({ name: clean(w.name), lead: clean(w.lead) })),
    constraints: clean(a.constraints), geography: clean(a.geography), currency: clean(a.currency).toUpperCase(), budget_guidance: a.budget_guidance || null,
    team_roles: a.team_roles.filter((r) => clean(r.role)).map((r) => ({ role: clean(r.role), count: r.count || 1, name: clean(r.name) || undefined, rate: r.rate ?? null })),
    dependencies: a.dependencies.filter((d) => clean(d.name)).map((d) => ({ name: clean(d.name), owner: clean(d.owner), needed_by: d.needed_by || null })),
  };
}

export async function render({ navigate }) {
  if (aiEnabled === null) { try { aiEnabled = (await get('/documents/status')).ai_enabled; } catch { aiEnabled = false; } }
  const host = h('div');
  const errHost = h('div');

  const field = (name, label, o = {}) => ({ name, label, value: a[name], ...o });
  const bind = (fields) => { const b = buildFields(fields); return { ...b, save: () => Object.assign(a, b.read()) }; };


  function uploader(save) {
    const msg = h('div');
    const fileInput = h('input', { type: 'file', multiple: true, accept: '.docx,.pdf,.txt,.md,.markdown,.csv,.rtf', 'aria-label': 'Choose project documents', onChange: async (e) => {
      msg.replaceChildren();
      for (const f of [...e.target.files]) {
        if (f.size > 10 * 1024 * 1024) { msg.append(errorBox({ message: `${f.name} is larger than 10 MB` })); continue; }
        try { docs.push(await upload('/documents/extract', f)); } catch (ex) { msg.append(errorBox({ message: `${f.name}: ${ex.message}` })); }
      }
      e.target.value = ''; draw();
    } });
    const paste = h('textarea', { rows: 5, placeholder: 'Paste text from an email, brief or charter…', 'aria-label': 'Paste document text' });
    const go = h('button', { class: 'btn btn-primary', type: 'button', disabled: !docs.length, onClick: async (e) => {
      e.target.disabled = true; e.target.textContent = 'Analysing…'; msg.replaceChildren();
      try {
        save();
        const res = await post('/documents/analyze', { documents: docs.map((d) => ({ name: d.name, text: d.text })) });
        for (const [k, v] of Object.entries(res.answers)) { if (k === 'phases') a.phasesText = v.join('\n'); else a[k] = v; }
        docResult = res; draw();
      } catch (ex) { msg.replaceChildren(errorBox(ex)); e.target.disabled = false; e.target.textContent = 'Analyse and fill the form'; }
    } }, 'Analyse and fill the form');
    return h('div', { class: 'card', style: { marginBottom: '16px' } },
      h('h3', 'Start from a document (optional)'),
      h('p', { class: 'muted small' }, 'Upload a statement of work, business case, project charter or any initial project document (.docx, .pdf, .txt, .md, up to 10 MB each) — or paste text. The form below is pre-filled from it; you review and edit everything before anything is created. Files are read in memory and not stored.'),
      aiEnabled ? h('div', { class: 'notice info small' }, 'AI analysis is enabled: the document text is sent to the Anthropic API to extract the details.') : h('div', { class: 'notice info small' }, 'Keyword analysis: details are found from headings and labels such as "Objectives", "Scope", "Sponsor:" and "Budget:". An administrator can enable deeper AI analysis (ANTHROPIC_API_KEY).'),
      h('div', { class: 'row', style: { marginTop: '10px' } }, fileInput),
      h('details', { style: { marginTop: '8px' } }, h('summary', 'Or paste text instead'), paste,
        h('button', { class: 'btn btn-sm', type: 'button', style: { marginTop: '6px' }, onClick: () => { const v = paste.value.trim(); if (v.length < 20) { msg.replaceChildren(errorBox({ message: 'Paste at least a couple of sentences' })); return; } docs.push({ name: 'Pasted text', text: v, chars: v.length }); paste.value = ''; msg.replaceChildren(); draw(); } }, 'Add pasted text')),
      msg,
      docs.length ? h('ul', { class: 'plain' }, docs.map((d, i) => h('li', h('div', { class: 'row spread' }, h('span', h('strong', d.name), h('span', { class: 'muted small' }, ` · ${d.chars.toLocaleString()} characters${d.truncated ? ' (truncated)' : ''}`)),
        h('button', { class: 'btn btn-sm btn-danger', type: 'button', onClick: () => { docs.splice(i, 1); draw(); } }, 'Remove'))))) : null,
      h('div', { style: { marginTop: '10px' } }, go),
      docResult ? h('div', { class: 'notice', style: { marginTop: '12px' } },
        h('strong', docResult.source === 'claude' ? 'Analysed with Claude. ' : 'Keyword analysis complete. '), `Filled ${docResult.found.length} field(s): ${docResult.found.map((k) => FIELD_LABELS[k] || k).join(', ')}. `,
        h('strong', 'Please verify everything below'), ' — extracted details can be incomplete or wrong, and nothing is confirmed until you create and baseline the program.',
        docResult.notes.length ? h('ul', docResult.notes.map((n) => h('li', n))) : null,
        (() => { const missing = ['name', 'sponsor', 'manager', 'start_date', 'end_date', 'objectives', 'outcomes', 'scope'].filter((k) => !docResult.found.includes(k)); return missing.length ? h('div', { class: 'small' }, `Not found in the document (fill in manually): ${missing.map((k) => FIELD_LABELS[k]).join(', ')}.`) : null; })()) : null);
  }

  async function next(from) {
    errHost.replaceChildren();
    if (from === 3) {
      try {
        const out = await post('/proposals', payload());
        proposal = out.proposal; edits = { charter: { ...proposal.charter }, approved_budget: proposal.approved_budget };
      } catch (e) { errHost.replaceChildren(errorBox(e)); return; }
    }
    step = from + 1; draw();
  }

  function stepBody() {
    if (step === 0) {
      const b = bind([
        field('name', 'Program name', { required: true, span2: true }),
        field('program_type', 'Program type', { type: 'select', options: TYPES, hint: 'Shapes the phases, activities and cost categories that are proposed.', span2: true }),
        field('sponsor', 'Sponsor', { required: true }), field('manager', 'Program manager', { required: true }),
        field('start_date', 'Start date', { type: 'date', required: true }), field('end_date', 'End date', { type: 'date', required: true }),
        field('delivery_approach', 'Delivery approach', { type: 'select', options: [['waterfall', 'Waterfall (sequential phases)'], ['agile', 'Agile (iterative releases)'], ['hybrid', 'Hybrid']] }),
        field('currency', 'Currency', { required: true, hint: '3-letter code, e.g. USD, EUR, GBP' }),
        field('geography', 'Geography', { span2: true, hint: 'Countries or regions covered, e.g. "UK, Germany, France"' }),
      ]);
      return { el: h('div', uploader(() => b.save()), b.grid), save: b.save, valid: () => a.name.trim() && a.sponsor.trim() && a.manager.trim() };
    }
    if (step === 1) {
      const b = bind([
        field('objectives', 'Objectives', { type: 'textarea', rows: 4, required: true, span2: true, hint: 'One per line' }),
        field('outcomes', 'Expected outcomes', { type: 'textarea', rows: 4, required: true, span2: true, hint: 'One per line — each becomes a success measure' }),
        field('scope', 'In scope', { type: 'textarea', rows: 4, required: true, span2: true, hint: 'One per line' }),
        field('exclusions', 'Out of scope (exclusions)', { type: 'textarea', rows: 3, span2: true }),
        field('constraints', 'Constraints', { type: 'textarea', rows: 3, span2: true, hint: 'One per line — each becomes a tracked risk' }),
      ]);
      return { el: b.grid, save: b.save, valid: () => a.objectives.trim() && a.outcomes.trim() && a.scope.trim() };
    }
    if (step === 2) {
      const b = bind([
        field('phasesText', 'Custom phases (optional)', { type: 'textarea', rows: 4, span2: true, hint: 'One phase name per line, in order. Leave blank to use the standard phases for the program type and delivery approach.' }),
        field('budget_guidance', 'Budget guidance (optional)', { type: 'number', min: 0, hint: `In program currency. Leave blank to propose a budget from the estimated plan cost.` }),
      ]);
      return {
        el: h('div', h('h3', 'Workstreams'), h('p', { class: 'muted small' }, 'Each workstream gets its own tasks in every delivery phase.'),
          listEditor(a.workstreams, [{ key: 'name', label: 'Workstream', placeholder: 'e.g. Data Migration' }, { key: 'lead', label: 'Lead (optional)', placeholder: 'Name' }], () => ({ name: '', lead: '' }), 'Add workstream'),
          h('div', { style: { marginTop: '16px' } }, b.grid)),
        save: b.save, valid: () => a.workstreams.some((w) => w.name.trim()),
      };
    }
    if (step === 3) {
      return {
        el: h('div',
          h('h3', 'Team roles'), h('p', { class: 'muted small' }, 'Optional. Leave empty for a typical team for this program type. Rates are hourly; blank rates get a benchmark estimate clearly marked as assumed. A name is only used when the count is 1; otherwise placeholders ("TBC") are created.'),
          listEditor(a.team_roles, [{ key: 'role', label: 'Role' }, { key: 'count', label: 'Count', type: 'number', min: 1 }, { key: 'name', label: 'Name (if known)' }, { key: 'rate', label: 'Hourly rate', type: 'number', min: 0 }], () => ({ role: '', count: 1, name: '', rate: null }), 'Add role'),
          h('h3', { style: { marginTop: '20px' } }, 'Known dependencies'), h('p', { class: 'muted small' }, 'External things you rely on. Each becomes a dependency plus a delay risk in the RAID log.'),
          listEditor(a.dependencies, [{ key: 'name', label: 'Dependency' }, { key: 'owner', label: 'Owner' }, { key: 'needed_by', label: 'Needed by', type: 'date' }], () => ({ name: '', owner: '', needed_by: '' }), 'Add dependency')),
        save: () => {}, valid: () => true,
      };
    }
    return { el: review(), save: () => {}, valid: () => true };
  }

  function review() {
    const st = proposal.stats;
    const cur = a.currency.toUpperCase();
    const charterFields = [['summary', 'Executive summary', 5], ['success_measures', 'Success measures', 5], ['governance', 'Governance', 5], ['objectives', 'Objectives', 3], ['outcomes', 'Outcomes', 3], ['scope', 'Scope', 3], ['exclusions', 'Exclusions', 2], ['constraints', 'Constraints', 2]];
    const generated = ['summary', 'success_measures', 'governance'];
    return h('div',
      h('div', { class: 'notice' }, h('strong', 'This is a proposal, not a plan of record. '), 'Everything generated below is a draft based on your answers and standard templates. Items are labelled Proposed or Assumed until you edit or approve them. You can change every item after the program is created, and nothing is baselined until you approve it.'),
      proposal.warnings.map((w) => h('div', { class: 'errors' }, '⚠ ', w)),
      h('div', { class: 'grid g4', style: { margin: '16px 0' } },
        [['Phases', st.phases], ['Tasks & subtasks', st.tasks], ['Milestones', st.milestones], ['Resources', `${st.resources} (${st.placeholders} TBC)`], ['Estimated effort', `${num(st.hours)} h`], ['Estimated labour', money(st.labourCost, cur, true)],
          ['Estimated plan cost', money(st.planCost, cur, true)], ['RAID items proposed', st.raid]].map(([l, v]) => h('div', { class: 'kpi' }, h('div', { class: 'label' }, l), h('div', { class: 'value' }, v)))),
      h('h3', 'Assumptions made'), h('ul', proposal.assumption_notes.map((x) => h('li', x))),
      h('h3', { style: { marginTop: '16px' } }, 'Budget'),
      h('label', { class: 'field', style: { maxWidth: '320px' } }, `Approved budget (${cur})`, h('input', { type: 'number', min: 0, value: edits.approved_budget ?? '', onInput: (e) => { edits.approved_budget = e.target.value === '' ? null : Number(e.target.value); } }),
        h('span', { class: 'hint' }, `Plan cost incl. ${proposal.assumptions.contingency_pct}% contingency: ${money(st.withContingency, cur)}`)),
      h('h3', { style: { marginTop: '16px' } }, 'Charter draft — edit before creating'),
      charterFields.map(([k, label, rows]) => h('label', { class: 'field', style: { marginTop: '10px' } }, h('span', label, ' ', proposedTag(generated.includes(k))),
        h('textarea', { rows, onInput: (e) => { edits.charter[k] = e.target.value; } }, edits.charter[k] || ''))));
  }

  function draw() {
    const body = stepBody();
    const isLast = step === STEPS.length - 1;
    const nextBtn = h('button', { class: 'btn btn-primary', type: 'button', onClick: async (e) => {
      body.save();
      if (!isLast) {
        if (!body.valid()) { errHost.replaceChildren(errorBox({ message: 'Please complete the required fields (marked *) before continuing.' })); return; }
        e.target.disabled = true; await next(step); return;
      }
      e.target.disabled = true; errHost.replaceChildren();
      try {
        const out = await post('/programs', { answers: payload(), edits: { charter: edits.charter, approved_budget: edits.approved_budget } });
        a = blank(); step = 0; proposal = null; docs = []; docResult = null; toast('Program created as a draft proposal');
        navigate(`#/p/${out.id}/overview`);
      } catch (ex) { errHost.replaceChildren(errorBox(ex)); e.target.disabled = false; }
    } }, isLast ? 'Create draft program' : step === 3 ? 'Generate proposal' : 'Next');
    host.replaceChildren(
      h('div', { class: 'steps', role: 'list' }, STEPS.map((s, i) => h('span', { role: 'listitem', class: i === step ? 'on' : i < step ? 'done' : '', 'aria-current': i === step ? 'step' : null }, `${i + 1}. ${s}`))),
      h('div', { class: 'card' }, h('h2', STEPS[step]), body.el, errHost,
        h('div', { class: 'row spread', style: { marginTop: '16px' } },
          h('button', { class: 'btn', type: 'button', disabled: step === 0, onClick: () => { body.save(); step = Math.max(0, step - 1); errHost.replaceChildren(); draw(); } }, 'Back'), nextBtn)));
  }
  draw();
  return h('div', h('div', { class: 'page-head' }, h('div', h('h1', 'New program'), h('p', { class: 'muted' }, 'Answer a few questions. A draft charter, plan, resources, budget and RAID log are proposed for you to review and edit.')),
    h('a', { class: 'btn', href: '#/programs' }, 'Cancel')), host);
}
