import { h, date, money, formModal, proposedTag, healthBadge, STATUS_LABEL } from '../dom.js';
import { patch } from '../api.js';

const SECTIONS = [
  ['summary', 'Executive summary'], ['objectives', 'Objectives'], ['outcomes', 'Expected outcomes'], ['success_measures', 'Success measures'],
  ['scope', 'Scope'], ['exclusions', 'Exclusions (out of scope)'], ['governance', 'Governance'], ['constraints', 'Constraints'],
];

export async function render(ctx) {
  const d = ctx.data;
  const p = d.program;
  const canEdit = d.caps.charter;
  const generated = p.proposal_state?.sections || {};

  const section = ([key, label]) => h('div', { class: 'card' },
    h('div', { class: 'card-head' }, h('h2', label), proposedTag(generated[key]),
      canEdit ? h('div', { class: 'row' },
        generated[key] ? h('button', { class: 'btn btn-sm', type: 'button', title: 'Mark as reviewed without changes', onClick: () => ctx.act(() => patch(`/programs/${ctx.id}`, { confirm_sections: [key] }), 'Confirmed') }, 'Confirm') : null,
        h('button', { class: 'btn btn-sm', type: 'button', onClick: () => editSection(ctx, key, label) }, 'Edit')) : null),
    p[key]?.trim() ? h('pre', { class: 'text' }, p[key]) : h('p', { class: 'muted' }, 'Not yet written.'));

  const facts = [
    ['Sponsor', p.sponsor], ['Program manager', p.manager], ['Delivery approach', p.delivery_approach], ['Geography', p.geography || '—'],
    ['Dates', `${date(p.start_date)} → ${date(p.end_date)}`], ['Currency', p.currency], ['Approved budget', p.approved_budget ? money(p.approved_budget, p.currency) : 'Not set'],
    ['Status', STATUS_LABEL[p.status]],
  ];
  const owners = d.workstreams.map((w) => h('li', h('strong', w.name), ' — ', w.lead || h('span', { class: 'muted' }, 'no lead named'), ' ', proposedTag(w.is_proposed)));

  const side = h('div',
    h('div', { class: 'card' }, h('div', { class: 'card-head' }, h('h2', 'Key facts'), canEdit ? h('button', { class: 'btn btn-sm', type: 'button', onClick: () => factsDialog(ctx) }, 'Edit') : null),
      h('dl', { style: { margin: 0 } }, facts.flatMap(([k, v]) => [h('dt', { class: 'muted small', style: { marginTop: '8px' } }, k), h('dd', { style: { margin: 0 } }, v)])),
      h('div', { style: { marginTop: '10px' } }, healthBadge(d.health.overall))),
    h('div', { class: 'card' }, h('div', { class: 'card-head' }, h('h2', 'Workstreams & owners'), d.caps.plan ? h('button', { class: 'btn btn-sm', type: 'button', onClick: () => wsDialog(ctx) }, '+ Add') : null),
      d.workstreams.length ? h('ul', { class: 'plain' }, d.workstreams.map((w) => h('li', h('div', { class: 'row spread' }, h('span', h('strong', w.name), ' — ', w.lead || h('span', { class: 'muted' }, 'no lead named'), ' ', proposedTag(w.is_proposed)),
        d.caps.plan ? h('button', { class: 'btn btn-sm', type: 'button', onClick: () => wsDialog(ctx, w) }, 'Edit') : null)))) : h('p', { class: 'muted' }, 'No workstreams.')),
    h('div', { class: 'card' }, h('h2', 'Proposal assumptions'), p.proposal_state?.assumptions?.length
      ? h('ul', { class: 'small' }, p.proposal_state.assumptions.map((a) => h('li', a)))
      : h('p', { class: 'muted small' }, 'No unreviewed assumptions. They are cleared when a baseline is approved.')));

  return h('div', { class: 'grid g-main' }, h('div', SECTIONS.map(section)), side);
}

function editSection(ctx, key, label) {
  formModal({
    title: `Edit ${label.toLowerCase()}`, fields: [{ name: key, label, type: 'textarea', rows: 10, value: ctx.data.program[key], span2: true }],
    onSubmit: async (v) => { ctx.apply(await patch(`/programs/${ctx.id}`, v)); },
  });
}

function factsDialog(ctx) {
  const p = ctx.data.program;
  formModal({
    title: 'Edit program details',
    fields: [
      { name: 'name', label: 'Name', value: p.name, required: true, span2: true }, { name: 'sponsor', label: 'Sponsor', value: p.sponsor, required: true }, { name: 'manager', label: 'Program manager', value: p.manager, required: true },
      { name: 'start_date', label: 'Start date', type: 'date', value: p.start_date, required: true }, { name: 'end_date', label: 'End date', type: 'date', value: p.end_date, required: true },
      { name: 'delivery_approach', label: 'Delivery approach', type: 'select', value: p.delivery_approach, options: [['waterfall', 'Waterfall'], ['agile', 'Agile'], ['hybrid', 'Hybrid']] },
      { name: 'geography', label: 'Geography', value: p.geography }, { name: 'approved_budget', label: `Approved budget (${p.currency})`, type: 'number', value: p.approved_budget, min: 0 },
      { name: 'status', label: 'Status', type: 'select', value: p.status === 'draft' ? 'active' : p.status, options: [['active', 'Active'], ['on_hold', 'On hold'], ['complete', 'Complete']], hint: p.status === 'draft' ? 'Draft becomes Active when a baseline is approved.' : null, disabled: p.status === 'draft' },
    ],
    onSubmit: async (v) => { const body = { ...v }; if (p.status === 'draft') delete body.status; ctx.apply(await patch(`/programs/${ctx.id}`, body)); },
  });
}

async function wsDialog(ctx, ws) {
  const { post, patch: pt, del } = await import('../api.js');
  formModal({
    title: ws ? 'Edit workstream' : 'Add workstream',
    fields: [{ name: 'name', label: 'Name', value: ws?.name, required: true, span2: true }, { name: 'lead', label: 'Lead', value: ws?.lead }, { name: 'description', label: 'Description', value: ws?.description, type: 'textarea', span2: true }],
    danger: ws ? { label: 'Delete', onClick: async () => { ctx.apply(await del(`/programs/${ctx.id}/workstreams/${ws.id}`)); } } : null,
    onSubmit: async (v) => { ctx.apply(ws ? await pt(`/programs/${ctx.id}/workstreams/${ws.id}`, v) : await post(`/programs/${ctx.id}/workstreams`, v)); },
  });
}
