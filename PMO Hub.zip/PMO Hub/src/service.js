import crypto from 'node:crypto';
import { query } from './db.js';
import { HttpError } from './auth.js';
import { computeProgram, makeSnapshot, todayStr } from './calc.js';
import { generateProposal } from './proposal.js';

const uid = () => crypto.randomUUID();
const base = { query };
const PROGRAM_JSON = ['assumptions', 'support_requests', 'proposal_state'];

/** Load full raw models (program + children) for one or more programs. */
export async function loadModels(ids, q = base) {
  const out = new Map();
  if (!ids.length) return out;
  const ph = ids.map((_, i) => `$${i + 1}`).join(',');
  const by = async (table, order = '') => (await q.query(`SELECT * FROM ${table} WHERE program_id IN (${ph}) ${order}`, ids));
  const programs = await q.query(`SELECT * FROM programs WHERE id IN (${ph})`, ids);
  const workstreams = await by('workstreams', 'ORDER BY sort, name');
  const resources = await by('resources', 'ORDER BY sort, name');
  const tasks = await by('tasks');
  const budget = await by('budget_lines', 'ORDER BY category');
  const raid = await by('raid_items', 'ORDER BY created_at');
  const baselines = await q.query(`SELECT DISTINCT ON (program_id) * FROM baselines WHERE program_id IN (${ph}) ORDER BY program_id, version DESC`, ids);
  const deps = await q.query(`SELECT d.task_id, d.predecessor_id FROM task_deps d JOIN tasks t ON t.id = d.task_id WHERE t.program_id IN (${ph})`, ids);
  const links = await q.query(`SELECT l.raid_id, l.task_id FROM raid_links l JOIN raid_items r ON r.id = l.raid_id WHERE r.program_id IN (${ph})`, ids);

  const predMap = new Map();
  for (const d of deps) (predMap.get(d.task_id) || predMap.set(d.task_id, []).get(d.task_id)).push(d.predecessor_id);
  const linkMap = new Map();
  for (const l of links) (linkMap.get(l.raid_id) || linkMap.set(l.raid_id, []).get(l.raid_id)).push(l.task_id);

  for (const p of programs) {
    out.set(p.id, { program: p, workstreams: [], resources: [], tasks: [], budget_lines: [], raid: [], baseline: null });
  }
  for (const w of workstreams) out.get(w.program_id).workstreams.push(w);
  for (const r of resources) out.get(r.program_id).resources.push(r);
  for (const t of tasks) out.get(t.program_id).tasks.push({ ...t, predecessors: predMap.get(t.id) || [] });
  for (const b of budget) out.get(b.program_id).budget_lines.push(b);
  for (const r of raid) out.get(r.program_id).raid.push({ ...r, task_ids: linkMap.get(r.id) || [] });
  for (const b of baselines) out.get(b.program_id).baseline = b;
  return out;
}

export async function loadModel(id, q = base) {
  const m = (await loadModels([id], q)).get(id);
  if (!m) throw new HttpError(404, 'Program not found');
  return m;
}

// ------------------------------------------------------------------ audit
export async function logAudit(q, user, programId, e) {
  await q.query(
    `INSERT INTO audit_log (program_id,user_id,user_name,category,entity,entity_id,entity_name,field,old_value,new_value,summary)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
    [programId, user?.id || null, user?.name || 'system', e.category || 'material', e.entity, e.entity_id || '', e.entity_name || '', e.field || '', e.old ?? '', e.new ?? '', e.summary || ''],
  );
}

const show = (v) => (v === null || v === undefined ? '' : typeof v === 'object' ? JSON.stringify(v) : String(v));

/** Log one audit row per changed field. `cats` maps field -> category (default 'material'). */
export async function auditDiff(q, user, programId, { entity, id, name, before, after, cats = {}, skip = [] }) {
  for (const f of Object.keys(after)) {
    if (skip.includes(f)) continue;
    if (show(before[f]) === show(after[f])) continue;
    await logAudit(q, user, programId, {
      category: cats[f] || 'material', entity, entity_id: id, entity_name: name, field: f, old: show(before[f]), new: show(after[f]),
      summary: `${entity} "${name}": ${f.replace(/_/g, ' ')} changed`,
    });
  }
}

// ------------------------------------------------------------------ program creation
export async function createProgram(q, user, answers, edits = {}) {
  const prop = generateProposal(answers);
  const id = uid();
  const [{ n }] = await q.query('SELECT count(*) AS n FROM programs');
  const code = edits.code || `PRG-${String(Number(n) + 1).padStart(3, '0')}`;
  const charter = { ...prop.charter };
  const state = JSON.parse(JSON.stringify(prop.proposal_state));
  for (const [k, v] of Object.entries(edits.charter || {})) {
    if (v !== charter[k]) { charter[k] = v; delete state.sections[k]; }
  }
  const budget = edits.approved_budget !== undefined && edits.approved_budget !== null ? edits.approved_budget : prop.approved_budget;
  await q.query(
    `INSERT INTO programs (id,code,name,status,sponsor,manager,delivery_approach,start_date,end_date,currency,geography,approved_budget,
       summary,objectives,outcomes,success_measures,scope,exclusions,governance,constraints,assumptions,proposal_state,created_by)
     VALUES ($1,$2,$3,'draft',$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20::jsonb,$21::jsonb,$22)`,
    [id, code, answers.name, answers.sponsor, answers.manager, answers.delivery_approach, answers.start_date, answers.end_date, answers.currency,
      answers.geography || '', budget, charter.summary, charter.objectives, charter.outcomes, charter.success_measures, charter.scope,
      charter.exclusions, charter.governance, charter.constraints, JSON.stringify(prop.assumptions), JSON.stringify({ ...state, program_type: prop.program_type }), user.id],
  );
  await q.query('INSERT INTO program_members (program_id,user_id,role) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING', [id, user.id, 'manager']);

  const wsIds = {}, resIds = {}, taskIds = {};
  let i = 0;
  for (const w of prop.workstreams) {
    wsIds[w.key] = uid();
    await q.query('INSERT INTO workstreams (id,program_id,name,lead,description,sort,is_proposed) VALUES ($1,$2,$3,$4,$5,$6,true)', [wsIds[w.key], id, w.name, w.lead, w.description, i++]);
  }
  i = 0;
  for (const r of prop.resources) {
    resIds[r.key] = uid();
    await q.query(
      `INSERT INTO resources (id,program_id,name,role,rate,rate_currency,rate_assumed,capacity_hrs_week,allocation_pct,chargeable,is_placeholder,is_proposed,sort)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,true,$12)`,
      [resIds[r.key], id, r.name, r.role, r.rate, r.rate_currency, !!r.rate_assumed, r.capacity_hrs_week, r.allocation_pct, r.chargeable, r.is_placeholder, i++]);
  }
  for (const t of prop.tasks) {
    taskIds[t.key] = uid();
    await q.query(
      `INSERT INTO tasks (id,program_id,parent_id,workstream_id,resource_id,type,name,start_date,end_date,estimate_hrs,sort,notes,is_proposed)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,true)`,
      [taskIds[t.key], id, t.parent_key ? taskIds[t.parent_key] : null, t.ws_key ? wsIds[t.ws_key] : null, t.resource_key ? resIds[t.resource_key] : null,
        t.type, t.name, t.start_date, t.end_date, t.estimate_hrs, t.sort, t.notes]);
  }
  for (const t of prop.tasks) {
    for (const p of t.pred_keys) await q.query('INSERT INTO task_deps (task_id,predecessor_id) VALUES ($1,$2) ON CONFLICT DO NOTHING', [taskIds[t.key], taskIds[p]]);
  }
  for (const l of prop.budget_lines) {
    await q.query('INSERT INTO budget_lines (id,program_id,category,description,planned_amount,actual_amount,is_assumption,is_proposed) VALUES ($1,$2,$3,$4,$5,0,$6,true)', [uid(), id, l.category, l.description, l.planned_amount, l.is_assumption]);
  }
  for (const r of prop.raid) {
    const rid = uid();
    await q.query(
      `INSERT INTO raid_items (id,program_id,type,title,description,owner,status,impact,likelihood,response,due_date,is_proposed)
       VALUES ($1,$2,$3,$4,$5,$6,'open',$7,$8,$9,$10,true)`,
      [rid, id, r.type, r.title, r.description, r.owner, r.impact || null, r.likelihood || null, r.response, r.due_date || null]);
    for (const k of r.task_keys || []) if (taskIds[k]) await q.query('INSERT INTO raid_links (raid_id,task_id) VALUES ($1,$2) ON CONFLICT DO NOTHING', [rid, taskIds[k]]);
  }
  await logAudit(q, user, id, { category: 'material', entity: 'Program', entity_id: id, entity_name: answers.name, summary: `Program created with a generated proposal (${prop.stats.tasks} tasks, ${prop.stats.raid} RAID items). All content is unconfirmed until reviewed.` });
  return { id, proposal: prop };
}

// ------------------------------------------------------------------ baseline
export async function proposedCount(q, programId) {
  let n = 0;
  for (const t of ['workstreams', 'resources', 'tasks', 'budget_lines', 'raid_items']) {
    const [r] = await q.query(`SELECT count(*) AS n FROM ${t} WHERE program_id=$1 AND is_proposed`, [programId]);
    n += Number(r.n);
  }
  const [p] = await q.query('SELECT proposal_state FROM programs WHERE id=$1', [programId]);
  n += Object.keys(p.proposal_state?.sections || {}).length;
  return n;
}

export async function approveBaseline(q, user, programId, { note, confirm }) {
  const model = await loadModel(programId, q);
  const c = computeProgram(model, todayStr());
  const errors = c.plan.issues.filter((i) => i.level === 'error');
  if (errors.length) throw new HttpError(422, 'Fix plan errors before approving a baseline', { errors: errors.map((e) => e.message) });
  if (!model.tasks.length) throw new HttpError(422, 'The plan has no tasks');
  const pending = await proposedCount(q, programId);
  if (pending > 0 && !confirm) throw new HttpError(409, 'Unreviewed proposed content exists', { pending });
  const prev = model.baseline;
  if (prev && note.trim().length < 5) throw new HttpError(422, 'Re-baselining needs a reason (at least 5 characters)', { errors: ['Add a note explaining why the baseline is being replaced'] });
  const version = (prev?.version || 0) + 1;
  const bid = uid();
  const snapshot = makeSnapshot(model, c.plan, c.budget);
  await q.query('INSERT INTO baselines (id,program_id,version,approved_by,note,snapshot) VALUES ($1,$2,$3,$4,$5,$6::jsonb)', [bid, programId, version, user.name, note, JSON.stringify(snapshot)]);
  await q.query(`UPDATE programs SET baseline_id=$2, status=CASE WHEN status='draft' THEN 'active' ELSE status END, proposal_state='{}'::jsonb, updated_at=now() WHERE id=$1`, [programId, bid]);
  for (const t of ['workstreams', 'resources', 'tasks', 'budget_lines', 'raid_items']) await q.query(`UPDATE ${t} SET is_proposed=false WHERE program_id=$1`, [programId]);
  await logAudit(q, user, programId, {
    category: 'baseline', entity: 'Baseline', entity_id: bid, entity_name: `v${version}`, field: 'baseline',
    old: prev ? `v${prev.version}` : '', new: `v${version}`,
    summary: `Baseline v${version} approved by ${user.name}: end ${snapshot.end_date}, budget ${snapshot.approved_budget}, ${snapshot.tasks.length} plan items${pending ? `, ${pending} proposed items accepted` : ''}${note ? `. Note: ${note}` : ''}`,
  });
  return { version, id: bid };
}

export { PROGRAM_JSON };
