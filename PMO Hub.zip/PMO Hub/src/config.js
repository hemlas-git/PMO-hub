import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

// Minimal .env loader (real environment variables always win).
(function loadDotEnv() {
  const file = path.join(root, '.env');
  if (!fs.existsSync(file)) return;
  for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    if (line.trim().startsWith('#')) continue;
    const m = line.match(/^\s*([A-Za-z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (!m) continue;
    let v = m[2];
    if (/^(['"]).*\1$/.test(v)) v = v.slice(1, -1);
    if (process.env[m[1]] === undefined) process.env[m[1]] = v;
  }
})();

const env = process.env;
const isProd = env.NODE_ENV === 'production';

export const config = {
  root,
  isProd,
  port: Number(env.PORT) || 3100,
  databaseUrl: env.DATABASE_URL || '',
  pgSsl: env.PGSSL === 'true',
  dataDir: env.DATA_DIR || path.join(root, 'data', 'pglite'),
  sessionHours: Number(env.SESSION_HOURS) || 12,
  secureCookies: env.SECURE_COOKIES ? env.SECURE_COOKIES === 'true' : isProd,
  trustProxy: env.TRUST_PROXY === 'true',
  seedDemo: env.SEED_DEMO ? env.SEED_DEMO === 'true' : !isProd,
  demoPassword: env.DEMO_PASSWORD || 'Demo-Pass-2026!',
  requireLogin: env.REQUIRE_LOGIN === 'true',
  // Public demo mode (Vercel): in-memory database seeded with sample data, read-only unless DEMO_READONLY=false.
  demoMode: env.DEMO_MODE === 'true',
  demoReadonly: env.DEMO_MODE === 'true' && env.DEMO_READONLY !== 'false',
  anthropic: { key: env.ANTHROPIC_API_KEY || '', model: env.ANTHROPIC_MODEL || 'claude-sonnet-5-5' },
  bootstrap: {
    email: env.BOOTSTRAP_ADMIN_EMAIL || '',
    name: env.BOOTSTRAP_ADMIN_NAME || 'Administrator',
    password: env.BOOTSTRAP_ADMIN_PASSWORD || '',
  },
};

if (isProd && !config.databaseUrl && env.DEMO_MODE !== 'true') {
  throw new Error('DATABASE_URL must be set when NODE_ENV=production');
}
