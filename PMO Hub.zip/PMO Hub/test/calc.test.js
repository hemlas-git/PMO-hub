import test from 'node:test';
import assert from 'node:assert/strict';
import { computeProgram, validateTask, cascadeShifts, findCycle, workdays } from '../src/calc.js';
import { generateProposal } from '../src/proposal.js';

const answers = {
  name: 'Test', program_type: 'infrastructure', delivery_approach: 'waterfall', sponsor: 'S', manager: 'M', start_date: '2026-01-05', end_date: '2026-09-30',
  currency: 'USD', geography: 'UK, France', objectives: 'a', outcomes: 'b', scope: 'c', exclusions: 'd', constraints: 'e', phases: [],
  workstreams: [{ name: 'One', lead: 'L1' }, { name: 'Two', lead: '' }], team_roles: [], dependencies: [{ name: 'Vendor', description: '', owner: 'V', needed_by: '2026-02-01' }],
};

/** Turn a generated proposal into the raw model shape the calculator expects. */
function modelFrom(prop, overrides = {}) {
  const id = (k) => `id-${k}`;
  return {
    program: { id: 'p', start_date: answers.start_date, end_date: answers.end_date, currency: 'USD', status: 'active', approved_budget: prop.approved_budget, assumptions: prop.assumptions, support_requests: [] },
    workstreams: prop.workstreams.map((w) => ({ ...w, id: id(w.key) })),
    resources: prop.resources.map((r) => ({ ...r, id: id(r.key) })),
    tasks: prop.tasks.map((t) => ({ ...t, id: id(t.key), parent_id: t.parent_key ? id(t.parent_key) : null, workstream_id: t.ws_key ? id(t.ws_key) : null, resource_id: t.resource_key ? id(t.resource_key) : null,
      actual_hrs: 0, pct_complete: 0, status: 'not_started', predecessors: t.pred_keys.map(id) })),
    budget_lines: prop.budget_lines.map((l, i) => ({ ...l, id: `b${i}`, forecast_override: null })),
    raid: [], baseline: null, ...overrides,
  };
}

test('proposal adapts to program type and flags assumptions', () => {
  const infra = generateProposal(answers);
  const tech = generateProposal({ ...answers, program_type: 'technology' });
  assert.ok(infra.tasks.some((t) => t.name.includes('Procurement')));
  assert.ok(!tech.tasks.some((t) => t.name.includes('Procurement')));
  assert.ok(infra.budget_lines.some((l) => l.category.includes('Materials')));
  assert.ok(infra.assumption_notes.length >= 3);
  assert.ok(infra.resources.filter((r) => r.chargeable).every((r) => r.rate_assumed || r.rate != null));
  const custom = generateProposal({ ...answers, phases: ['Kick-off', 'Study', 'Pilot', 'Rollout', 'Wrap-up'] });
  assert.deepEqual(custom.tasks.filter((t) => t.type === 'phase' && t.key.startsWith('p') && t.key !== 'pmo').map((t) => t.name), ['Kick-off', 'Study', 'Pilot', 'Rollout', 'Wrap-up']);
});

test('generated plan is internally consistent: no cycles, no dependency conflicts, no over-allocation', () => {
  const prop = generateProposal(answers);
  const c = computeProgram(modelFrom(prop), '2026-03-02');
  assert.equal(c.plan.hasCycle, false);
  assert.deepEqual(c.plan.issues.filter((i) => i.level === 'error'), []);
  assert.deepEqual(c.plan.issues.filter((i) => i.message.includes('before predecessor')), []);
  assert.equal(c.resources.resources.filter((r) => r.over_allocated).length, 0);
  assert.ok(c.budget.plannedCost > 0 && c.budget.forecast > 0);
});

test('updating estimates and dates flows through to effort and cost', () => {
  const prop = generateProposal(answers);
  const m = modelFrom(prop);
  const before = computeProgram(m, '2026-03-02');
  const leaf = m.tasks.find((t) => t.type === 'subtask' && t.resource_id);
  leaf.estimate_hrs += 100;
  const after = computeProgram(m, '2026-03-02');
  const rate = m.resources.find((r) => r.id === leaf.resource_id).rate;
  assert.ok(Math.abs(after.budget.labour.planned - before.budget.labour.planned - 100 * rate) < 0.01);
  assert.ok(after.plan.nodes.find((n) => n.id === leaf.parent_id).estimate > before.plan.nodes.find((n) => n.id === leaf.parent_id).estimate);
});

test('actuals update forecast; missing rate and over-allocation are flagged', () => {
  const prop = generateProposal(answers);
  const m = modelFrom(prop);
  const leaf = m.tasks.find((t) => t.type === 'subtask' && t.resource_id);
  leaf.actual_hrs = leaf.estimate_hrs * 2; leaf.pct_complete = 50; leaf.status = 'in_progress';
  const c = computeProgram(m, '2026-03-02');
  assert.ok(c.resources.resources.find((r) => r.id === leaf.resource_id).actual_hrs >= leaf.actual_hrs);
  const person = m.resources.find((r) => r.id === leaf.resource_id);
  person.rate = null; person.allocation_pct = 10;
  const c2 = computeProgram(m, '2026-03-02');
  const row = c2.resources.resources.find((r) => r.id === person.id);
  assert.equal(row.missing_rate, true);
  assert.equal(row.over_allocated, true);
  assert.ok(c2.resources.flags.length >= 2);
});

test('circular dependencies and bad dates are rejected', () => {
  const tasks = [
    { id: 'a', type: 'task', name: 'A', start_date: '2026-01-05', end_date: '2026-01-09', predecessors: [] },
    { id: 'b', type: 'task', name: 'B', start_date: '2026-01-12', end_date: '2026-01-16', predecessors: ['a'] },
  ];
  assert.ok(findCycle(['a', 'b'], [['a', 'b'], ['b', 'a']]));
  const errs = validateTask(tasks, { ...tasks[0], predecessors: ['b'] }, 'a');
  assert.ok(errs.some((e) => e.includes('Circular')));
  assert.ok(validateTask(tasks, { type: 'task', name: 'X', start_date: '2026-02-10', end_date: '2026-02-01', predecessors: [] }).some((e) => e.includes('before start')));
  assert.deepEqual(validateTask(tasks, { type: 'task', name: 'C', start_date: '2026-02-01', end_date: '2026-02-05', predecessors: ['b'] }), []);
});

test('moving a task cascades finish-to-start successors', () => {
  const tasks = [
    { id: 'a', type: 'task', start_date: '2026-01-05', end_date: '2026-01-23', predecessors: [] },
    { id: 'b', type: 'task', start_date: '2026-01-12', end_date: '2026-01-16', predecessors: ['a'] },
    { id: 'c', type: 'milestone', start_date: '2026-01-16', end_date: '2026-01-16', predecessors: ['b'] },
  ];
  const shifts = cascadeShifts(tasks, ['a']);
  const b = shifts.find((s) => s.id === 'b');
  assert.equal(b.start_date, '2026-01-26');
  assert.equal(b.end_date, '2026-01-30');
  assert.equal(shifts.find((s) => s.id === 'c').start_date, '2026-01-30');
  assert.equal(workdays('2026-01-05', '2026-01-11').length, 5);
});

test('baseline variance and health respond to slippage and RAID', () => {
  const prop = generateProposal(answers);
  const m = modelFrom(prop);
  const c0 = computeProgram(m, '2026-02-02');
  m.baseline = { version: 1, approved_by: 'x', approved_at: 'now', note: '', snapshot: { start_date: '2026-01-05', end_date: c0.plan.forecastEnd, approved_budget: c0.budget.approved, planned_cost: c0.budget.plannedCost, planned_hours: 1, currency: 'USD',
    tasks: c0.plan.nodes.map((n) => ({ id: n.id, wbs: n.wbs, name: n.name, type: n.type, parent_id: n.parent_id, start: n.start, end: n.end, estimate: n.estimate, isSummary: n.isSummary })) } };
  const last = m.tasks.filter((t) => t.type === 'subtask').pop();
  last.end_date = '2026-12-31';
  m.raid = [{ id: 'r1', type: 'risk', title: 'Big', status: 'open', impact: 5, likelihood: 5, due_date: '2026-01-01', task_ids: [], owner: 'x' }];
  const c1 = computeProgram(m, '2026-02-02');
  assert.ok(c1.variance.endSlip > 14);
  assert.equal(c1.health.schedule, 'red');
  assert.equal(c1.health.raid, 'red');
  assert.equal(c1.health.overall, 'red');
  assert.equal(c1.raid.topRisks[0].score, 25);
});
