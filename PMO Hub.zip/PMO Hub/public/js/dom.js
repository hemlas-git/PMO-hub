// Tiny DOM helpers. Text is always inserted as text nodes (never innerHTML), so data can't inject markup.

export function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  if (attrs !== null && attrs !== undefined && (typeof attrs !== 'object' || attrs instanceof Node || Array.isArray(attrs))) { kids.unshift(attrs); attrs = null; }
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v === null || v === undefined || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k === 'style') { for (const [p, x] of Object.entries(v)) (p.startsWith('--') ? el.style.setProperty(p, x) : (el.style[p] = x)); }
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
    else if (['value', 'checked', 'disabled', 'selected', 'multiple', 'required', 'readOnly'].includes(k)) el[k] = v;
    else el.setAttribute(k, v === true ? '' : v);
  }
  append(el, kids);
  return el;
}
function append(el, kids) {
  for (const k of kids.flat(Infinity)) {
    if (k === null || k === undefined || k === false) continue;
    el.append(k instanceof Node ? k : document.createTextNode(String(k)));
  }
}
const SVGNS = 'http://www.w3.org/2000/svg';
export function s(tag, attrs, ...kids) {
  const el = document.createElementNS(SVGNS, tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v === null || v === undefined || v === false) continue;
    if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
    else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
    else el.setAttribute(k, v);
  }
  append(el, kids);
  return el;
}
export const clear = (el) => { el.replaceChildren(); return el; };

// ---------------------------------------------------------------- formatting
export function money(n, cur = 'USD', compact = false) {
  try {
    return new Intl.NumberFormat(undefined, { style: 'currency', currency: cur, maximumFractionDigits: 0, notation: compact ? 'compact' : 'standard' }).format(n || 0);
  } catch { return `${cur} ${Math.round(n || 0)}`; }
}
export const num = (n, d = 0) => new Intl.NumberFormat(undefined, { maximumFractionDigits: d }).format(n || 0);
export const date = (s) => (s ? new Date(`${s}T00:00:00Z`).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC' }) : '—');
export const shortDate = (s) => (s ? new Date(`${s}T00:00:00Z`).toLocaleDateString(undefined, { day: 'numeric', month: 'short', timeZone: 'UTC' }) : '—');
export const datetime = (iso) => (iso ? new Date(iso).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' }) : '—');
export const signed = (n, d = 0) => (n > 0 ? '+' : '') + num(n, d);
export const days = (n) => (n === 0 ? 'on baseline' : `${n > 0 ? '+' : ''}${n}d`);

// ---------------------------------------------------------------- status indicators (icon + text, never colour alone)
const HEALTH = { green: ['●', 'On track'], amber: ['▲', 'At risk'], red: ['■', 'Off track'], draft: ['◌', 'Draft'], complete: ['✓', 'Complete'], on_hold: ['‖', 'On hold'], done: ['✓', 'Done'] };
export const healthBadge = (v, title) => h('span', { class: `badge b-${v}`, title: title || null }, HEALTH[v]?.[0] || '', ' ', HEALTH[v]?.[1] || v);
export const ragDot = (v, label) => h('span', { class: `dot ${v === 'done' ? 'green' : v || 'grey'}`, role: 'img', 'aria-label': label || v, title: label || v });
export const proposedTag = (on) => (on ? h('span', { class: 'tag-proposed', title: 'Generated proposal — not yet reviewed' }, 'Proposed') : null);
export const bar = (pct, expected) => h('div', { class: 'bar', role: 'progressbar', 'aria-valuenow': Math.round(pct), 'aria-valuemin': 0, 'aria-valuemax': 100 },
  h('span', { style: { width: `${Math.max(0, Math.min(100, pct))}%` } }), expected != null ? h('i', { class: 'mark', style: { left: `${Math.min(100, expected)}%` }, title: `Expected ${expected}%` }) : null);

export const STATUS_LABEL = { not_started: 'Not started', in_progress: 'In progress', complete: 'Complete', blocked: 'Blocked', open: 'Open', closed: 'Closed', draft: 'Draft', active: 'Active', on_hold: 'On hold' };
export const TYPE_LABEL = { phase: 'Phase', task: 'Task', subtask: 'Subtask', milestone: 'Milestone', risk: 'Risk', assumption: 'Assumption', issue: 'Issue', dependency: 'Dependency', decision: 'Decision' };

// ---------------------------------------------------------------- toast
export function toast(msg, isErr = false) {
  let box = document.querySelector('.toasts');
  if (!box) { box = h('div', { class: 'toasts', role: 'status', 'aria-live': 'polite' }); document.body.append(box); }
  const t = h('div', { class: `toast${isErr ? ' err' : ''}` }, msg);
  box.append(t);
  setTimeout(() => t.remove(), isErr ? 7000 : 3500);
}

export function errorBox(err) {
  const list = err?.errors || [];
  return h('div', { class: 'errors', role: 'alert' }, err?.message || 'Something went wrong', list.length ? h('ul', list.map((e) => h('li', typeof e === 'string' ? e : e.message))) : null);
}

// ---------------------------------------------------------------- tables
export function dataTable(cols, rows, { sort, onSort, onRow, empty, rowClass } = {}) {
  const head = h('tr', cols.map((c) => {
    const th = h('th', { class: c.num ? 'num' : '', scope: 'col', 'aria-sort': sort?.key === c.key ? (sort.dir === 1 ? 'ascending' : 'descending') : null });
    if (c.sort && onSort) th.append(h('button', { type: 'button', onClick: () => onSort(c.key) }, c.label, sort?.key === c.key ? (sort.dir === 1 ? ' ▲' : ' ▼') : ''));
    else th.append(c.label);
    return th;
  }));
  const body = rows.map((r) => {
    const tr = h('tr', { class: [onRow ? 'clickable' : '', rowClass ? rowClass(r) : ''].join(' ').trim(), tabindex: onRow ? 0 : null,
      onClick: onRow ? (e) => { if (!e.target.closest('a,button,input,select')) onRow(r); } : null,
      onKeydown: onRow ? (e) => { if (e.key === 'Enter' && !e.target.closest('a,button,input,select')) onRow(r); } : null },
    cols.map((c) => h('td', { class: c.num ? 'num' : c.class || '' }, c.render ? c.render(r) : r[c.key])));
    return tr;
  });
  const table = h('table', { class: 'data' }, h('thead', head), h('tbody', body));
  if (!rows.length && empty) return h('div', { class: 'table-wrap' }, table, h('div', { class: 'empty' }, empty));
  return h('div', { class: 'table-wrap' }, table);
}

// ---------------------------------------------------------------- forms + dialogs
/**
 * fields: [{name,label,type,options,required,hint,value,span2,min,max,step,placeholder,rows,disabled}]
 * types: text | textarea | number | date | select | checkbox | multiselect | email | password
 */
export function buildFields(fields) {
  const inputs = {};
  const grid = h('div', { class: 'form-grid' });
  for (const f of fields) {
    let el;
    const common = { name: f.name, required: f.required || null, disabled: f.disabled || null, placeholder: f.placeholder || null };
    if (f.type === 'textarea') el = h('textarea', { ...common, rows: f.rows || 3 }, f.value ?? '');
    else if (f.type === 'select') {
      el = h('select', common, (f.options || []).map(([v, l]) => h('option', { value: v ?? '', selected: String(v ?? '') === String(f.value ?? '') }, l)));
    } else if (f.type === 'multiselect') {
      el = h('select', { ...common, multiple: true, size: Math.min(7, Math.max(3, (f.options || []).length)) },
        (f.options || []).map(([v, l]) => h('option', { value: v, selected: (f.value || []).includes(v) }, l)));
    } else if (f.type === 'checkbox') el = h('input', { ...common, type: 'checkbox', checked: !!f.value });
    else el = h('input', { ...common, type: f.type || 'text', value: f.value ?? '', min: f.min ?? null, max: f.max ?? null, step: f.step ?? (f.type === 'number' ? 'any' : null), autocomplete: f.type === 'password' ? 'new-password' : null });
    inputs[f.name] = { el, f };
    const wrap = f.type === 'checkbox'
      ? h('label', { class: `check${f.span2 ? ' span2' : ''}` }, el, f.label)
      : h('label', { class: `field${f.span2 ? ' span2' : ''}` }, f.label + (f.required ? ' *' : ''), el, f.hint ? h('span', { class: 'hint' }, f.hint) : null);
    grid.append(wrap);
  }
  const read = () => {
    const out = {};
    for (const [name, { el, f }] of Object.entries(inputs)) {
      if (f.type === 'checkbox') out[name] = el.checked;
      else if (f.type === 'multiselect') out[name] = [...el.selectedOptions].map((o) => o.value);
      else if (f.type === 'number') out[name] = el.value === '' ? (f.nullable === false ? 0 : null) : Number(el.value);
      else if (f.type === 'date') out[name] = el.value === '' ? null : el.value;
      else if (f.type === 'select' && f.nullable) out[name] = el.value === '' ? null : el.value;
      else out[name] = el.value;
    }
    return out;
  };
  return { grid, read, inputs };
}

export function formModal({ title, fields, submitLabel = 'Save', onSubmit, extra, danger, intro }) {
  const dlg = h('dialog', { 'aria-labelledby': 'dlg-title' });
  const { grid, read } = buildFields(fields);
  const errHost = h('div');
  const submit = h('button', { class: 'btn btn-primary', type: 'submit' }, submitLabel);
  const form = h('form', { method: 'dialog', onSubmit: async (e) => {
    e.preventDefault();
    submit.disabled = true; errHost.replaceChildren();
    try { await onSubmit(read(), dlg); dlg.close(); } catch (err) { errHost.replaceChildren(errorBox(err)); dlg.querySelector('.dlg-body').scrollTop = 0; } finally { submit.disabled = false; }
  } },
  h('div', { class: 'dlg-head' }, h('h2', { id: 'dlg-title' }, title), h('button', { class: 'btn btn-link', type: 'button', 'aria-label': 'Close', onClick: () => dlg.close() }, '✕')),
  h('div', { class: 'dlg-body' }, errHost, intro ? h('p', { class: 'muted' }, intro) : null, grid, extra || null),
  h('div', { class: 'dlg-foot' }, danger ? h('button', { class: 'btn btn-danger', type: 'button', style: { marginRight: 'auto' }, onClick: async () => { try { await danger.onClick(); dlg.close(); } catch (err) { errHost.replaceChildren(errorBox(err)); } } }, danger.label) : null,
    h('button', { class: 'btn', type: 'button', onClick: () => dlg.close() }, 'Cancel'), submit));
  dlg.append(form);
  dlg.addEventListener('close', () => dlg.remove());
  document.body.append(dlg);
  dlg.showModal();
  return dlg;
}

export function confirmDialog({ title, message, confirmLabel = 'Confirm', danger = false, body }) {
  return new Promise((resolve) => {
    const dlg = h('dialog', { 'aria-labelledby': 'cf-title' });
    let result = false;
    dlg.append(h('form', { method: 'dialog' },
      h('div', { class: 'dlg-head' }, h('h2', { id: 'cf-title' }, title)),
      h('div', { class: 'dlg-body' }, message ? h('p', message) : null, body || null),
      h('div', { class: 'dlg-foot' }, h('button', { class: 'btn', type: 'button', onClick: () => dlg.close() }, 'Cancel'),
        h('button', { class: `btn ${danger ? 'btn-danger' : 'btn-primary'}`, type: 'button', onClick: () => { result = true; dlg.close(); } }, confirmLabel))));
    dlg.addEventListener('close', () => { dlg.remove(); resolve(result); });
    document.body.append(dlg);
    dlg.showModal();
  });
}

export const emptyState = (title, text, action) => h('div', { class: 'empty' }, h('h3', title), h('p', text), action || null);
