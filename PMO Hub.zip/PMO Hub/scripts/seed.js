// Loads the demo users and sample programs. Refuses to run if any user already exists.
import { initDb, migrate, query, closeDb } from '../src/db.js';
import { seedDemo } from '../src/seed.js';

await initDb();
await migrate();
const [{ n }] = await query('SELECT count(*) AS n FROM users');
if (Number(n) > 0) {
  console.error('Users already exist; refusing to seed. (Delete ./data/pglite for a fresh local database.)');
  process.exitCode = 1;
} else {
  await seedDemo();
  console.log('Demo data loaded. Sign in as admin@demo.test (see DEMO_PASSWORD).');
}
await closeDb();
