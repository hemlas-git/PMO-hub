import { z } from 'zod';

const isoDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Use YYYY-MM-DD').refine((s) => {
  const d = new Date(`${s}T00:00:00Z`);
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === s;
}, 'Not a valid date');
const text = (max = 2000) => z.string().trim().max(max);
const longText = text(10000);
const name = (max = 200) => z.string().trim().min(1, 'Required').max(max);
const uuid = z.string().uuid();
const money = z.coerce.number().min(0).max(1e12);
const currency = z.string().trim().toUpperCase().regex(/^[A-Z]{3}$/, 'Use a 3-letter currency code');
const nullableDate = isoDate.nullable().optional().or(z.literal('').transform(() => null));

export const password = z.string().min(10, 'At least 10 characters').max(200)
  .refine((p) => /[A-Za-z]/.test(p) && /\d/.test(p), 'Must contain letters and numbers');

export const loginSchema = z.object({ email: z.string().trim().toLowerCase().email().max(200), password: z.string().min(1).max(200) });

export const answersSchema = z.object({
  name: name(),
  program_type: z.enum(['technology', 'transformation', 'infrastructure', 'product', 'other']),
  objectives: z.string().trim().min(1, 'Add at least one objective').max(4000),
  outcomes: z.string().trim().min(1, 'Add at least one expected outcome').max(4000),
  scope: z.string().trim().min(1, 'Describe the scope').max(4000),
  exclusions: text(4000).default(''),
  sponsor: name(120),
  manager: name(120),
  start_date: isoDate,
  end_date: isoDate,
  delivery_approach: z.enum(['waterfall', 'agile', 'hybrid']),
  phases: z.array(name(80)).max(12).optional().default([]),
  workstreams: z.array(z.object({ name: name(100), lead: text(120).default(''), description: text(500).default('') })).min(1, 'Add at least one workstream').max(15),
  constraints: text(4000).default(''),
  geography: text(300).default(''),
  currency,
  budget_guidance: z.coerce.number().min(0).max(1e12).nullable().optional().or(z.literal('').transform(() => null)),
  team_roles: z.array(z.object({
    role: name(100), count: z.coerce.number().int().min(1).max(20).default(1), name: text(120).optional(),
    rate: z.coerce.number().min(0).max(100000).nullable().optional().or(z.literal('').transform(() => null)),
    allocation: z.coerce.number().int().min(1).max(100).optional(),
  })).max(30).default([]),
  dependencies: z.array(z.object({ name: name(200), description: text(1000).default(''), owner: text(120).default(''), needed_by: nullableDate })).max(30).default([]),
}).superRefine((a, ctx) => {
  if (a.end_date < a.start_date) ctx.addIssue({ code: 'custom', path: ['end_date'], message: 'End date must be after the start date' });
  else if ((new Date(a.end_date) - new Date(a.start_date)) / 86400000 < 56) ctx.addIssue({ code: 'custom', path: ['end_date'], message: 'Programs must run for at least 8 weeks to generate a plan' });
});

export const createProgramSchema = z.object({
  answers: answersSchema,
  edits: z.object({
    charter: z.record(z.enum(['summary', 'objectives', 'outcomes', 'success_measures', 'scope', 'exclusions', 'governance', 'constraints']), longText).optional(),
    approved_budget: money.nullable().optional(),
    code: text(30).optional(),
  }).optional().default({}),
});

const supportRequest = z.object({
  id: z.string().max(60), text: name(1000), status: z.enum(['open', 'resolved']),
  needed_by: nullableDate, raised_on: nullableDate,
});
export const programPatchSchema = z.object({
  name: name().optional(), code: text(30).optional(), status: z.enum(['active', 'on_hold', 'complete']).optional(),
  sponsor: name(120).optional(), manager: name(120).optional(), delivery_approach: z.enum(['waterfall', 'agile', 'hybrid']).optional(),
  start_date: isoDate.optional(), end_date: isoDate.optional(), currency: currency.optional(), geography: text(300).optional(),
  approved_budget: money.nullable().optional(),
  summary: longText.optional(), objectives: longText.optional(), outcomes: longText.optional(), success_measures: longText.optional(),
  scope: longText.optional(), exclusions: longText.optional(), governance: longText.optional(), constraints: longText.optional(),
  confirm_sections: z.array(z.enum(['summary', 'objectives', 'outcomes', 'success_measures', 'scope', 'exclusions', 'governance', 'constraints'])).max(8).optional(),
  status_narrative: text(5000).optional(),
  health_override: z.enum(['green', 'amber', 'red']).nullable().optional(),
  health_override_reason: text(1000).optional(),
  support_requests: z.array(supportRequest).max(30).optional(),
  assumptions: z.object({
    contingency_pct: z.coerce.number().min(0).max(100).optional(),
    forecast_method: z.enum(['percent', 'remaining', 'performance']).optional(),
    utilisation_pct: z.coerce.number().min(1).max(100).optional(),
    fx: z.record(currency, z.coerce.number().positive().max(100000)).optional(),
  }).optional(),
}).strict();

export const workstreamSchema = z.object({ name: name(100), lead: text(120).default(''), description: text(1000).default('') });

export const taskSchema = z.object({
  type: z.enum(['phase', 'task', 'subtask', 'milestone']),
  name: name(200),
  parent_id: uuid.nullable().optional().default(null),
  workstream_id: uuid.nullable().optional().default(null),
  resource_id: uuid.nullable().optional().default(null),
  start_date: isoDate,
  end_date: isoDate,
  estimate_hrs: z.coerce.number().min(0).max(1e6).default(0),
  actual_hrs: z.coerce.number().min(0).max(1e6).default(0),
  pct_complete: z.coerce.number().int().min(0).max(100).default(0),
  status: z.enum(['not_started', 'in_progress', 'complete', 'blocked']).default('not_started'),
  notes: text(3000).default(''),
  predecessors: z.array(uuid).max(50).default([]),
  cascade: z.boolean().optional().default(true),
});
export const taskPatchSchema = taskSchema.partial();

export const resourceSchema = z.object({
  name: name(120), role: text(100).default(''),
  rate: z.coerce.number().min(0).max(100000).nullable().optional().or(z.literal('').transform(() => null)),
  rate_currency: z.string().trim().toUpperCase().regex(/^([A-Z]{3})?$/).default(''),
  capacity_hrs_week: z.coerce.number().min(0).max(80).default(40),
  allocation_pct: z.coerce.number().int().min(0).max(100).default(100),
  chargeable: z.boolean().default(true),
  is_placeholder: z.boolean().default(false),
  rate_assumed: z.boolean().default(false),
});

export const budgetLineSchema = z.object({
  category: name(100), description: text(500).default(''),
  planned_amount: money.default(0), actual_amount: money.default(0),
  forecast_override: money.nullable().optional().or(z.literal('').transform(() => null)),
  is_assumption: z.boolean().default(false), notes: text(1000).default(''),
});

export const raidSchema = z.object({
  type: z.enum(['risk', 'assumption', 'issue', 'dependency', 'decision']),
  title: name(200), description: text(3000).default(''), owner: text(120).default(''),
  status: z.enum(['open', 'in_progress', 'closed']).default('open'),
  impact: z.coerce.number().int().min(1).max(5).nullable().optional().or(z.literal('').transform(() => null)),
  likelihood: z.coerce.number().int().min(1).max(5).nullable().optional().or(z.literal('').transform(() => null)),
  response: text(3000).default(''),
  due_date: nullableDate,
  workstream_id: uuid.nullable().optional().default(null),
  task_ids: z.array(uuid).max(50).default([]),
});

export const baselineSchema = z.object({ note: text(1000).default(''), confirm: z.boolean().default(false) });

export const userCreateSchema = z.object({
  email: z.string().trim().toLowerCase().email().max(200), name: name(120), password,
  global_role: z.enum(['admin', 'portfolio_leader', 'program_manager', 'member']).default('member'),
});
export const userPatchSchema = z.object({
  name: name(120).optional(), global_role: z.enum(['admin', 'portfolio_leader', 'program_manager', 'member']).optional(),
  active: z.boolean().optional(), password: password.optional(),
}).strict();
export const membersSchema = z.object({
  members: z.array(z.object({ user_id: uuid, role: z.enum(['manager', 'lead', 'finance', 'viewer']) })).max(200),
});
export const portfolioSettingsSchema = z.object({
  base_currency: currency, fx: z.record(currency, z.coerce.number().positive().max(100000)),
});
export const changePasswordSchema = z.object({ current: z.string().min(1).max(200), next: password });
