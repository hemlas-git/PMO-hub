import { formModal } from '../dom.js';
import { del } from '../api.js';

/** Typed-name confirmation, then DELETE. onDone runs after a successful delete. */
export function deleteProgramDialog(p, onDone) {
  formModal({
    title: `Delete program "${p.name}"?`, submitLabel: 'Delete permanently',
    intro: 'This permanently removes the program with its charter, plan, resources, budget, RAID log, baselines and change history. It cannot be undone.',
    fields: [{ name: 'confirm', label: `Type the program name to confirm: ${p.name}`, required: true, span2: true }],
    onSubmit: async (v) => {
      if (v.confirm.trim() !== p.name) throw new Error('The name you typed does not match');
      await del(`/programs/${p.id}`);
      await onDone();
    },
  });
}
