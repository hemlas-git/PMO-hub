import { h, date, shortDate, datetime, money, num, days, signed, healthBadge, ragDot, bar, formModal, confirmDialog, proposedTag, emptyState } from '../dom.js';
import { get, patch } from '../api.js';

const rid = () => (crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`);
const kpi = (label, value, sub, cls = '', extra) => h('div', { class: 'kpi' }, h('div', { class: 'label' }, label), h('div', { class: `value ${cls}` }, value), sub ? h('div', { class: 'sub' }, sub) : null, extra || null);

export async function render(ctx) {
  const d = ctx.data;
  const p = d.program;
  const cur = p.currency;
  const b = d.budget;
  const v = d.variance;
  const canEdit = d.caps.charter;
  const audit = await get(`/programs/${ctx.id}/audit?category=material&limit=6`);

  // ---- KPIs
  const slip = v ? v.endSlip : 0;
  const kpis = h('div', { class: 'grid g4' },
    kpi('Progress', `${d.plan.progress}%`, `${d.plan.plannedProgress}% expected by today`, d.plan.progress + 8 < d.plan.plannedProgress ? 'warn' : '', bar(d.plan.progress, d.plan.plannedProgress)),
    kpi('Forecast finish', date(d.plan.forecastEnd), v ? `Baseline ${date(v.baseEnd)} (${days(slip)})` : 'No baseline yet', slip > 14 ? 'bad' : slip > 0 ? 'warn' : ''),
    kpi('Forecast vs approved budget', money(b.forecast, cur, true), b.approved ? `${b.variance >= 0 ? 'Under' : 'Over'} by ${money(Math.abs(b.variance), cur, true)} of ${money(b.approved, cur, true)}` : 'No approved budget set', b.variance < 0 ? 'bad' : ''),
    kpi('Actual spend', money(b.actual, cur, true), b.spentPct != null ? `${Math.round(b.spentPct)}% of approved budget` : ''));

  // ---- health
  const dot = (k, label) => h('li', ragDot(d.health[k], label), ' ', h('strong', label), ' — ', { green: 'on track', amber: 'at risk', red: 'off track' }[d.health[k]]);
  const healthCard = h('div', { class: 'card' }, h('div', { class: 'card-head' }, h('h2', 'Health'), healthBadge(d.health.overall),
    canEdit && p.status !== 'draft' ? h('button', { class: 'btn btn-sm', type: 'button', onClick: () => overrideDialog(ctx) }, d.health.overridden ? 'Change override' : 'Override…') : null),
  p.status === 'draft' ? h('p', { class: 'muted' }, 'Health is calculated once the program is baselined and active.') : h('ul', { class: 'plain' }, dot('schedule', 'Schedule'), dot('budget', 'Budget'), dot('raid', 'RAID')),
  d.health.overridden ? h('div', { class: 'notice info' }, `Overridden to ${d.health.overall} (calculated: ${d.health.computed}). Reason: ${d.health.override_reason || 'not given'}`) : null,
  d.health.reasons.length ? h('ul', { class: 'small' }, d.health.reasons.map((r) => h('li', r))) : null);

  // ---- narrative
  const ta = h('textarea', { rows: 5, readOnly: !canEdit, 'aria-label': 'Status narrative' }, p.status_narrative);
  const narrative = h('div', { class: 'card' }, h('div', { class: 'card-head' }, h('h2', 'Status narrative'),
    canEdit ? h('button', { class: 'btn btn-sm btn-primary', type: 'button', onClick: () => ctx.act(() => patch(`/programs/${ctx.id}`, { status_narrative: ta.value }), 'Status saved') }, 'Save status') : null),
  ta, h('p', { class: 'muted small' }, p.narrative_updated_at ? `Last updated ${datetime(p.narrative_updated_at)} by ${p.narrative_updated_by}` : 'Not yet updated. Status changes are recorded in the change history.'));

  // ---- support requests
  const reqs = p.support_requests || [];
  const supportCard = h('div', { class: 'card' }, h('div', { class: 'card-head' }, h('h2', 'Management support requested'),
    canEdit ? h('button', { class: 'btn btn-sm', type: 'button', onClick: () => requestDialog(ctx) }, '+ Add request') : null),
  reqs.length ? h('ul', { class: 'plain' }, reqs.map((r) => h('li', h('div', { class: 'row spread' }, h('span', h('span', { class: `badge ${r.status === 'open' ? 'b-amber' : 'b-grey'}` }, r.status === 'open' ? 'Open' : 'Resolved'), ' ', r.text),
    canEdit ? h('span', h('button', { class: 'btn btn-sm', type: 'button', onClick: () => requestDialog(ctx, r) }, 'Edit')) : null),
  h('div', { class: 'muted small' }, r.needed_by ? `Needed by ${date(r.needed_by)}` : 'No date', r.raised_on ? ` · raised ${date(r.raised_on)}` : '')))) : emptyState('No support requested', 'Raise anything the steering committee or sponsor needs to unblock, fund or decide.'));

  // ---- milestones / risks
  const ms = h('div', { class: 'card' }, h('h2', 'Next milestones'), d.plan.nextMilestones.length ? h('ul', { class: 'plain' }, d.plan.nextMilestones.map((m) => h('li', h('div', { class: 'row spread' },
    h('span', ragDot(m.rag, m.rag), ' ', m.name, m.critical ? h('span', { class: 'crit' }, ' CRITICAL PATH') : null), h('span', { class: m.overdue ? 'bad small' : 'muted small' }, (m.overdue ? 'Overdue · ' : '') + date(m.end)))))) : h('p', { class: 'muted' }, 'No upcoming milestones.'));
  const risks = h('div', { class: 'card' }, h('div', { class: 'card-head' }, h('h2', 'Top risks'), h('a', { href: `#/p/${ctx.id}/raid` }, 'RAID log →')),
    d.raid.topRisks.length ? h('ul', { class: 'plain' }, d.raid.topRisks.map((r) => h('li', h('strong', { class: r.score >= 15 ? 'bad' : '' }, `${r.score} `), r.title, h('div', { class: 'muted small' }, r.owner || 'No owner')))) : h('p', { class: 'muted' }, 'No open risks scored yet.'),
    h('p', { class: 'small muted' }, `${d.raid.overdueDecisions} overdue decisions · ${d.raid.overdueActions} overdue actions · ${d.raid.highCount} high-priority open items`));

  // ---- key changes
  const changes = [];
  if (v) {
    if (v.endSlip) changes.push(`Finish date ${days(v.endSlip)} vs baseline v${v.version}`);
    if (v.budgetDelta) changes.push(`Approved budget changed by ${money(v.budgetDelta, cur, true)} vs baseline`);
    if (v.hoursDelta) changes.push(`Planned effort ${signed(v.hoursDelta)} h vs baseline`);
    if (v.milestoneSlips) changes.push(`${v.milestoneSlips} milestone(s) later than baseline`);
    if (Math.abs(v.forecastVsBaseCost) > 1) changes.push(`Forecast is ${money(v.forecastVsBaseCost, cur, true)} ${v.forecastVsBaseCost > 0 ? 'above' : 'below'} baseline plan cost`);
  }
  const changeCard = h('div', { class: 'card' }, h('div', { class: 'card-head' }, h('h2', 'Key changes'), h('a', { href: `#/p/${ctx.id}/history` }, 'Change history →')),
    changes.length ? h('ul', changes.map((c) => h('li', c))) : h('p', { class: 'muted' }, v ? 'No variance against the approved baseline.' : 'Approve a baseline to track variance.'),
    audit.entries.length ? h('ul', { class: 'plain small' }, audit.entries.map((e) => h('li', h('span', { class: 'muted' }, `${datetime(e.at)} · ${e.user_name} — `), e.summary || `${e.entity} ${e.entity_name}`))) : null);

  const charter = h('div', { class: 'card' }, h('div', { class: 'card-head' }, h('h2', 'Executive summary'), proposedTag(p.proposal_state?.sections?.summary), h('a', { href: `#/p/${ctx.id}/charter` }, 'Charter →')),
    h('pre', { class: 'text' }, p.summary || 'No summary yet.'));

  return h('div', kpis, h('div', { class: 'grid g-main', style: { marginTop: '16px' } },
    h('div', charter, narrative, changeCard), h('div', healthCard, supportCard, ms, risks)));
}

function overrideDialog(ctx) {
  const p = ctx.data.program;
  formModal({
    title: 'Override calculated health', submitLabel: 'Save override',
    intro: `The calculated health is ${ctx.data.health.computed}. An override is recorded in the change history with your reason.`,
    fields: [{ name: 'health_override', label: 'Health', type: 'select', nullable: true, value: p.health_override || '', options: [['', 'No override (use calculated)'], ['green', 'On track'], ['amber', 'At risk'], ['red', 'Off track']] },
      { name: 'health_override_reason', label: 'Reason', type: 'textarea', value: p.health_override_reason, span2: true }],
    onSubmit: async (v) => { if (v.health_override && !v.health_override_reason.trim()) throw new Error('Please give a reason for the override'); ctx.apply(await patch(`/programs/${ctx.id}`, v)); },
  });
}

function requestDialog(ctx, existing) {
  const reqs = ctx.data.program.support_requests || [];
  const save = (list) => patch(`/programs/${ctx.id}`, { support_requests: list }).then((r) => ctx.apply(r));
  formModal({
    title: existing ? 'Edit support request' : 'New support request',
    fields: [{ name: 'text', label: 'What do you need from management?', type: 'textarea', required: true, value: existing?.text, span2: true },
      { name: 'needed_by', label: 'Needed by', type: 'date', value: existing?.needed_by },
      { name: 'status', label: 'Status', type: 'select', options: [['open', 'Open'], ['resolved', 'Resolved']], value: existing?.status || 'open' }],
    danger: existing ? { label: 'Delete', onClick: () => save(reqs.filter((r) => r.id !== existing.id)) } : null,
    onSubmit: async (v) => {
      const item = { id: existing?.id || rid(), text: v.text, status: v.status, needed_by: v.needed_by, raised_on: existing?.raised_on || new Date().toISOString().slice(0, 10) };
      await save(existing ? reqs.map((r) => (r.id === existing.id ? item : r)) : [...reqs, item]);
    },
  });
}
