# PMO Hub — program & portfolio management

Create a program from a guided form, review a **proposed** charter / baseline plan / resource and budget plan / RAID log, approve a baseline, then track actuals and change. Portfolio leaders get a cross-program view of health, budget, top risks and management-support requests.

> **Status:** the 7 unit tests pass, the server starts and seeds the demo data, and the API flows (proposal → create → baseline, cycle/date validation, cascade, role-based access, CSRF) and every UI page were exercised against a local run. Visual polish has not been reviewed by eye.

## Stack

| | |
|---|---|
| Runtime / API | Node 20+, Express 5, ES modules |
| Database | PostgreSQL. **Local: embedded PGlite (no install).** **Cloud: Cloud SQL for PostgreSQL** via `pg`. Same SQL, one schema: `db/schema.sql` |
| Validation | zod on every write endpoint |
| Frontend | No-build vanilla ES-module SPA (`public/`), SVG Gantt, strict CSP, no `innerHTML` |
| Auth | Email + password (scrypt), server-side sessions (hashed token, HttpOnly SameSite cookie), CSRF header + origin check, lockout and IP throttling |
| Cloud | Google Cloud Run + Cloud SQL + Secret Manager (`deploy/gcp-deploy.sh`, `Dockerfile`) |

## Run locally

```bash
cd pmo-hub
# If Node isn't installed, a local copy may exist in .tools/ :
# export PATH="$PWD/.tools/node-v22.23.4-darwin-arm64/bin:$PATH"
npm install
cp .env.example .env      # optional; defaults work
npm test                  # unit tests for the calculation engine and proposal generator
npm start                 # http://localhost:3100
```

On first start with an empty database and `NODE_ENV` ≠ production, demo users and four sample programs are created (set `SEED_DEMO=false` to skip). Demo password: `DEMO_PASSWORD` (default `Demo-Pass-2026!`, local use only).

| Demo user | Role |
|---|---|
| admin@demo.test | Administrator |
| steerco@demo.test | Portfolio leader (sees everything) |
| pm.alex@demo.test, pm.sam@demo.test | Program managers (own programs) |
| lead@demo.test | Workstream lead on one program |
| finance@demo.test | Resource/finance partner on three programs |

Sample programs: **Customer Platform Modernisation** (amber: slipped data migration, over-allocated engineer, missing rate), **EMEA Finance Process Transformation** (green), **Data Centre Exit** (red: late, over budget, overdue decisions) and **Customer Loyalty Programme Relaunch** (a fresh, un-baselined draft showing "Proposed" labels). Dates are relative to today. To reset: stop the server and delete `./data/pglite`.

## Configuration

All configuration is environment variables (see `.env.example`). Nothing secret is in client code or the repo.

| Variable | Purpose |
|---|---|
| `DATABASE_URL` | Postgres connection string. Empty = embedded local DB in `DATA_DIR` |
| `NODE_ENV=production` | Requires `DATABASE_URL`, secure cookies, HSTS, no demo seed |
| `TRUST_PROXY=true` | Set behind Cloud Run / a load balancer |
| `SESSION_HOURS` | Session lifetime (default 12) |
| `SEED_DEMO`, `DEMO_PASSWORD` | Demo data (default on only when not production) |
| `BOOTSTRAP_ADMIN_EMAIL/NAME/PASSWORD` | Optional: create the first admin at startup when no users exist |

## Database

`db/schema.sql` is idempotent and runs automatically on start (or `npm run migrate`). Tables: `users, sessions, settings, programs, program_members, workstreams, resources, tasks, task_deps, budget_lines, raid_items, raid_links, baselines, audit_log`. Against your own Postgres 13+:

```bash
DATABASE_URL=postgres://user:pass@host:5432/pmohub npm run migrate
```

## Deploy to Google Cloud

Prereqs: `gcloud` installed and logged in, a project with billing.

```bash
PROJECT_ID=my-project REGION=europe-west2 ./deploy/gcp-deploy.sh
```

It enables APIs, creates a Cloud SQL Postgres 16 instance and database, stores `DATABASE_URL` (with a generated password) in **Secret Manager**, builds the container with Cloud Build, creates a least-privilege service account, and deploys to Cloud Run with the Cloud SQL connection and `NODE_ENV=production`. Put the service behind your identity/network controls (e.g. IAP, custom domain + Cloud Armor) as required by your organisation; the app itself enforces sign-in.

### First administrator

Choose one:

1. **Bootstrap secret (simplest on Cloud Run).** Create secrets for the email and a strong password, deploy once with `--set-env-vars BOOTSTRAP_ADMIN_EMAIL=...` and `--set-secrets BOOTSTRAP_ADMIN_PASSWORD=...:latest`. The admin is created only if the `users` table is empty. Then remove those variables.
2. **CLI against the database.** With the [Cloud SQL Auth Proxy](https://cloud.google.com/sql/docs/postgres/sql-proxy) running locally:
   ```bash
   DATABASE_URL='postgres://pmohub:PASSWORD@127.0.0.1:5432/pmohub' npm run create-admin -- you@company.com "Your Name"
   ```
   (the password is prompted for, or read from `ADMIN_PASSWORD`).

Sign in, open **Admin**, add users, set their global role and grant per-program access.

## Sign-in is off by default

Everyone who can open the URL acts as one shared administrator with full access (no login screen). Each person can click **Set your name** in the top bar so the change history records who made an edit (stored in their browser; it is a label, not authentication). Set `REQUIRE_LOGIN=true` to turn on individual accounts and the role-based access described below. Because there is no login, only share the URL with people you trust and keep it on a private network, behind your company SSO/IAP, or share the link only internally. The Cloud Run deploy script therefore creates a **private** service unless you set `ALLOW_PUBLIC=true`.

## Roles and access (when REQUIRE_LOGIN=true)

* **Global role:** `admin` (everything), `portfolio_leader` (read every program; can approve baselines), `program_manager` (can create programs), `member` (assigned programs only).
* **Per-program role:** `manager` (edit all), `lead` (plan, progress, RAID), `finance` (resources, rates, budget), `viewer` (read only).
* Users only receive programs they are authorised for; other program ids return 404. All checks are server-side in `src/auth.js` / `src/routes/programs.js`.

## How the connected model works

`src/calc.js` is a pure engine. The API stores raw facts (tasks, dates, estimates, actuals, rates, RAID, baselines) and **recomputes everything on read**, so any edit flows through immediately:

* Task dates/estimates → rolled-up phase dates, critical path, effort per person/week/month, labour cost, forecast, over-allocation, health, portfolio row.
* Actual hours / % complete / spend → actuals, estimate to complete (method is an editable assumption), forecast at completion, variance.
* RAID → schedule/budget/RAID health, top risks and overdue counts on the overview and portfolio.
* Changing a task's finish date optionally pushes finish-to-start successors out automatically (audited).
* Each baseline snapshots dates, effort and budget; variance is always current plan vs the latest baseline. Earlier baselines stay in the history.
* The audit log records field-level changes with categories: baseline, material, status, progress.

## Start from a document

On **New program** you can upload a statement of work, business case, project charter or any initial project document (`.docx`, `.pdf`, `.txt`, `.md`, up to 10 MB each, several at once) or paste text. The wizard is pre-filled from it (name, sponsor, manager, dates, objectives, outcomes, scope, exclusions, constraints, workstreams, team, dependencies, geography, currency, budget, delivery approach, program type). You review and edit everything; the normal proposal, review and baseline steps still apply.

* **Keyword analysis (default):** reads headings and labels such as "Objectives", "Out of scope", "Sponsor:", "Budget:". No external calls.
* **AI analysis:** set `ANTHROPIC_API_KEY` (and optionally `ANTHROPIC_MODEL`) and Claude extracts the details instead. The document text is then sent to the Anthropic API, and the wizard says so. On any API failure it falls back to keyword analysis. Store the key in Secret Manager in production.
* Files are processed in memory and never stored. Document text is treated as untrusted data; results only pre-fill the form.
* Code: `src/analyze.js`, `src/routes/documents.js`, uploader in `public/js/pages/wizard.js`.

## Proposals

`src/proposal.js` is a deterministic rule-based generator (no AI call). It adapts to the **program type**, **delivery approach**, optional **custom phases**, workstreams, team, dependencies, constraints, geography and budget guidance. Everything generated is stored with `is_proposed = true` and shown with **Proposed** / **assumed** labels. Editing an item (or approving a baseline, with explicit confirmation) clears the label. Benchmark hourly rates are generic estimates, clearly flagged, to be replaced by your rate card.

## Project layout

```
db/schema.sql          database schema
src/server.js          app, security headers, bootstrap
src/db.js              Postgres (pg) / PGlite adapter
src/auth.js            passwords, sessions, CSRF, program access
src/calc.js            schedule, resources, budget, RAID, health, baseline variance
src/proposal.js        proposal generator
src/service.js         data loading, program creation, baseline approval, audit
src/routes/            REST API (programs, auth/admin)
src/seed.js            demo data
public/                SPA (js/pages/* one module per page)
scripts/               migrate, seed, create-admin
deploy/gcp-deploy.sh   Cloud Run + Cloud SQL + Secret Manager
test/                  node:test unit tests
```

## Extension points (not in the MVP)

Integrations (Jira/Azure DevOps/finance systems), notifications/email, SSO (OIDC) in place of passwords in `src/auth.js`, per-workstream permissions, portfolio analytics and scenario planning, resource calendars/holidays, non-finish-to-start dependency types, rate cards by role/period, MFA, CSV/PDF export.

## Known limitations

* Dependencies are finish-to-start between leaf items; weekends only (no holiday calendars).
* Rates are hourly and effort is spread evenly across working days.
* Login throttling is per instance (in memory); use Cloud Armor/IAP for stronger edge protection.
* Money is stored as `numeric(14,2)`; hours as double precision.
