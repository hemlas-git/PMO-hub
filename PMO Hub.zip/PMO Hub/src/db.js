import fs from 'node:fs';
import path from 'node:path';
import pg from 'pg';
import { PGlite } from '@electric-sql/pglite';
import { config } from './config.js';

// OIDs: 20 int8, 1082 date, 1700 numeric. Return plain numbers / 'YYYY-MM-DD' strings.
const parseNum = (v) => (v === null ? null : parseFloat(v));
const parseDate = (v) => v;

let pool = null;
let lite = null;

export async function initDb() {
  if (config.databaseUrl) {
    pg.types.setTypeParser(20, parseNum);
    pg.types.setTypeParser(1700, parseNum);
    pg.types.setTypeParser(1082, parseDate);
    pool = new pg.Pool({
      connectionString: config.databaseUrl,
      ssl: config.pgSsl ? { rejectUnauthorized: false } : undefined,
      max: 10,
    });
  } else {
    if (!config.dataDir.startsWith('memory://')) fs.mkdirSync(config.dataDir, { recursive: true });
    lite = new PGlite(config.dataDir, {
      parsers: { 20: parseNum, 1700: parseNum, 1082: parseDate },
    });
    await lite.waitReady;
  }
}

const rows = (r) => r.rows;

/** Run one statement; returns rows. */
export function query(sql, params = []) {
  return pool ? pool.query(sql, params).then(rows) : lite.query(sql, params).then(rows);
}

/** Run a multi-statement script (no parameters). */
export async function exec(sql) {
  if (pool) await pool.query(sql);
  else await lite.exec(sql);
}

/** Run fn inside a transaction. fn receives { query }. */
export async function tx(fn) {
  if (pool) {
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const out = await fn({ query: (s, p = []) => client.query(s, p).then(rows) });
      await client.query('COMMIT');
      return out;
    } catch (e) {
      await client.query('ROLLBACK').catch(() => {});
      throw e;
    } finally {
      client.release();
    }
  }
  return lite.transaction((t) => fn({ query: (s, p = []) => t.query(s, p).then(rows) }));
}

export async function migrate() {
  const sql = fs.readFileSync(path.join(config.root, 'db', 'schema.sql'), 'utf8');
  await exec(sql);
}

export async function closeDb() {
  if (pool) await pool.end();
  if (lite) await lite.close();
}
