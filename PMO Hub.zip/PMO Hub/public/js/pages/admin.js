import { h, dataTable, formModal, toast, errorBox, datetime } from '../dom.js';
import { get, post, patch, put } from '../api.js';

const ROLES = [['admin', 'Administrator'], ['portfolio_leader', 'Portfolio leader (sees all programs)'], ['program_manager', 'Program manager (can create programs)'], ['member', 'Member (assigned programs only)']];
const PROG_ROLES = [['', 'No access'], ['manager', 'Manager — edit everything'], ['lead', 'Workstream lead — plan, progress, RAID'], ['finance', 'Resource / finance — resources & budget'], ['viewer', 'Viewer — read only']];

export async function render() {
  const host = h('div');
  async function draw() {
    const [{ users }, { programs }, settings] = await Promise.all([get('/admin/users'), get('/admin/programs'), get('/admin/settings')]);
    host.replaceChildren(
      h('div', { class: 'page-head' }, h('div', h('h1', 'Administration'), h('p', { class: 'muted' }, 'Accounts, program access and portfolio currency settings.'))),
      usersCard(users, draw), accessCard(users, programs), fxCard(settings, draw));
  }
  await draw();
  return host;
}

function usersCard(users, redraw) {
  const cols = [
    { key: 'name', label: 'Name', render: (u) => h('strong', u.name) }, { key: 'email', label: 'Email', render: (u) => u.email },
    { key: 'role', label: 'Role', render: (u) => ROLES.find((r) => r[0] === u.global_role)?.[1].split(' (')[0] },
    { key: 'active', label: 'Status', render: (u) => h('span', { class: `badge ${u.active ? 'b-green' : 'b-grey'}` }, u.active ? '● Active' : 'Disabled') },
    { key: 'created', label: 'Created', render: (u) => h('span', { class: 'small muted' }, datetime(u.created_at)) },
    { key: 'a', label: '', render: (u) => h('button', { class: 'btn btn-sm', type: 'button', onClick: () => editUser(u, redraw) }, 'Edit') },
  ];
  return h('div', { class: 'card' }, h('div', { class: 'card-head' }, h('h2', 'Users'), h('button', { class: 'btn btn-primary btn-sm', type: 'button', onClick: () => newUser(redraw) }, '+ Add user')), dataTable(cols, users));
}

function newUser(redraw) {
  formModal({
    title: 'Add user', intro: 'Passwords need at least 10 characters with letters and numbers. Share the initial password securely and ask the user to change it.',
    fields: [{ name: 'name', label: 'Name', required: true }, { name: 'email', label: 'Email', type: 'email', required: true }, { name: 'password', label: 'Initial password', type: 'password', required: true },
      { name: 'global_role', label: 'Role', type: 'select', options: ROLES, value: 'member' }],
    onSubmit: async (v) => { await post('/admin/users', v); toast('User created'); redraw(); },
  });
}

function editUser(u, redraw) {
  formModal({
    title: `Edit ${u.name}`,
    fields: [{ name: 'name', label: 'Name', value: u.name, required: true }, { name: 'global_role', label: 'Role', type: 'select', options: ROLES, value: u.global_role },
      { name: 'active', label: 'Account active', type: 'checkbox', value: u.active }, { name: 'password', label: 'Reset password (leave blank to keep)', type: 'password' }],
    onSubmit: async (v) => { const body = { ...v }; if (!body.password) delete body.password; await patch(`/admin/users/${u.id}`, body); toast('User updated'); redraw(); },
  });
}

function accessCard(users, programs) {
  const body = h('div');
  const pick = h('select', { 'aria-label': 'Program', onChange: () => load(pick.value) }, [h('option', { value: '' }, 'Select a program…'), ...programs.map((p) => h('option', { value: p.id }, `${p.code} — ${p.name}`))]);
  async function load(pid) {
    if (!pid) { body.replaceChildren(h('p', { class: 'muted' }, 'Choose a program to manage who can see and edit it. Administrators and portfolio leaders can already see every program.')); return; }
    const { members } = await get(`/admin/programs/${pid}/members`);
    const cur = new Map(members.map((m) => [m.user_id, m.role]));
    const sels = new Map();
    const rows = users.filter((u) => u.active).map((u) => {
      const sel = h('select', { 'aria-label': `Access for ${u.name}` }, PROG_ROLES.map(([v, l]) => h('option', { value: v, selected: (cur.get(u.id) || '') === v }, l)));
      sels.set(u.id, sel);
      return h('tr', h('td', h('strong', u.name), h('div', { class: 'muted small' }, u.email)), h('td', { class: 'small' }, u.global_role.replace('_', ' ')), h('td', sel));
    });
    const err = h('div');
    body.replaceChildren(h('div', { class: 'table-wrap' }, h('table', { class: 'data' }, h('thead', h('tr', h('th', 'User'), h('th', 'Global role'), h('th', 'Access to this program'))), h('tbody', rows))), err,
      h('div', { style: { marginTop: '12px' } }, h('button', { class: 'btn btn-primary', type: 'button', onClick: async () => {
        try {
          await put(`/admin/programs/${pid}/members`, { members: [...sels].filter(([, s]) => s.value).map(([user_id, s]) => ({ user_id, role: s.value })) });
          toast('Access saved'); err.replaceChildren();
        } catch (e) { err.replaceChildren(errorBox(e)); }
      } }, 'Save access')));
  }
  load('');
  return h('div', { class: 'card', style: { marginTop: '16px' } }, h('div', { class: 'card-head' }, h('h2', 'Program access'), pick), body);
}

function fxCard(settings, redraw) {
  const base = h('input', { value: settings.base_currency, maxlength: 3, style: { width: '90px' }, 'aria-label': 'Base currency' });
  const fx = h('textarea', { rows: 3, 'aria-label': 'FX rates' }, Object.entries(settings.fx).map(([k, v]) => `${k}=${v}`).join('\n'));
  const err = h('div');
  return h('div', { class: 'card', style: { marginTop: '16px' } }, h('h2', 'Portfolio currency'),
    h('p', { class: 'muted small' }, 'Portfolio totals are shown in the base currency. Enter how many base-currency units one unit of each program currency is worth, e.g. EUR=1.08.'),
    h('label', { class: 'field', style: { maxWidth: '200px' } }, 'Base currency', base), h('label', { class: 'field', style: { marginTop: '10px', maxWidth: '360px' } }, 'Exchange rates (one per line)', fx), err,
    h('div', { style: { marginTop: '12px' } }, h('button', { class: 'btn btn-primary', type: 'button', onClick: async () => {
      try {
        const map = {};
        for (const line of fx.value.split(/[\n,]+/).map((x) => x.trim()).filter(Boolean)) {
          const m = line.match(/^([A-Za-z]{3})\s*[=:]\s*([\d.]+)$/);
          if (!m) throw new Error(`Could not read "${line}". Use the form EUR=1.08`);
          map[m[1].toUpperCase()] = Number(m[2]);
        }
        await put('/admin/settings', { base_currency: base.value.toUpperCase(), fx: map });
        toast('Currency settings saved'); err.replaceChildren(); redraw();
      } catch (e) { err.replaceChildren(errorBox(e)); }
    } }, 'Save')));
}
