// Rule-based proposal generator. Turns the guided-form answers into a draft charter, baseline plan,
// resource plan, budget assumptions and initial RAID log. Output is deterministic and every generated
// item is flagged as a proposal/assumption; nothing here is presented as confirmed fact.
// The structure adapts to the program type (technology, business change, infrastructure/construction,
// product, general) and to custom phases supplied by the user.

import { addDays, diffDays, workdays } from './calc.js';

export const PROGRAM_TYPES = {
  technology: 'Technology / software delivery',
  transformation: 'Business or organisational change',
  infrastructure: 'Infrastructure, construction or facilities',
  product: 'Product development or launch',
  other: 'General / other',
};

// kind: mobilise | work | close. act = activity label, subs = two sub-activities.
const P = (name, weight, kind, act, subs) => ({ name, weight, kind, act, subs });
const PHASES = {
  technology: {
    waterfall: [P('Mobilise & Initiate', 0.08, 'mobilise'), P('Plan & Design', 0.2, 'work', 'Define requirements and design', ['Gather requirements', 'Agree design and sign-off']), P('Build', 0.34, 'work', 'Build and configure', ['Develop / configure', 'Review and rework']), P('Test & Validate', 0.16, 'work', 'Test and validate', ['Execute test cycles', 'Fix defects and retest']), P('Deploy & Transition', 0.14, 'work', 'Deploy and hand over', ['Prepare cutover and training', 'Go-live and hypercare']), P('Close', 0.08, 'close')],
    agile: [P('Mobilise & Discovery', 0.1, 'mobilise'), P('Release 1', 0.24, 'work', 'Deliver release 1 increment', ['Sprint delivery', 'Review and demo']), P('Release 2', 0.24, 'work', 'Deliver release 2 increment', ['Sprint delivery', 'Review and demo']), P('Release 3', 0.24, 'work', 'Deliver release 3 increment', ['Sprint delivery', 'Review and demo']), P('Hardening & Go-live', 0.1, 'work', 'Harden and release', ['Hardening and regression', 'Go-live and hypercare']), P('Close & Retrospective', 0.08, 'close')],
    hybrid: [P('Mobilise & Initiate', 0.08, 'mobilise'), P('Design', 0.18, 'work', 'Define and design', ['Gather requirements', 'Agree design and sign-off']), P('Iterative Build', 0.34, 'work', 'Iterative build', ['Sprint delivery', 'Review and demo']), P('Integrate & Test', 0.16, 'work', 'Integrate and test', ['Execute test cycles', 'Fix defects and retest']), P('Deploy & Transition', 0.16, 'work', 'Deploy and hand over', ['Prepare cutover and training', 'Go-live and hypercare']), P('Close', 0.08, 'close')],
  },
  transformation: [P('Mobilise & Initiate', 0.08, 'mobilise'), P('Assess & Design', 0.22, 'work', 'Assess current state and design target state', ['Baseline current state', 'Design and agree target state']), P('Prepare & Pilot', 0.28, 'work', 'Prepare and pilot', ['Prepare people, process and materials', 'Run pilot and refine']), P('Roll-out', 0.22, 'work', 'Roll out change', ['Communicate and train', 'Roll out and support']), P('Embed & Sustain', 0.12, 'work', 'Embed and sustain', ['Monitor adoption', 'Reinforce and handover to owners']), P('Close', 0.08, 'close')],
  infrastructure: [P('Initiate & Mobilise', 0.07, 'mobilise'), P('Planning, Design & Approvals', 0.2, 'work', 'Plan, design and secure approvals', ['Detailed design', 'Permits and approvals']), P('Procurement', 0.15, 'work', 'Procure materials and contractors', ['Tender and evaluate', 'Award and order']), P('Construction / Installation', 0.34, 'work', 'Construct / install', ['Site preparation and works', 'Quality checks and rework']), P('Commissioning & Inspection', 0.14, 'work', 'Commission and inspect', ['Commissioning and testing', 'Inspection and snagging']), P('Handover & Close', 0.1, 'close')],
  product: [P('Mobilise & Discovery', 0.1, 'mobilise'), P('Design & Prototype', 0.24, 'work', 'Design and prototype', ['Research and concept', 'Prototype and review']), P('Develop', 0.3, 'work', 'Develop', ['Develop and integrate', 'Review and iterate']), P('Validate', 0.18, 'work', 'Validate and certify', ['Test and trial', 'Certification and sign-off']), P('Launch', 0.12, 'work', 'Prepare and execute launch', ['Launch readiness', 'Go-to-market and support']), P('Close', 0.06, 'close')],
  other: [P('Mobilise', 0.1, 'mobilise'), P('Plan', 0.2, 'work', 'Plan and prepare', ['Define approach', 'Agree plan']), P('Execute', 0.45, 'work', 'Execute', ['Deliver first half', 'Deliver second half']), P('Review & Embed', 0.15, 'work', 'Review and embed', ['Review results', 'Embed and hand over']), P('Close', 0.1, 'close')],
};

const NON_LABOUR = {
  technology: [['Software & licences', 4], ['Environments & infrastructure', 6], ['Training & enablement', 3]],
  transformation: [['Training & communications', 6], ['External advisers', 5], ['Change tooling & surveys', 2]],
  infrastructure: [['Materials & equipment', 25], ['Contractors & subcontracts', 20], ['Permits & inspections', 3], ['Site costs & utilities', 5]],
  product: [['Prototyping & materials', 8], ['Testing & certification', 4], ['Launch & marketing', 6]],
  other: [['Goods & services', 8], ['Training & communications', 3]],
};

const DEFAULT_TEAM = {
  technology: [['Business Analyst', 1], ['Solution Architect', 1], ['Software Engineer', 2], ['QA Analyst', 1]],
  transformation: [['Change Manager', 1], ['Business Analyst', 1], ['Process Specialist', 1], ['Training Lead', 1]],
  infrastructure: [['Site / Construction Lead', 1], ['Engineer', 2], ['Procurement Specialist', 1], ['Health & Safety Officer', 1]],
  product: [['Product Owner', 1], ['Designer', 1], ['Engineer', 2], ['Test Specialist', 1]],
  other: [['Coordinator', 2], ['Specialist', 1]],
};

// Benchmark hourly rates (program currency units) used ONLY when the user gives no rate. Always flagged as assumed.
const RATE_BENCHMARKS = [[/program|project manager|pmo/i, 95], [/architect/i, 120], [/engineer|developer|construction|site/i, 85], [/analyst|specialist|process/i, 75], [/qa|test/i, 70], [/design/i, 80], [/change|training|product/i, 78], [/procure/i, 72], [/safety/i, 70]];
const benchmarkRate = (role) => (RATE_BENCHMARKS.find(([re]) => re.test(role)) || [0, 70])[1];

const lines = (s) => String(s || '').split(/\r?\n/).map((x) => x.replace(/^[-•*\d.)\s]+/, '').trim()).filter(Boolean);
const r2 = (n) => Math.round(n * 100) / 100;

function phaseTemplate(a) {
  if (Array.isArray(a.phases) && a.phases.filter((p) => p.trim()).length >= 2) {
    const names = a.phases.map((p) => p.trim()).filter(Boolean);
    return names.map((n, i) => P(n, 1 / names.length, i === 0 ? 'mobilise' : i === names.length - 1 && names.length >= 4 ? 'close' : 'work', `Deliver ${n.toLowerCase()}`, ['Prepare', 'Deliver and review']));
  }
  const t = PHASES[a.program_type] || PHASES.other;
  return Array.isArray(t) ? t : t[a.delivery_approach] || t.hybrid;
}

export function generateProposal(a) {
  const type = PROGRAM_TYPES[a.program_type] ? a.program_type : 'other';
  a = { ...a, program_type: type };
  const util = 0.8;
  const assumptions = [];
  const warnings = [];
  const days = workdays(a.start_date, a.end_date);
  const n = days.length;
  const weeks = n / 5;

  // ---------- resources
  const resources = [];
  const addRes = (r) => { resources.push({ capacity_hrs_week: 40, allocation_pct: 100, chargeable: true, is_placeholder: false, rate_currency: '', ...r }); return r.key; };
  addRes({ key: 'sponsor', name: a.sponsor, role: 'Executive Sponsor', rate: null, chargeable: false });
  const pmRole = (a.team_roles || []).find((t) => /program|project manager|pmo/i.test(t.role));
  addRes({ key: 'pm', name: a.manager, role: 'Program Manager', rate: pmRole?.rate ?? benchmarkRate('program manager'), rate_assumed: pmRole?.rate == null, allocation_pct: pmRole?.allocation ?? 100 });
  const team = (a.team_roles || []).filter((t) => t !== pmRole);
  const teamSpec = team.length ? team : DEFAULT_TEAM[type].map(([role, count]) => ({ role, count, defaulted: true }));
  const delivery = [];
  teamSpec.forEach((t, i) => {
    const count = Math.max(1, Math.min(t.count || 1, 20));
    for (let k = 0; k < count; k++) {
      const named = t.name && count === 1;
      const key = addRes({
        key: `r${i}_${k}`, name: named ? t.name : `TBC – ${t.role}${count > 1 ? ` ${k + 1}` : ''}`, role: t.role,
        rate: t.rate ?? benchmarkRate(t.role), rate_assumed: t.rate == null, is_placeholder: !named, allocation_pct: t.allocation ?? 100,
      });
      delivery.push(key);
    }
  });
  if (!team.length) assumptions.push('No team roles were provided, so a typical team for this program type was assumed. Replace the "TBC" placeholders with real people.');
  const placeholders = resources.filter((r) => r.is_placeholder).length;
  if (resources.some((r) => r.rate_assumed && r.chargeable)) assumptions.push(`Hourly rates marked "assumed" are generic benchmark estimates in ${a.currency}, not a real rate card. Replace them before relying on cost figures.`);
  const wsList = (a.workstreams || []).map((w, j) => ({ key: `w${j}`, name: w.name, lead: w.lead || '', description: w.description || '' }));
  const leadKey = {};
  wsList.forEach((w) => {
    if (!w.lead) return;
    const ex = resources.find((r) => r.name.toLowerCase() === w.lead.toLowerCase());
    leadKey[w.key] = ex ? ex.key : addRes({ key: `l_${w.key}`, name: w.lead, role: 'Workstream Lead', rate: benchmarkRate('lead'), rate_assumed: true });
  });
  const cap = (key) => { const r = resources.find((x) => x.key === key); return (r.capacity_hrs_week * r.allocation_pct) / 100; };

  // ---------- phases and tasks
  const tmpl = phaseTemplate(a);
  const totalW = tmpl.reduce((s, p) => s + p.weight, 0);
  let acc = 0;
  const phases = tmpl.map((p) => {
    const s = Math.min(Math.round((acc / totalW) * n), n - 1);
    acc += p.weight;
    const e = Math.max(s, Math.round((acc / totalW) * n) - 1);
    return { ...p, days: days.slice(s, e + 1) };
  });
  const tasks = [];
  let sort = 0;
  const T = (t) => { tasks.push({ pred_keys: [], estimate_hrs: 0, notes: '', sort: sort++, ...t }); return t.key; };
  const first = (p) => p.days[0];
  const last = (p) => p.days[p.days.length - 1];
  let prevGate = null;
  const gates = [];
  phases.forEach((p, i) => {
    const pk = `p${i}`;
    T({ key: pk, parent_key: null, type: 'phase', name: p.name, start_date: first(p), end_date: last(p) });
    const pw = p.days.length / 5;
    if (p.kind !== 'work') {
      const items = p.kind === 'mobilise'
        ? ['Confirm charter, governance and stakeholders', 'Mobilise team and working arrangements', 'Baseline plan, budget and RAID review']
        : ['Confirm outcomes accepted and benefits hand-over', 'Capture lessons learned', 'Close out contracts, budget and documentation'];
      const keys = items.map((name, k) => T({
        key: `${pk}t${k}`, parent_key: pk, type: 'task', name, resource_key: 'pm', start_date: first(p), end_date: last(p),
        estimate_hrs: r2((pw * cap('pm') * 0.3) / items.length), pred_keys: p.kind === 'close' && prevGate ? [prevGate] : [],
      }));
      const g = T({ key: `g${i}`, parent_key: pk, type: 'milestone', name: p.kind === 'mobilise' ? 'Mobilisation complete' : 'Program closed', resource_key: 'sponsor', start_date: last(p), end_date: last(p), pred_keys: keys });
      gates.push(g);
      prevGate = g;
      return;
    }
    const D = p.days;
    const h = Math.max(1, Math.floor(D.length / 2));
    const aDays = D.slice(0, h);
    const bDays = D.slice(h).length ? D.slice(h) : D.slice(-1);
    const R = delivery.length ? delivery : ['pm'];
    const per = Math.ceil(Math.max(wsList.length, 1) / R.length);
    const bKeys = [];
    (wsList.length ? wsList : [{ key: 'w_', name: a.name }]).forEach((w, j) => {
      const wk = `${pk}${w.key}`;
      T({ key: wk, parent_key: pk, type: 'task', ws_key: w.key === 'w_' ? null : w.key, resource_key: leadKey[w.key] || null, name: `${w.name} – ${p.act}`, start_date: first(p), end_date: last(p) });
      [['a', aDays, p.subs[0], j], ['b', bDays, p.subs[1], j + wsList.length]].forEach(([suffix, ds, label, idx]) => {
        const rk = R[idx % R.length];
        const key = `${wk}${suffix}`;
        T({
          key, parent_key: wk, type: 'subtask', ws_key: w.key === 'w_' ? null : w.key, resource_key: rk, name: label,
          start_date: ds[0], end_date: ds[ds.length - 1], estimate_hrs: r2(((ds.length / 5) * cap(rk) * util) / per),
          pred_keys: suffix === 'a' ? (prevGate ? [prevGate] : []) : [`${wk}a`],
        });
        if (suffix === 'b') bKeys.push(key);
      });
    });
    const g = T({ key: `g${i}`, parent_key: pk, type: 'milestone', name: `${p.name} gate – exit criteria met`, resource_key: 'sponsor', start_date: last(p), end_date: last(p), pred_keys: bKeys });
    gates.push(g);
    prevGate = g;
  });
  // program-wide governance effort
  const pmoKey = T({ key: 'pmo', parent_key: null, type: 'phase', name: 'Program management', start_date: days[0], end_date: days[n - 1] });
  T({ key: 'pmo1', parent_key: pmoKey, type: 'task', name: 'Governance, reporting and RAID management', resource_key: 'pm', start_date: days[0], end_date: days[n - 1], estimate_hrs: r2(weeks * cap('pm') * 0.4) });
  assumptions.push(`Effort is sized so each assigned person is loaded at about ${Math.round(util * 100)}% of capacity over each phase; the Program Manager carries governance at about 40% plus mobilise/close work. These are planning estimates, not commitments.`);
  assumptions.push(`Phase durations follow a standard ${PROGRAM_TYPES[type].toLowerCase()} template (${phases.map((p) => `${p.name} ${Math.round((p.weight / totalW) * 100)}%`).join(', ')}) applied to your start and end dates. Adjust the dates in the Plan.`);

  // ---------- budget
  const labourCost = tasks.reduce((s, t) => {
    const r = resources.find((x) => x.key === t.resource_key);
    return s + (t.estimate_hrs || 0) * (r?.rate || 0);
  }, 0);
  const hours = tasks.reduce((s, t) => s + (t.estimate_hrs || 0), 0);
  const budget_lines = NON_LABOUR[type].map(([category, pct]) => ({
    category, description: `Estimate: ${pct}% of planned labour cost`, planned_amount: Math.round((labourCost * pct) / 100 / 100) * 100, actual_amount: 0, is_assumption: true,
  }));
  const multiRegion = /,|\band\b|global|multi|emea|apac|regional|countries/i.test(a.geography || '');
  if (multiRegion) budget_lines.push({ category: 'Travel & expenses', description: 'Estimate: 3% of planned labour cost (multi-region delivery)', planned_amount: Math.round((labourCost * 3) / 100 / 100) * 100, actual_amount: 0, is_assumption: true });
  const nonLabour = budget_lines.reduce((s, l) => s + l.planned_amount, 0);
  const contingency_pct = 10;
  const planCost = labourCost + nonLabour;
  const withCont = planCost * (1 + contingency_pct / 100);
  const guidance = a.budget_guidance || null;
  const approved_budget = guidance || Math.ceil(withCont / 1000) * 1000;
  assumptions.push(guidance
    ? `Approved budget is set to your guidance of ${a.currency} ${guidance.toLocaleString('en-US')}. Non-labour lines and ${contingency_pct}% contingency are assumptions.`
    : `No budget guidance was given, so the proposed budget is the estimated plan cost plus ${contingency_pct}% contingency (rounded up). Confirm the real budget.`);
  if (guidance && withCont > guidance) warnings.push(`The estimated plan cost including ${contingency_pct}% contingency (${a.currency} ${Math.round(withCont).toLocaleString('en-US')}) exceeds your budget guidance. Review scope, team and dates.`);

  // ---------- RAID
  const owner = a.manager;
  const gate1 = gates[1] || gates[0];
  const raid = [];
  const R_ = (r) => raid.push({ status: 'open', owner, response: '', description: '', ...r });
  lines(a.constraints).forEach((c) => R_({ type: 'risk', title: `Constraint may limit delivery: ${c}`.slice(0, 190), description: `Stated program constraint: ${c}`, impact: 3, likelihood: 3, response: 'Agree how the constraint will be managed and monitor it at the weekly program board.', due_date: addDays(a.start_date, 21) }));
  (a.dependencies || []).forEach((d) => {
    R_({ type: 'dependency', title: d.name, description: d.description || `External dependency: ${d.name}`, owner: d.owner || owner, due_date: d.needed_by || addDays(a.start_date, Math.min(diffDays(a.start_date, a.end_date) / 3, 120) | 0), response: 'Confirm the provider, delivery date and escalation route.', task_keys: [gate1] });
    R_({ type: 'risk', title: `Late delivery of dependency: ${d.name}`.slice(0, 190), impact: 4, likelihood: 3, response: 'Agree a delivery date with the provider and track as a dependency.', due_date: addDays(a.start_date, 30), task_keys: [gate1] });
  });
  R_({ type: 'risk', title: 'Scope creep beyond the agreed scope', description: `Exclusions: ${a.exclusions || 'none stated'}`, impact: 4, likelihood: 3, response: 'Operate change control against the approved baseline.', due_date: addDays(a.start_date, 30) });
  if (placeholders) R_({ type: 'risk', title: 'Key resources not yet confirmed', description: `${placeholders} team member(s) are still "TBC".`, impact: 4, likelihood: 4, response: 'Confirm named resources before the first delivery phase starts.', due_date: addDays(a.start_date, 14) });
  if (multiRegion) R_({ type: 'risk', title: 'Coordination across regions slows decisions and delivery', impact: 3, likelihood: 3, response: 'Agree a single decision forum and shared reporting cadence.', due_date: addDays(a.start_date, 30) });
  if (guidance && withCont > guidance) R_({ type: 'risk', title: 'Estimated cost exceeds budget guidance', description: warnings[0], impact: 4, likelihood: 4, response: 'Reconcile scope, team and budget before baseline approval.', due_date: addDays(a.start_date, 14) });
  if (n < 120) R_({ type: 'risk', title: 'Compressed timeline leaves little schedule contingency', impact: 3, likelihood: 3, response: 'Identify the critical path early and protect it.', due_date: addDays(a.start_date, 30) });
  R_({ type: 'assumption', title: 'Sponsor and stakeholders are available for timely decisions', impact: 3, likelihood: 2, response: 'Validate at kick-off; escalate through SteerCo if not met.' });
  R_({ type: 'assumption', title: `Scope exclusions remain stable: ${lines(a.exclusions).slice(0, 2).join('; ') || 'none stated'}`.slice(0, 190) });
  R_({ type: 'assumption', title: `Team availability averages ${Math.round(util * 100)}% of capacity and the benchmark rates are reasonable` });
  R_({ type: 'decision', title: 'Confirm governance cadence and decision rights', owner: a.sponsor, due_date: addDays(a.start_date, 14) });
  R_({ type: 'decision', title: 'Approve budget and release funding', owner: a.sponsor, due_date: addDays(a.start_date, 21) });
  R_({ type: 'decision', title: 'Approve the baseline plan', owner: a.sponsor, due_date: addDays(a.start_date, 28) });

  // ---------- charter text
  const obj = lines(a.objectives);
  const out = lines(a.outcomes);
  const charter = {
    summary: `"${a.name}" is a proposed ${PROGRAM_TYPES[type].toLowerCase()} program (${a.delivery_approach} approach) sponsored by ${a.sponsor} and led by ${a.manager}, running ${a.start_date} to ${a.end_date} (about ${Math.round(weeks)} weeks) in ${a.geography || 'the stated geography'}. `
      + `Primary objective: ${obj[0] || 'to be defined'}. It plans to deliver ${out.length} outcome(s) across ${wsList.length || 1} workstream(s). `
      + `Estimated effort is ${Math.round(hours).toLocaleString('en-US')} hours and estimated cost ${a.currency} ${Math.round(planCost).toLocaleString('en-US')} before contingency. [Generated proposal — review and edit.]`,
    objectives: obj.map((x) => `• ${x}`).join('\n'),
    outcomes: out.map((x) => `• ${x}`).join('\n'),
    success_measures: [...out.map((o) => `• Accepted by ${a.sponsor}: ${o}`), `• Delivered by ${a.end_date} with no more than 2 weeks variance to the approved baseline`, '• Final cost within ±10% of the approved budget', '• No open critical risks or issues (score 20+) at closure'].join('\n'),
    scope: lines(a.scope).map((x) => `• ${x}`).join('\n'),
    exclusions: lines(a.exclusions).map((x) => `• ${x}`).join('\n'),
    governance: [`• Steering committee: monthly, chaired by ${a.sponsor}`, `• Program board: weekly, led by ${a.manager}, with workstream leads${wsList.some((w) => w.lead) ? ` (${wsList.filter((w) => w.lead).map((w) => `${w.lead} – ${w.name}`).join('; ')})` : ''}`, '• RAID log reviewed weekly; decisions logged with owner and due date', '• Change control: changes moving a baseline date by more than 2 weeks or budget by more than 5% go to the steering committee', '• [Proposed governance — confirm cadence and thresholds]'].join('\n'),
    constraints: lines(a.constraints).map((x) => `• ${x}`).join('\n'),
  };

  return {
    program_type: type,
    charter,
    approved_budget,
    assumptions: { contingency_pct, forecast_method: 'percent', utilisation_pct: Math.round(util * 100), fx: {} },
    workstreams: wsList,
    resources,
    tasks,
    budget_lines,
    raid,
    assumption_notes: assumptions,
    warnings,
    stats: { phases: phases.length, tasks: tasks.filter((t) => t.type !== 'phase' && t.type !== 'milestone').length, milestones: tasks.filter((t) => t.type === 'milestone').length, hours: Math.round(hours), labourCost: Math.round(labourCost), nonLabour: Math.round(nonLabour), planCost: Math.round(planCost), withContingency: Math.round(withCont), resources: resources.length, placeholders, raid: raid.length },
    proposal_state: { sections: { summary: true, success_measures: true, governance: true }, assumptions: assumptions },
  };
}
