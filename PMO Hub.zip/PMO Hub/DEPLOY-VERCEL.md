# Host PMO Hub on Vercel (public demo)

Runs the app as one serverless function with an in-memory database seeded with sample data on every cold start. Nothing is stored, and visitors can browse but not change data (read-only).

From this folder, in Terminal:

    npm install
    npx vercel login        # sign in yourself
    npx vercel --prod       # accept the defaults; give the project a name such as pmo-hub-demo

Vercel prints the public https address. To allow edits in the demo (they vanish on restart), set DEMO_READONLY to "false" in vercel.json.
Do not add ANTHROPIC_API_KEY or DATABASE_URL to the demo.
